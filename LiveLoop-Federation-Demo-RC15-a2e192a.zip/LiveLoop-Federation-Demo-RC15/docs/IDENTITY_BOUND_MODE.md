# Identity-bound agent mode (optional, experimental, NOT qualified)

Default LiveLoop behaviour ("trusted-local") lets whoever starts `ll mcp` act as any participant. Identity-bound mode ties one `ll mcp` process to one agent identity.

What it does when enabled (`ll mcp --data-dir <dir> --identity-mode required --credential-file <file>`):
- The process refuses to start if the credential file is missing, malformed, wrong, revoked, expired, or its participant is not an active Agent. It never falls back to trusted-local.
- Every call is checked again against the database (revoked, retired, converted to Human, or enrollment no longer active means refused).
- The process can act only as its own participant, inside its own project. Administrative and bootstrap tools are refused.
- Approvals can be decided only by participants designated when the request was created, and a decision is final.

How to get a credential:
1. The participant must already be enrolled as an Agent (an administrator issues an invite from the dashboard; the agent claims it). A participant without an active enrollment cannot get a credential.
2. `ll principal issue --data-dir <dir> --project <slug> --participant <name> --out <new file>` writes a one-line credential file. The secret exists only in that file; keep it private. `ll principal revoke --principal-id <id>` revokes it; `ll principal list` shows principals.

What this does NOT claim:
- It is not security-qualified. The review is still in progress; do not describe a deployment as secure because it uses this mode.
- Participants that were created before enrollment existed cannot get a credential yet; how to migrate them is an open decision.
- External effects (archive files, webhook delivery, repository access) are outside the database transaction.
