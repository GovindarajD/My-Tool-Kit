# Known gaps and things not yet verified (v1.4.0 candidate)

Not run (no result exists, neither pass nor fail): install, repair, upgrade and uninstall on a clean machine; running on a PC with PowerShell disabled; saving Settings as a standard user; an independent second-PC scenario; code signing; any physical qualification.

Upgrade, uninstall and data recovery are described, with their untested parts, in `TESTING_AND_UPGRADE_NOTES.md`.

Product limits:
- The Settings dialog edits only the data folder and the dashboard address; Gitea and Edge-Hub configuration are shown, not edited, there.
- The installer and executables are not code-signed (expect a SmartScreen warning).
- Skill installation into an agent harness is a manual copy of whole folders, or the optional command-line helper `ll.exe harness skills` / `harness mcp-config` (preview first, backups, nothing deleted). There is no one-click flow in the Control Center.
- Third-party tools (Gitea, a tunnel client, OneDrive, a Git server) are not installed or configured by LiveLoop.
- No Windows service: the Control Center runs in your user session.
- Default trusted-local mode has known governance gaps: an arbitrary participant can be named as approver, a designation of a Human can be answered by any caller naming that Human, a stranger can supersede a directive, and approver names that do not resolve may be silently dropped by `send_message` and `issue_directive`. Hardening trusted-local mode is an open decision.
- Participants created before enrollment cannot be bound to a credential yet.
- Reads in bound mode are scoped to the project, not to the individual participant.
