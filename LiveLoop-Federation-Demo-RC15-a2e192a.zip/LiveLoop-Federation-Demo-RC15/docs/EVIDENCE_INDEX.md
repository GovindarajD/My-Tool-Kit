# Evidence index and how to verify what you installed

Each release candidate folder contains `MANIFEST.json` and `CHECKSUMS.txt` next to the installer.
- `CHECKSUMS.txt`: SHA-256 of every file in the folder. Check with `Get-FileHash` or `sha256sum -c`.
- `MANIFEST.json`: schema, source identity (git base and dirty state), build record summary, test evidence (counts per workspace, never added together, with a statement of what was and was not verified), the file list with hashes, and the release verdict (always `NOT_ASSESSED` until a person decides).
- `docs\` and `skills\` next to the installer are byte-identical to what the MSI installs. The manifest lists every file in them; if a hash differs, do not use the candidate.

What the numbers mean: test counts come from `cargo test` runs on the same source inputs that were built (debug test binaries; the shipped binaries are release builds), recorded by the evidence tool. They are the builder's own evidence, not an independent qualification.
