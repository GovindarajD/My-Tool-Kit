# LiveLoop — Installation, Setup & Operations Guide

This guide covers installing LiveLoop, connecting your first AI agent to it, and day-to-day
operation. It assumes no prior familiarity with LiveLoop.

## Quick start

1. Run **LiveLoop-Setup.exe**. Follow the install wizard (Welcome → license/options → install
   location).
2. When it finishes, **LiveLoop Control Center** launches automatically — look for its icon in
   your system tray, not a console window.
3. The Control Center starts the dashboard server on its own. The tray icon goes from amber
   (starting) to green (ready) within a few seconds.
4. Right-click the tray icon → **Open Dashboard** → sign in with your admin token. The token is
   generated on first run and stored locally; you only need to paste it once per browser.
5. From the dashboard, invite your first agent (Project → Agents → Invite Agent).
6. Install the skill(s) your agent harness needs — see **Connecting an agent** below.
7. Have the agent join LiveLoop. This is the one point where your agent harness itself starts
   `ll.exe mcp` via its own configuration (`.mcp.json`) — not something you run by hand. See
   **Connecting an agent** for why this matters.
8. Send a test message and confirm it shows up both to the agent and on the dashboard.
9. Optional: right-click the tray icon → **Settings** to review (and for data directory /
   dashboard address, edit) your configuration, or **Help / Diagnostics** to check component
   health.

That's the whole normal path. No PowerShell, no manually running `ll.exe`, no separate zip
files to extract.

## Prerequisites

| Requirement | Notes |
|---|---|
| Windows x64 | The only platform this release supports |
| An AI agent harness with a skill-discovery mechanism | Claude Code is the only harness this release has been validated against; other harnesses may work if they support the same skill-folder convention, but this hasn't been confirmed |
| Python 3 on `PATH` | Only needed if you use the `liveloop` skill's lifecycle scripts; the other four skills have no runtime dependency |

Nothing else. The server has no external database dependency (SQLite is built in), and normal
operation never requires PowerShell — it's only used, briefly, by this installer's own build
tooling, never by you.

## What gets installed

```
%ProgramFiles%\LiveLoop\
  ll.exe                          the server (handles both agent connections and the dashboard)
  liveloop-control-center.exe     the tray app that supervises everything
  edge-hub-node.exe                optional multi-PC sync component (see "Multiple PCs" below)
  docs\                           this guide and the other documents (see "More documents" below)
  skills\...                      the 5 agent skills, each a complete folder (see "Connecting an agent")
```

A Start Menu folder is created with shortcuts to the Control Center, this guide, and the skills
folder.

**Not included in this release**: the installer and bundled executables are not code-signed, so
Windows SmartScreen may warn you on first run. This will be resolved in a future release once a
code-signing certificate is obtained.

## The Control Center

The Control Center is the tray app you interact with day to day. It:

- Starts and supervises the dashboard server automatically on launch.
- Optionally starts and supervises the multi-PC sync component (Edge-Hub), but only if you've
  configured it — it never starts speculatively.
- Shows status at a glance via its tray icon color: amber = starting, green = ready, gray =
  stopped, red = error.

Right-click the tray icon for the full menu:

- **Open Dashboard** — opens the web dashboard in your browser.
- **Start / Stop** — controls the dashboard server.
- **Settings** — view and edit your data directory and dashboard address. Changes are saved for
  your Windows user (in `%LOCALAPPDATA%\LiveLoop\control-center.toml`, so a standard user can save
  them and an upgrade does not touch them) and take effect after you restart the Control Center. (Gitea and multi-PC configuration are shown
  here too, but are currently view-only — change those via the server's own configuration tools
  rather than this dialog.)
- **Help / Diagnostics** — shows the current health of each component in plain language.
- **About** — the product version and the build label. The product version (for example 1.4.0) is the
  number to quote; the version of the internal program components is not a release number.
- **Open Skills Folder** — opens the folder containing the 5 agent skills, for copying into your
  agent harness's own skills directory (see below).
- **Exit** — stops everything the Control Center itself started and closes the tray app.

**What the Control Center never does**: start or manage the `mcp` connection your agent harness
uses. That is deliberate — see the next section.

## Connecting an agent

An agent connects to LiveLoop in two independent ways, and it's important to understand the
difference:

1. **The dashboard** (`ll.exe web`) — the browser UI you use as a human. The Control Center
   starts and supervises this automatically. You never run this by hand.
2. **The agent connection** (`ll.exe mcp`) — how your AI agent harness actually talks to
   LiveLoop. This is started by your agent harness itself, reading its own configuration file
   (typically `.mcp.json` in your agent's workspace):
   ```json
   {
     "mcpServers": {
       "ll-mcp": {
         "type": "stdio",
         "command": "C:\\Program Files\\LiveLoop\\ll.exe",
         "args": ["mcp", "--data-dir", "C:\\Users\\<you>\\AppData\\Local\\LiveLoop\\data"],
         "env": {}
       }
     }
   }
   ```
   **You never run `ll.exe mcp` directly, and the Control Center never starts it either.** If
   you do run it by hand from a terminal to see what it does, it will print one line and then go
   silent — that's expected; it's waiting for an agent harness to connect over stdio, not hung.

### Installing the skills

LiveLoop ships five skills, each a small instruction set your agent harness loads:

| Skill | Who needs it |
|---|---|
| `liveloop` | Every agent that sends or receives LiveLoop messages |
| `organizing` | Combined with `architect` or `coder` below — shared session/filing discipline |
| `architect` | Agents acting in a planning/review role |
| `coder` | Agents acting in an implementation role |
| `repo-access` | Anyone configuring or using governed Git repository access |

To install: right-click the tray icon → **Open Skills Folder**, then copy the skill folder(s)
you need into your agent harness's own skills directory. For Claude Code, that's
`<your workspace>\.claude\skills\<skill name>\`.

Copy each skill as a **whole folder**. The `liveloop` skill is 39 files (helper scripts, contract
documents and governance notes next to `SKILL.md`); copying `SKILL.md` alone does not work. If a
folder with the same name already exists in your harness, keep a copy of yours before replacing it.
The same `docs\` and `skills\` folders are also delivered as plain folders next to the installer.

Optional command-line helper (you run it; nothing happens on its own). It first only PRINTS what it
would do; add `--apply` to do it. It never deletes anything, backs up any file it would replace
(`<name>.bak-<timestamp>`) and leaves your own files alone:

```
"C:\Program Files\LiveLoop\ll.exe" harness skills --target "<your harness skills folder>"
"C:\Program Files\LiveLoop\ll.exe" harness mcp-config --file "<your .mcp.json>" --data-dir "<your data folder>"
```

The second command adds or updates only the `ll-mcp` entry of the `.mcp.json` and keeps every other
server; if a different `ll-mcp` entry exists it stops and says so (use `--replace` to replace just
that entry; the file is backed up first). An existing entry that runs in identity-bound mode
(`--identity-mode required`) is never replaced by a default-mode entry, with or without `--replace`;
pass `--credential-file <your credential file>` to write an identity-bound entry. The helpers refuse
links/junctions, network (UNC) and device paths, and a target that overlaps the source; a file that
changed between the preview and `--apply` is not overwritten. The file is re-written as formatted
JSON, so key order may change. There is no one-click version of this in the Control Center yet.

Once installed, have your agent harness invoke the `liveloop` skill and follow its instructions
to join — this is where the `mcp` connection above actually gets used.

## Multiple PCs (optional)

Earlier testing covered the Edge-Hub transport between two PCs (the "E4" setup). The installed Control Center procedure below has not itself been qualified: it is written from the product's source and from that earlier testing.

Most people never need this section. A single PC running the Control Center, the dashboard and
the agent connection (everything above) is the complete, normal setup.

### What this section describes

This section describes the earlier E4 multi-PC topology: **each PC is a
complete, independent LiveLoop installation** with its own data directory, database, admin token
and dashboard. In this setup nothing is shared live between PCs, and a dashboard shows only the
PC it runs on.

The component that can exchange data between PCs in this setup is **Edge-Hub**, an optional
program that ships in the install folder (`edge-hub-node.exe`). It passes small, self-contained
message files ("envelopes") and their acknowledgements through **one folder that OneDrive keeps
synchronised between the PCs**. It is a slow, eventual channel and is not used to wake or control
agents. In earlier testing, delivery took anywhere from under a minute to about 38 minutes; that
is an observation, not a guarantee, and there is no guaranteed maximum.

> Scope of this release: Edge-Hub delivers envelopes
> between PCs and keeps a local record of what it received and acknowledged (visible with the
> `status` command below). This guide does not describe, and this release does not include, an
> automatic bridge that copies LiveLoop messages, projects or dashboard content between PCs.
> Other ways of connecting PCs (for example a network or tunnel you provide yourself) are not
> described or tested here.

### What stays on each PC, and what is designed to be shared

| Item | Where it lives | Placed in the OneDrive transport folder? |
|---|---|---|
| LiveLoop database (`liveloop.sqlite3` and its `-wal` / `-shm` files) | The PC's own data directory | **Never** |
| Admin token (`admin_token.secret`) | The PC's own data directory | **Never** |
| Git/Gitea credentials | The PC's own Windows Credential Manager | **Never** |
| Edge-Hub's own local store (`local_store.sqlite3`) and node identity | Edge-Hub's `data_dir` on that PC | **Never** |
| Edge-Hub envelopes and acknowledgements | The shared transport folder | **Yes - this is what that folder is for** |
| Installer, skills, documents | Each PC installs or downloads its own copy | Not required (optional convenience) |

Two PCs that use the same project name still have two separate projects in two separate
databases. Agreeing on a project name and participant names is a human convention, not a link.

### One PC (the default)

Follow the Quick start above. There is nothing to configure for multiple PCs: Edge-Hub is
installed but dormant, and the Control Center does not start it unless it finds the
configuration file described below. Right-click the tray icon, then **Settings** to see the data
directory and dashboard address this PC is using, and **Help / Diagnostics** to see whether
Edge-Hub is "not configured" (the normal one-PC state).

### Adding a second PC

1. **Install and check each PC on its own first.** On every PC, complete the Quick start and
   confirm the tray icon is green, the dashboard opens, and a test message shows up. Do this
   before touching Edge-Hub, so a later problem can be traced to the right place.
2. **Pick one OneDrive folder that is genuinely the same folder on both PCs.** Create it once
   (for example `LiveLoopTransport`) and, if the PCs use different OneDrive accounts, share it
   to the second account using OneDrive's own sharing and accept it there. Two folders that
   merely have the same name are *not* the same folder and will exchange nothing. The local path
   may differ on each PC. Make sure OneDrive shows the folder actively syncing, not paused.
   Earlier testing worked with OneDrive's default Files On-Demand setting. Choosing "Always keep
   on this device" for this folder is an optional precaution, not a requirement.
3. **Keep everything else out of that folder.** Do not put a data directory, an admin token or
   any credential file inside it.
4. **Create a small text file named `edge-hub.toml` on each PC**, in your own per-user folder
   `%LOCALAPPDATA%\LiveLoop\` (for example `C:\Users\alice\AppData\Local\LiveLoop\edge-hub.toml`;
   create the `LiveLoop` folder if it is missing). No administrator rights are needed there, and
   an upgrade of the installed program does not touch it. The Control Center reads this per-user
   file first; if there is none it falls back to an `edge-hub.toml` next to `edge-hub-node.exe`
   (the older location, kept so existing setups keep working). Optional helper that writes this one
   file for you after checking the paths (it prints first; add `--apply` to write). It refuses a data
   folder equal to, inside or containing the shared folder, and a data folder inside a OneDrive
   folder it can find (environment variables and the OneDrive accounts in the registry; links,
   `..` and upper/lower case are resolved first). It cannot detect other sync products, so it never
   says a folder is safe: the default data folder is accepted, any other needs `--confirm-not-synced`.
   If this PC already has an Edge-Hub store, pointing it at a different data folder would make
   Edge-Hub create a NEW node identity (the old store is neither migrated nor deleted), so that also
   needs `--replace --accept-new-node-identity`. It keeps a backup of any file it replaces:
   `ll.exe harness edge-hub --transport-root "<shared folder>"`.
   Each PC uses its **own** local paths:

   ```toml
   transport_root = "C:\\Users\\alice\\OneDrive\\LiveLoopTransport"
   data_dir = "C:\\Users\\alice\\AppData\\Local\\LiveLoop\\edge-hub-data"
   ```

   - `transport_root`: this PC's local path to the shared OneDrive folder from step 2.
   - `data_dir`: a local folder under your own user profile that is **not** inside
     `transport_root` and is not synchronised by OneDrive. Edge-Hub creates it when it runs (so
     it exists after step 5). The `status` command below does **not** create it: run `status`
     only after step 5, or create the folder yourself first. The software does not check where
     it is: if `data_dir` is placed inside the shared folder, its database would be synchronised,
     which is the failure this section exists to prevent.
   - Write complete literal paths with doubled backslashes (`\\`), as shown. Do not use
     environment variables such as `%LOCALAPPDATA%` in this file. The two fields are the only
     settings in the file.
5. **Restart the Control Center** (tray icon, **Exit**, then start it again). It looks for
   `edge-hub.toml` only when it starts. If both `edge-hub.toml` and `edge-hub-node.exe` are
   present it then starts Edge-Hub automatically; Edge-Hub also appears in **Help / Diagnostics**
   and gets its own status, Start and Stop entries in the tray menu. The Settings window shows
   the Edge-Hub configuration but does not create or edit it.
6. **Check each PC on its own** (next section), then check the link in both directions.

The command-prompt steps above and below are *engineering* steps, not part of the normal
operator interface. There is no setup wizard, button or credential prompt for Edge-Hub in this
release.

### Checking that each PC is independent and that the link works

Use a normal command prompt on each PC:

```
cd "C:\Program Files\LiveLoop"
edge-hub-node.exe status --config edge-hub.toml
```

- The first run prints a new `node_id` for this PC and remembers it. Each PC must show a
  **different** `node_id`; never copy one between PCs.
- The `data_dir` and `transport_root` lines must show this PC's own paths.
- Edge-Hub announces each PC in the shared folder when it starts, so a PC appears there only
  after Edge-Hub has run on it. Then `envelopes\<node_id>\` and `acks\<node_id>\` folders appear,
  one pair per PC. Seeing only your own PC's folders may simply be a sync or discovery delay: wait and check again, and also confirm it is the same OneDrive folder on both PCs, before concluding anything.

To check delivery, compare before and after rather than relying on one number:

1. On PC-2, run `status` and note the `peer <PC-1 node_id>: ingested=...` value, if that line
   exists (this is your baseline).
2. On PC-1, create a small payload file in a folder you own, for example
   `C:\Users\alice\LiveLoopTest\ping.json`, containing a unique value:
   `{"correlation_id":"pc1-2026-10-13-001"}`. Use a different value each time.
3. On PC-1, send one test envelope using the absolute path. If the Control Center is running
   Edge-Hub on that PC, choose **Stop** for Edge-Hub in the tray menu first. This is a
   precaution so two copies do not use the same local store; concurrent use has not been
   qualified:

   ```
   cd "C:\Program Files\LiveLoop"
   edge-hub-node.exe run --config edge-hub.toml --max-cycles 1 --send-event test.ping --send-payload-file "C:\Users\alice\LiveLoopTest\ping.json"
   ```

   Start Edge-Hub again from the tray menu afterwards.
4. Wait for OneDrive to sync. If nothing arrives after a long time, check OneDrive's own sync
   status on both PCs and re-run `status`; there is no guaranteed delivery time.
5. On PC-2, run `status` again. The `ingested` value for the PC-1 line should be one higher than
   your baseline (the line is new if there was no baseline). Then look through the files in
   `envelopes\<PC-1 node_id>\` in the shared folder and find the text file that contains
   `event_type` `test.ping` and your exact `correlation_id`. Do not simply take the newest file: other envelopes may have arrived at the same time. The counter alone is only an aggregate
   indication that something arrived; the correlation value in that file is what ties it to
   your test. This procedure does not by itself prove that the receiving PC's store recorded that
   specific event; that end-to-end evidence is still pending.

Repeat from PC-2 to PC-1 to check the other direction.

### If something goes wrong

| Symptom | What it means |
|---|---|
| `status` shows no `peer` line | The folder may not be the same OneDrive folder on both PCs, OneDrive may not have finished syncing, or the other PC may not have run Edge-Hub yet |
| `status` fails with a config error | The error names the problem: file missing, TOML unreadable, or a path that cannot be created or opened (for example a `data_dir` folder that does not exist yet). Fix `edge-hub.toml` or create the folder |
| Control Center shows Edge-Hub "not configured" after you created the file | Restart the Control Center; check the file is named exactly `edge-hub.toml`, sits in `%LOCALAPPDATA%\LiveLoop\` (or next to `edge-hub-node.exe`), and that `edge-hub-node.exe` is installed |
| OneDrive is paused, delayed or offline | Each PC's LiveLoop keeps working; only the exchange between PCs waits. Earlier testing showed exchange continuing after a long delay and after restarts. Acknowledgements that are not confirmed in time are shown as `stalled_acks` in `status` rather than dropped silently. Other cases, such as the shared folder being deleted, have not been verified |
| A damaged envelope file appears | Edge-Hub moves files that are not valid JSON, or whose content hash does not match, to a `quarantine` folder in the shared folder. Other kinds of damage have not been verified |
| `data_dir` was placed inside the shared folder | Stop every Edge-Hub instance on this PC: the one the Control Center supervises and any you started by hand. Do not delete `data_dir` or its `local_store.sqlite3`: they hold this PC's node identity and local record. This release provides no tested steps for moving them, so get engineering guidance before moving or changing anything |

### What is not covered

- Synchronising source code or working folders between PCs is a separate problem and is not
  provided by Edge-Hub.
- Exchange over a local network without OneDrive (often called "E3") is not supported in this
  release; only the OneDrive folder method described above has been tested.
- The earlier Edge-Hub transport was qualified on a physical two-PC setup with the earlier
  launcher (v1.1). This procedure for the installed Control Center has not been qualified; an
  independent clean-PC confirmation (acceptance scenario 11) is still pending.

## Optional integrations (not installed by LiveLoop)

The installer puts LiveLoop itself on your PC. It does **not** install, set up, start or sign you in
to any of the following, and it registers no Windows service. Help / Diagnostics in the Control
Center repeats this list.

| Integration | What you do | What LiveLoop does |
|---|---|---|
| Gitea (shared repository access) | Install or reach your own Gitea (local or external) | Talks to it only through the admin-gated repo-access tool, after you configure it with the admin token. The Control Center shows a best-effort "something is listening on port 3000" hint, not a verified check |
| OneDrive (second PC) | Use your own OneDrive client and account; share one folder to the other PC | Nothing. You write that folder's local path into `edge-hub.toml` (see "Multiple PCs") |
| Tunnel client (ChatGPT as Architect) | Install and sign in to the external tunnel program yourself | Not installed by LiveLoop. Once its program and profile are set in the Control Center's Settings (or found in the usual places), the tray menu shows `Tunnel: <state>` with Start/Stop, and Settings can start it together with the Control Center. The Control Center checks the profile first (program present, the API-key variable or file named by the profile exists, a fixed health port), refuses to start over a client that is already running, and follows its `/readyz`. The API key is never stored or shown by LiveLoop. The tunnel program starts its own `ll mcp` |
| Agent harness (Claude Code and similar) | Copy the skills (Open Skills Folder), add the `.mcp.json` snippet above, sign in to the harness | Provides the files and the `ll mcp` command |

A short checklist for a typical first setup, in order:

1. Install, start the Control Center, confirm the tray icon is green and the dashboard opens.
2. Optional, one PC only: copy the skills and add the `.mcp.json` snippet for your agent harness.
3. Optional: Gitea - install or locate it yourself, then configure repo access with the admin token.
4. Optional, two PCs: follow "Multiple PCs"; your OneDrive account and sharing are yours to set up.
5. Optional: the tunnel program for ChatGPT - set up and sign in outside LiveLoop.

Everything that needs a login (OneDrive, Gitea, the tunnel provider, your agent harness) is a step
you perform yourself; nothing here automates an account.

## Shared Git repository access (optional)

If your team uses Gitea and wants agents to read/commit files through a governed broker (rather
than handing out raw credentials), LiveLoop includes this as an opt-in feature, disabled by
default. See the `repo-access` skill for how to configure and use it. The Control Center's
Settings dialog shows a best-effort check for a local Gitea instance, but this is a convenience
indicator only, not a guarantee — verify your own configuration against your actual Gitea
instance before relying on it.

LiveLoop does not install, manage, or take ownership of Gitea itself — it only connects to an
instance you already run.

## Normal operations

- **Start/stop**: use the Control Center tray menu.
- **Backups**: the data directory (shown in Settings) contains everything — back it up like any
  other folder while the server is stopped for a consistent copy.
- **Moving one project from another data folder** (rare, operator task): `ll.exe project import --from "<old data folder>" --project <name> --to "<this data folder>"`
  prints a preview and changes nothing. Adding `--apply` takes a verified backup of the target, copies the project's rows and its archive folder
  with all ids and message numbers preserved, and verifies the result; a second import of the same project is refused, and
  `ll.exe project undo-import --to "<folder>" --report "<report file>"` removes exactly what was imported (it refuses if the project has new work).
  Stop everything that writes to either folder first. This tool has been tested on fixtures only; run it on copies of your data before using it live.
- **Uninstall**: use Windows' "Apps & Features." This removes the installed program files; your
  data directory is left in place.

## Troubleshooting

| Symptom | What it means |
|---|---|
| Tray icon stays amber for a long time | The dashboard hasn't finished starting — check that its port isn't already in use by something else, and that the data directory is writable |
| Tray icon turns red | The server process exited unexpectedly — check Windows Event Viewer, or restart the Control Center for a fresh diagnostic trace |
| Running `ll.exe mcp` from a terminal seems to do nothing | Expected — it's waiting for an agent harness to connect; not a hang |
| A dashboard page shows "DEGRADED" | A real, underlying problem (e.g., a locked database file) — this is intentionally shown as an error rather than a misleading blank page |

## More documents

`RELEASE_NOTES.md`, `IDENTITY_BOUND_MODE.md` (optional credential-required agent mode, not
qualified), `KNOWN_GAPS.md`, `EVIDENCE_INDEX.md` and `TESTING_AND_UPGRADE_NOTES.md` (a checklist for
whoever tests this candidate, and what is and is not known about upgrades and data recovery) are in
the same `docs\` folder.

## Security notes

- Your admin token is generated locally on first run and never leaves your machine except as a
  one-time paste into your own browser session.
- The dashboard uses a signed session cookie after that one-time entry — you're not asked for
  the raw token again.
- If you use governed Gitea access, no agent identity ever receives a raw Gitea credential — the
  broker performs operations on the agent's behalf and returns only results.

## Known limitations (current release)

- The Settings dialog edits your data directory and dashboard address only; Gitea and Edge-Hub
  configuration are view-only there for now.
- No real custom product icon branding beyond the tray/exe icon shipped in this release (no
  further imagery such as splash screens).
- The installer and bundled executables are not code-signed yet — expect a SmartScreen warning.
- This release has not yet been formally verified on a PC with PowerShell execution disabled at
  the OS level (the normal product path doesn't use PowerShell, but that specific scenario
  hasn't been run as a dedicated test).
- Skill installation is a manual copy step, or the optional `ll.exe harness skills` command above; there
  is no one-click "install to my agent" workflow in the Control Center yet.
