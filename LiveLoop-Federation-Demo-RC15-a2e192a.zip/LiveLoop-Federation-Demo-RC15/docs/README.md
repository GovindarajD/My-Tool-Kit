# LiveLoop documentation (v1.4 line)

Start with **INSTALLATION_GUIDE.md**: installation, connecting your first AI agent, day-to-day operation, two-PC use, troubleshooting.

| Document | What it is for |
|---|---|
| `INSTALLATION_GUIDE.md` | Install, Control Center, connecting an agent, skills, multiple PCs, optional integrations, troubleshooting |
| `RELEASE_NOTES.md` | What this release contains and what changed since the previous one |
| `IDENTITY_BOUND_MODE.md` | The optional identity-bound (credential-required) agent mode: what it does, how to use it, what it does NOT claim |
| `KNOWN_GAPS.md` | Limitations and everything that has NOT been tested or qualified yet |
| `TESTING_AND_UPGRADE_NOTES.md` | Checklist for testing this candidate; what is known (and not known) about upgrade, uninstall and data recovery |
| `EVIDENCE_INDEX.md` | How to check that what you installed is what was built, and where the test evidence for a release lives |
| `..\skills\README.md` | The agent skills shipped with LiveLoop (complete folders; copy whole folders, never `SKILL.md` alone) |

Development history, design records and internal decision logs are not shipped here; they stay in the project repository.
