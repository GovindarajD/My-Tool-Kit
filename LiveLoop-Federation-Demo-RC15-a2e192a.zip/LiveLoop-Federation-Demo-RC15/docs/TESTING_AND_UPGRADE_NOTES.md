# Testing checklist, upgrade and data-recovery notes (v1.4.0 candidate)

This candidate is a local build. Everything below that says "to test" has NOT been run by the builder. The builder's own results are listed in `EVIDENCE_INDEX.md` and in the candidate's `MANIFEST.json`.

## What is known about your data
- Your data (the SQLite database and the message archive) lives in the data folder shown in Settings. By default that is `%LOCALAPPDATA%\LiveLoop\data` for the Windows user who runs the Control Center. The installer does not create, move or delete it.
- Uninstalling removes the program files only. The data folder and your per-user settings (`%LOCALAPPDATA%\LiveLoop\control-center.toml`, `edge-hub.toml`) are left in place.
- The database is upgraded automatically the first time a newer `ll.exe` opens it. The two newest steps (identity-bound mode tables) are applied atomically: they either complete or leave the database as it was. The upgrade is ONE WAY: there is no downgrade step, and an older `ll.exe` has not been tested against a database a newer one has opened. Copy the data folder somewhere safe before you upgrade (stop the Control Center first so the copy is consistent).

## Known limitations of upgrade and recovery (not verified)
- No upgrade has been run on a machine that holds real v1.2/v1.3 data. `ll.exe adopt-data --from <old folder> --to <new folder>` copies an existing data folder without deleting or overwriting anything; it has unit tests but no run against real user data.
- Earlier installers set a machine-wide `LL_CC_DATA_DIR` variable. This installer does not. If your previous data was found through that variable, check Settings after upgrading: if the data folder shown is not the one that holds your data, set it in Settings or use `adopt-data`. A removed variable and an unchanged data folder were not tested together on a real machine.
- A repair, an interrupted install, and an upgrade over a running Control Center were not tested.
- FOUND ON THE FIRST REAL UPGRADE (RC6 -> RC9): the installer registered the new package but kept the OLD `ll.exe` and Control Center, because every candidate had the same package version (1.4.0.0) and the programs carried file version 0.1.0 (Windows Installer only overwrites a file with a HIGHER file version; unversioned documents were replaced, which hid the problem). From RC10 the programs carry a file version taken from the candidate label (for example 1.4.0.10). Check after every upgrade: `ll version` and the file version of `ll.exe` in `C:\Program Files\LiveLoop`. Workaround for an affected installation: uninstall LiveLoop in Windows Settings (the data folder is not touched), then run the new Setup. Candidates built before RC10 must be installed on a machine WITHOUT an earlier LiveLoop install, or after uninstalling it. The RC10 fix itself is verified only by inspecting the built file versions; the real upgrade is the next test.
- Backups made by the helper commands (`.bak-<timestamp>` files) are plain copies next to the original; nothing prunes them.
- There is no rollback of a candidate: keep the previous installer and your data copy.

## Checklist for the person testing (tick each only after you have done it)
Install and first run
1. [ ] On a clean test machine or VM (not your working PC), run `LiveLoop-Setup.exe`. Note any SmartScreen prompt (the files are not signed).
2. [ ] The Control Center icon appears; it turns green; Open Dashboard works; sign in with the admin token.
3. [ ] Help / Diagnostics, Settings and About show the product version 1.4.0 and the candidate label.
4. [ ] Settings: change the dashboard address as a standard (non-administrator) user, restart, confirm it stuck and that `%LOCALAPPDATA%\LiveLoop\control-center.toml` was written.
Agents and skills
5. [ ] `docs\` and `skills\` next to the installer match the installed `C:\Program Files\LiveLoop\docs` and `skills` folders (compare file counts and a few files).
6. [ ] Copy the whole `liveloop` skill folder into a test agent harness (or run `ll.exe harness skills --target <folder>` without `--apply` first, read the preview, then with `--apply`); the agent can read its helper scripts.
7. [ ] `ll.exe harness mcp-config --file <test .mcp.json> --data-dir <data folder>` shows a preview; `--apply` keeps every other server in the file.
8. [ ] Invite an agent from the dashboard, let it join, send a message each way, see both on the dashboard.
Two PCs (only if you have two test machines and a shared folder)
9. [ ] `ll.exe harness edge-hub --transport-root <shared folder>` preview and apply on each PC; Edge-Hub starts from the Control Center; a test event crosses.
Upgrade, uninstall, recovery
10. [ ] Install this candidate over an older installed version that has test data; confirm the data is still there and the dashboard shows it.
11. [ ] Uninstall; confirm the data folder and settings are still present; reinstall and confirm they are picked up.
12. [ ] Restore a copied data folder into a fresh install and confirm it opens.
Identity-bound mode (optional, not qualified)
13. [ ] Issue a credential for an enrolled agent (`ll.exe principal issue ...`), start `ll mcp` with `--identity-mode required --credential-file ...`, and confirm a wrong or revoked credential makes it refuse to start.
Also not covered by anything above: a PC with PowerShell disabled, code signing, antivirus behaviour, long-running stability.
