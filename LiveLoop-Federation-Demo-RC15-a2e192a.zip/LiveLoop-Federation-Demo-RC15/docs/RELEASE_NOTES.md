# LiveLoop v1.4.0 release notes (local candidate; not yet qualified or approved)

Everything in this document describes a local build candidate. It has not been installed on an independent PC, has not been code-signed, and no physical or
clean-machine qualification has been run. See `KNOWN_GAPS.md`.

## What is in the box
- `LiveLoop-Setup.exe` (bundle) and `LiveLoop.msi`: `ll.exe`, `liveloop-control-center.exe`, `edge-hub-node.exe`, this `docs\` folder and the complete `skills\` folders.
- The same `docs\` and `skills\` folders are also delivered next to the installer as plain folders, byte-identical to what the MSI installs.

## Changes since the previous candidate line
- Identity-bound agent mode (optional, off by default): `ll mcp --identity-mode required --credential-file <file>`, `ll principal issue|revoke|list`. See `IDENTITY_BOUND_MODE.md`.
- A credential can only be issued for a participant with an ACTIVE enrollment. There is no override.
- Bound-mode writes run inside a database write transaction with rollback on error; migrations 10 and 11 are applied atomically.
- Per-user Control Center settings (`%LOCALAPPDATA%\LiveLoop\control-center.toml`) and a per-user default data folder; the installer no longer sets a machine-wide variable.
- The product version (1.4.0) and the candidate label are shown by `ll version` and in the Control Center About box. Internal crate versions (0.1.0) are not release numbers.
- Optional command-line helpers, preview first and never deleting: `ll harness skills` (copy skill folders), `ll harness mcp-config` (add/update only the `ll-mcp` entry of a `.mcp.json`, never downgrading an identity-bound entry), `ll harness edge-hub` (write the per-user two-PC config with data-folder checks). See the installation guide.
- `ll project import` / `ll project undo-import`: copy one project (rows, archive folder, ids and message numbers) from another data folder, preview first, verified backup, one transaction, recovery from interruption. Tested on fixtures only; not yet run on real data.
- Team page (dashboard) no longer misleads about presence: a self-reported status older than 30 minutes is shown as Unknown/STALE (never Listening); a new "Last activity (server)" column shows the newest message or cursor update; "Historical / Legacy" now means a legacy identity with no server-held activity for 14 days (an identity that is active but never posts status, such as a ChatGPT architect, is no longer listed as historical); likely test/fixture identities with no recent activity get their own section. Display only; no data or schema change. Tested on fixtures; not yet seen on the real project by the Architect.
- Team page, default view (RC11): shows people and agents with a reason to be listed (humans always; agents with activity in the last 14 days). Idle legacy agents and likely test identities stay in a collapsed "All other identities" block, all preserved, nothing revoked or deleted (display rule only, no schema change). "Listening (verified)" now means a live waiter is actually reporting to the server (an unexpired typed presence); an identity that only says in its own status that it is waiting shows as "Joined (self-reported, not verified)". The skill's `cooperative_wait.py` now reports LISTENING presence (declared interval 30 s) while it runs and says in its result whether the report succeeded; an assistant that only reads and writes on demand (for example a ChatGPT architect) never shows as Listening: with recent messages but no status reports it reads "Active on demand (no status reports)", and an agent whose own fresh status is JOINED_ACTIVE reads "Joined, not in a live wait (self-reported)" instead of a bare "Unknown". The installed skill folder must be updated for waiters to report.
- Control Center can run the external tunnel client (ChatGPT access): tray status row `Tunnel: <state>` with Start/Stop, Settings fields for the program, the profile and "start with the Control Center" (off by default), a pre-flight with a plain reason when it will not start, `/readyz`-based Healthy/Degraded state, and Help / Diagnostics shows its state and reason. Stop ends the client and the `ll mcp` it started. The tunnel client itself is still not part of the installer and its API key is never stored by LiveLoop. Tested by unit tests and one live run against the real client; the tray Stop item and the Settings dialog are not covered by an automated test.
- A document for whoever tests this candidate, including what is known and unknown about upgrades and data recovery: `TESTING_AND_UPGRADE_NOTES.md`.
- The skill payload is now the complete `liveloop` skill (previously only its `SKILL.md` was shipped).

## Unchanged on purpose
- Default (trusted-local) behaviour of the agent connection is unchanged. The governance gaps listed in `KNOWN_GAPS.md` still apply to it.
