LiveLoop RC15 + GitHub Federation DEMO  -  private build (unsigned, untagged, NOT a release)
=========================================================================================
What this is
  The LiveLoop installer (LiveLoop-Setup.exe / LiveLoop.msi) built from the local branch feature/federation-demo (commit a2e192a, on
  GitHub main f42b6f2b). Compared with RC13/RC14 it adds a "Federation (DEMO)" page to the Control Center and a federation node that
  lets two or more PCs exchange ordinary LiveLoop agent messages through a private GitHub hub, with delivery receipts.
  docs\, licenses\ and skills\ are the product documents, third-party licences and the 5 agent skills (same as the installer payload).

Step 0 - verify (on the target PC)
  Unzip somewhere simple (e.g. C:\LiveLoopDemo) and in PowerShell inside that folder run:
      powershell -ExecutionPolicy Bypass -File .\VERIFY.ps1
  Every line must say OK.

Install
  1. If this PC already runs LiveLoop you rely on, first copy %LOCALAPPDATA%\LiveLoop\data somewhere safe. This build upgrades the product
     files; the upgrade from an earlier RC has NOT been tested.
  2. Run LiveLoop-Setup.exe. It is NOT code-signed, so Windows SmartScreen / Defender may warn: choose More info > Run anyway only if
     VERIFY.ps1 passed.
  3. The Control Center tray icon appears. Skills for your agent harness: copy the whole folders you need from the installed
     skills\ (or this zip's skills\) into <workspace>\.claude\skills\ - see docs\INSTALLATION_GUIDE.md.

Use the Federation DEMO (two or more PCs)
  What you need: a PRIVATE GitHub repo for the demo hub (default org-in-a-box/liveloop-github-communication-hub, branch sandbox/m0-exchange,
  folder workspaces/m0-test) and a fine-grained GitHub token limited to ONLY that repo (Contents: read and write, Metadata: read), short expiry.
  Host PC: tray icon > "Federation (DEMO)..." > Network name, this node's name, token (masked), token expiry (UTC, optional) > pick a save path >
    "Create network & export profile". The exported .liveloop-network file is SECRET-BEARING (token + network secret): copy it only to the PCs you
    want to join, by a private route; never commit, e-mail or publish it. The token field is cleared after export.
  Every other PC: install this build, tray icon > "Federation (DEMO)..." > "Profile file" = that .liveloop-network file > "Import / Join".
    No invite, no fingerprint command, no branch or folder to type. Each PC creates its own identity and key. Registration works even while the
    host PC is switched off; peers admit each other automatically (demo mode opts in to that).
  Messages: remote agents appear as LiveLoop participants named "<node name>/<agent>". Send to them with the normal send_message; the other
    side receives an ordinary mailbox message with a "Remote message via LiveLoop federation" header, INFORMATION ONLY (a remote message never
    authorizes an action). acknowledge_message shows up on the sender as a normal acknowledgement.
  Status: the Federation page shows the network, node, peers, credential state and last error. If the token expires or is revoked it says so;
    local LiveLoop keeps working and outgoing messages queue. Import a profile with a new token (or re-export from the host) to recover.

What has and has NOT been tested (honest status)
  - Unit/integration: 392 tests pass at this commit (workspace-wide).
  - Real GitHub hub, two isolated instances on one PC, headless: 33/33 checks (4 of them simulations: invalid token, disconnect).
  - Control Center Federation page driven through its real controls on two isolated instances with a local fixture hub and a synthetic
    credential: 33/33 (1 check not executed: failed credential, needs the real hub).
  - NOT done: the Control Center UI against the REAL GitHub hub with a repo-scoped token (needs the owner); a real expired token; a real
    network cut; a clean-machine install, upgrade over RC13, uninstall or repair of this installer; a second physical PC.
  - Not code-signed. Polling (about 8 s), not push. DEMO ONLY: not for production data.
Please report anything odd (SmartScreen, install result, the Federation page, errors in its status line, delivery time).
