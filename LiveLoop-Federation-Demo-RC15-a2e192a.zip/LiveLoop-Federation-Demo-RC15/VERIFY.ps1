# Verifies every file listed in SHA256SUMS.txt (works in Windows PowerShell 5.1 and PowerShell 7).
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$bad = 0; $n = 0
foreach ($line in Get-Content -LiteralPath (Join-Path $root 'SHA256SUMS.txt')) {
    if ($line -notmatch '^([0-9A-Fa-f]{64})\s+\*?(.+)$') { continue }
    $want = $Matches[1].ToUpper(); $rel = $Matches[2].Trim(); $p = Join-Path $root ($rel -replace '/', '\')
    $n++
    if (-not (Test-Path -LiteralPath $p)) { Write-Host "MISSING   $rel"; $bad++; continue }
    $got = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToUpper()
    if ($got -eq $want) { Write-Host "OK        $rel" } else { Write-Host "MISMATCH  $rel"; $bad++ }
}
if ($bad -eq 0) { Write-Host "`nALL $n FILES OK" -ForegroundColor Green } else { Write-Host "`n$bad PROBLEM(S) among $n files. Do not use this bundle." -ForegroundColor Red; exit 1 }
