"""RC11: the waiter reports typed presence (LISTENING with a declared interval) to the server while it runs, and says so in its
result; a failing report never ends the wait. Fully faked transport, no server."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import cooperative_wait as cw  # noqa: E402


class PresenceReporting(unittest.TestCase):
    def run_wait(self, fetch_results, call_tool_result=(None, None), timeout=5):
        calls = []

        def fake_call_tool(runtime, name, args, client_name=None, **kw):
            calls.append((name, args))
            return call_tool_result

        seq = iter(fetch_results)
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(cw.mcp_client, "call_tool", side_effect=fake_call_tool), \
                mock.patch.object(cw.mcp_client, "fetch_delta_max_seq", side_effect=lambda *a, **k: next(seq)), \
                mock.patch.object(cw.time, "sleep", lambda s: None):
            out = cw.wait_for_event(object(), "agent-a", "proj", baseline_seq=10, timeout_seconds=timeout,
                                    poll_interval_seconds=0, relationship_id="rel", heartbeat_path=Path(d) / "hb.json")
        return out, calls

    def test_listening_is_reported_with_the_declared_interval_and_event_leaves_listening(self):
        out, calls = self.run_wait([(None, None, []), (11, None, ["m1"])])
        self.assertEqual(out["state"], "EVENT_DETECTED")
        self.assertTrue(out["presence_reported"])
        first = calls[0]
        self.assertEqual(first[0], "report_presence")
        self.assertEqual(first[1]["state"], "LISTENING")
        self.assertEqual(first[1]["declared_interval_seconds"], cw.PRESENCE_INTERVAL_SECONDS)
        self.assertEqual((first[1]["project_key"], first[1]["participant"]), ("proj", "agent-a"))
        self.assertTrue(first[1]["instance_id"].startswith("cw-"))
        self.assertEqual(calls[-1][1]["state"], "WORK_PENDING", "after an event the waiter must stop claiming LISTENING")
        # one LISTENING report per interval, not one per poll
        self.assertEqual(sum(1 for n, a in calls if a["state"] == "LISTENING"), 1)

    def test_a_failing_presence_report_never_ends_the_wait_and_is_disclosed(self):
        out, calls = self.run_wait([(None, None, []), (12, None, ["m"])], call_tool_result=(None, "tool error: nope"))
        self.assertEqual(out["state"], "EVENT_DETECTED")
        self.assertFalse(out["presence_reported"])

    def test_timeout_result_says_whether_presence_was_reported(self):
        # deadline already passed: no poll, no report, honest False
        out, calls = self.run_wait([], timeout=-1)
        self.assertEqual(out["state"], "TIMEOUT")
        self.assertFalse(out["presence_reported"])
        self.assertEqual(calls, [])


if __name__ == "__main__":
    unittest.main()
