"""Tests for check_qualification_mode.py (seq380).

Plain stdlib unittest, no MCP connectivity -- pure logic, matches this
skill's existing test convention.

Run directly: python test_check_qualification_mode.py
"""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import check_qualification_mode as cqm


def write_marker(d, **fields):
    p = Path(d) / ".liveloop-qualification-mode.json"
    p.write_text(json.dumps(fields), encoding="utf-8")
    return p


VALID_FIELDS = dict(
    schema="liveloop-qualification-v1",
    project="c0-fwq-fixture",
    capability="foreground_wait",
    acknowledged_experimental=True,
    fixture_confirmed_by="coding-agent-phase1a, seq380",
)


class CheckQualificationModeTests(unittest.TestCase):
    def test_no_marker_file_is_not_armed(self):
        with tempfile.TemporaryDirectory() as d:
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_NOT_ARMED")

    def test_valid_marker_matching_project_and_capability_is_armed(self):
        with tempfile.TemporaryDirectory() as d:
            write_marker(d, **VALID_FIELDS)
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_ARMED")
        self.assertEqual(result["fixture_confirmed_by"], VALID_FIELDS["fixture_confirmed_by"])
        self.assertIn("EXPERIMENTAL", result["note"])

    def test_project_mismatch_is_never_armed(self):
        # The exact seq363/380-class defect this whole line of work guards
        # against: a marker for one project must never authorize an
        # experiment against a different one.
        with tempfile.TemporaryDirectory() as d:
            write_marker(d, **VALID_FIELDS)
            result = cqm.check(d, "some-other-project", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_PROJECT_MISMATCH")

    def test_capability_mismatch_is_never_armed(self):
        with tempfile.TemporaryDirectory() as d:
            write_marker(d, **VALID_FIELDS)
            result = cqm.check(d, "c0-fwq-fixture", "native_wake")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_CAPABILITY_MISMATCH")

    def test_wrong_schema_is_invalid(self):
        with tempfile.TemporaryDirectory() as d:
            fields = dict(VALID_FIELDS)
            fields["schema"] = "something-else"
            write_marker(d, **fields)
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_FILE_INVALID")

    def test_missing_acknowledgement_is_invalid(self):
        with tempfile.TemporaryDirectory() as d:
            fields = dict(VALID_FIELDS)
            fields["acknowledged_experimental"] = False
            write_marker(d, **fields)
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_FILE_INVALID")

    def test_missing_confirmed_by_is_invalid(self):
        with tempfile.TemporaryDirectory() as d:
            fields = dict(VALID_FIELDS)
            fields["fixture_confirmed_by"] = ""
            write_marker(d, **fields)
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_FILE_INVALID")

    def test_corrupt_file_is_invalid_not_treated_as_absent(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-qualification-mode.json"
            p.write_text("{not valid json", encoding="utf-8")
            result = cqm.check(d, "c0-fwq-fixture", "foreground_wait")
        self.assertEqual(result["state"], "QUALIFICATION_MODE_FILE_INVALID")


if __name__ == "__main__":
    unittest.main()
