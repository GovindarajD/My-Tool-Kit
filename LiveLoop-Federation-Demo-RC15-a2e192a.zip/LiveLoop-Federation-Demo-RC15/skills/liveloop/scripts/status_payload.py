"""Deterministic LIVELOOP_STATUS payload builder (seq210, REQ-44).

Constructs a schema-valid status JSON body (STATUS_SCHEMA.md) from CLI args
so the agent doesn't hand-construct JSON inconsistently across turns. Prints
the JSON string to stdout -- the calling agent passes it into its own
send_message MCP tool call directly; this script never talks to LiveLoop
itself, matching "do not duplicate governance in scripts."
"""

import argparse
import json
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--participant", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--role", required=True)
    p.add_argument("--lifecycle-state", required=True,
                    choices=["NOT_JOINED", "JOINING", "CATCHING_UP", "PROCESSING",
                             "WAIT_ARMING", "WAITING", "JOINED_ACTIVE", "EXIT_PENDING",
                             "EXITING", "EXITED", "AGENT_UNATTENDED", "HUMAN_RECOVERY_REQUIRED"])
    p.add_argument("--commitment-state", required=True, choices=["OPEN", "NONE"])
    p.add_argument("--last-seen-seq", type=int, required=True)
    p.add_argument("--reason", required=True)
    p.add_argument("--waiter-relationship-id", default=None)
    p.add_argument("--waiter-cycle", type=int, default=None)
    p.add_argument("--recovery-required", action="store_true")
    p.add_argument("--active-task-refs", nargs="*", default=[])
    p.add_argument("--exit-watermark-seq", type=int, default=None,
                    help="seq245: the max(seq) snapshot taken at exit-intent time. Only pass "
                         "this from EXIT_PENDING onward -- omit entirely otherwise.")
    p.add_argument("--qualification-experiment", default=None,
                    help="seq380: set ONLY when this status is produced under an explicit, "
                         "check_qualification_mode.py-armed experiment testing an unqualified "
                         "capability on a disposable fixture. Pass the capability name being "
                         "tested (e.g. 'foreground_wait'). Adds a self-labeling field so this "
                         "status can never be mistaken for a qualified production WAITING.")
    args = p.parse_args()

    payload = {
        "schema": "liveloop-status-v1",
        "participant": args.participant,
        "project": args.project,
        "role": args.role,
        "lifecycle_state": args.lifecycle_state,
        "commitment_state": args.commitment_state,
        "last_seen_seq": args.last_seen_seq,
        "last_transition_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "reason": args.reason,
        "recovery_required": args.recovery_required,
        "active_task_refs": args.active_task_refs,
    }
    if args.waiter_relationship_id:
        payload["waiter_relationship_id"] = args.waiter_relationship_id
    if args.waiter_cycle is not None:
        payload["waiter_cycle"] = args.waiter_cycle
    if args.exit_watermark_seq is not None:
        payload["exit_watermark_seq"] = args.exit_watermark_seq
    if args.qualification_experiment:
        payload["qualification_experiment"] = args.qualification_experiment
        payload["qualification_experiment_note"] = (
            "EXPERIMENTAL -- this capability is NOT qualified in production. This status was "
            "produced under an explicit, disposable-fixture-scoped qualification-mode drill "
            "(check_qualification_mode.py), not ordinary lifecycle behavior."
        )

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
