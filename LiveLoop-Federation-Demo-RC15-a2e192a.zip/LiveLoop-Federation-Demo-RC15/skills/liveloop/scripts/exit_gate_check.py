"""Deterministic safe-exit gate (seq210, REQ-44) -- formalizes STATE_MODEL.md's
5-point EXIT_LIVELOOP check as a pure function, so it's evaluated consistently
rather than eyeballed differently each time.

This script does NOT talk to LiveLoop or any harness -- it takes the five
booleans as input (the calling agent gathers them via its own normal tool
use: record_execution_reference already called?, any accepted in-progress
obligation?, etc.) and returns SAFE_EXIT or EXIT_PENDING with the specific
failing reasons. Pure logic only, matching "do not duplicate governance in
scripts" -- the governance judgment stays with the agent; this just makes
the gate's own arithmetic deterministic.
"""

import argparse
import json


def evaluate(evidence_recorded, no_open_commitment, approvals_represented, cursor_current, waiter_clean):
    checks = {
        "evidence_recorded": evidence_recorded,
        "no_open_commitment": no_open_commitment,
        "approvals_represented": approvals_represented,
        "cursor_current": cursor_current,
        "waiter_clean": waiter_clean,
    }
    failing = [name for name, ok in checks.items() if not ok]
    return ("SAFE_EXIT" if not failing else "EXIT_PENDING"), failing


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--evidence-recorded", type=lambda s: s.lower() == "true", required=True)
    p.add_argument("--no-open-commitment", type=lambda s: s.lower() == "true", required=True)
    p.add_argument("--approvals-represented", type=lambda s: s.lower() == "true", required=True)
    p.add_argument("--cursor-current", type=lambda s: s.lower() == "true", required=True)
    p.add_argument("--waiter-clean", type=lambda s: s.lower() == "true", required=True)
    args = p.parse_args()

    result, failing = evaluate(
        args.evidence_recorded, args.no_open_commitment,
        args.approvals_represented, args.cursor_current, args.waiter_clean,
    )
    print(json.dumps({"result": result, "failing_checks": failing}))


if __name__ == "__main__":
    main()
