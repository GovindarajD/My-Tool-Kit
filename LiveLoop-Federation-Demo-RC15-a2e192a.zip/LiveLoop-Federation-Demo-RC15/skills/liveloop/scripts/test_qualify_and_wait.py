"""Pure-logic tests for qualify_and_wait.py's control flow (seq386).

These mock out every live-server call (verify_join.verify,
check_qualification_mode.check, mcp_client calls) to test the
orchestrator's own short-circuit logic without a live server: a failed
verify must never reach the qualification check; a failed qualification
check must never reach the status publish/wait. The full, real, live-server
pipeline (verify -> qualification -> status publish -> bounded wait ->
EVENT_DETECTED) was proven end to end against the actual c0-fwq-fixture
project during development -- see the seq386 report for that transcript;
it is not re-run here since it needs a live server.

Run directly: python test_qualify_and_wait.py
"""

import io
import sys
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).parent))
import qualify_and_wait as qaw


def run_main(argv, verify_result, qual_result=None):
    with mock.patch.object(qaw.verify_join, "verify", return_value=verify_result), \
         mock.patch.object(qaw.check_qualification_mode, "check", return_value=qual_result or {}), \
         mock.patch.object(sys, "argv", ["qualify_and_wait.py"] + argv):
        buf = io.StringIO()
        try:
            with redirect_stdout(buf):
                qaw.main()
            code = 0
        except SystemExit as e:
            code = e.code
        return code, buf.getvalue()


BASE_ARGS = ["--workspace-dir", ".", "--project", "p1"]


class ShortCircuitTests(unittest.TestCase):
    def test_failed_verify_never_reaches_qualification_check(self):
        with mock.patch.object(qaw.check_qualification_mode, "check") as qual_check:
            code, out = run_main(BASE_ARGS, {"state": "ENROLLMENT_REQUIRED", "detail": "x"})
            qual_check.assert_not_called()
        self.assertNotEqual(code, 0)
        self.assertIn("ENROLLMENT_REQUIRED", out)
        self.assertIn("orchestrator_stage", out)

    def test_failed_qualification_check_never_reaches_status_publish(self):
        verify_ok = {"state": "JOIN_VERIFIED", "participant_name": "p1", "cursor_last_seen_seq": 0}
        with mock.patch.object(qaw.mcp_client, "call_tool") as call_tool:
            code, out = run_main(
                BASE_ARGS, verify_ok,
                {"state": "QUALIFICATION_MODE_NOT_ARMED", "detail": "x"},
            )
            call_tool.assert_not_called()
        self.assertNotEqual(code, 0)
        self.assertIn("QUALIFICATION_MODE_NOT_ARMED", out)

    def test_project_mismatch_qualification_result_also_short_circuits(self):
        verify_ok = {"state": "JOIN_VERIFIED", "participant_name": "p1", "cursor_last_seen_seq": 0}
        with mock.patch.object(qaw.mcp_client, "call_tool") as call_tool:
            code, out = run_main(
                BASE_ARGS, verify_ok,
                {"state": "QUALIFICATION_MODE_PROJECT_MISMATCH", "detail": "x"},
            )
            call_tool.assert_not_called()
        self.assertNotEqual(code, 0)


if __name__ == "__main__":
    unittest.main()
