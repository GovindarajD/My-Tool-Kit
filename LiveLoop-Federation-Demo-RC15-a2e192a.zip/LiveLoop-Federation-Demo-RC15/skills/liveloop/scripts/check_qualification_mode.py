"""check_qualification_mode.py -- explicit, fail-closed escape hatch for
testing an UNQUALIFIED capability on a disposable fixture only (seq377/380).

Why this exists: `CAPABILITY_HANDSHAKE.md`'s degradation rule correctly
stops `JOIN_LIVELOOP` from attempting `cooperative_wait.py` when
`foreground_wait` is not qualified for the current harness (GitHub Copilot
VS Code, at time of writing) -- that gate is working as designed, not a
bug. But qualifying a new capability requires actually *trying* it
somewhere. This script is the one, narrow, auditable way to do that: it
requires an explicit, human/architect-authored marker file naming exactly
which project this experiment is scoped to, and fails closed on anything
else -- a missing file, a project mismatch, or an unacknowledged intent are
all hard failures, never silently bypassed.

This script only ever answers "is qualification mode armed for this
project." It has no opinion on whether the resulting experiment passed --
that's `cooperative_wait.py`'s own output, evaluated separately, by a human
before any capability flag is ever changed in `CAPABILITY_HANDSHAKE.md`.
Running this script and getting `QUALIFICATION_MODE_ARMED` is never, by
itself, evidence that a capability is supported.
"""

import argparse
import json
import sys
from pathlib import Path

REQUIRED_SCHEMA = "liveloop-qualification-v1"


def check(workspace_dir, project, capability):
    marker_path = Path(workspace_dir) / ".liveloop-qualification-mode.json"
    if not marker_path.exists():
        return {
            "state": "QUALIFICATION_MODE_NOT_ARMED",
            "detail": f"no {marker_path.name} in this workspace -- qualification mode is opt-in only, "
                      "never inferred. An admin/architect must explicitly create this file naming the "
                      "exact project/capability being experimented on before an unqualified capability "
                      "may be attempted, even on a disposable fixture.",
        }
    try:
        data = json.loads(marker_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        return {"state": "QUALIFICATION_MODE_FILE_INVALID", "detail": f"{marker_path.name} exists but could not be read/parsed: {e}"}

    if data.get("schema") != REQUIRED_SCHEMA:
        return {"state": "QUALIFICATION_MODE_FILE_INVALID", "detail": f"schema must be '{REQUIRED_SCHEMA}'"}
    if not data.get("acknowledged_experimental"):
        return {"state": "QUALIFICATION_MODE_FILE_INVALID", "detail": "acknowledged_experimental must be true -- this is not an accident-proof default"}
    if not data.get("fixture_confirmed_by"):
        return {"state": "QUALIFICATION_MODE_FILE_INVALID", "detail": "fixture_confirmed_by must name who authored this marker (audit trail, not anonymous)"}

    marker_project = data.get("project")
    if marker_project != project:
        return {
            "state": "QUALIFICATION_MODE_PROJECT_MISMATCH",
            "detail": f"marker names project '{marker_project}', but this JOIN is for '{project}' -- "
                      "qualification mode never applies outside the exact project it was armed for.",
            "marker_project": marker_project, "requested_project": project,
        }

    marker_capability = data.get("capability")
    if marker_capability != capability:
        return {
            "state": "QUALIFICATION_MODE_CAPABILITY_MISMATCH",
            "detail": f"marker names capability '{marker_capability}', but '{capability}' was requested.",
            "marker_capability": marker_capability, "requested_capability": capability,
        }

    return {
        "state": "QUALIFICATION_MODE_ARMED",
        "project": project,
        "capability": capability,
        "fixture_confirmed_by": data["fixture_confirmed_by"],
        "note": "EXPERIMENTAL ONLY -- this capability remains unqualified in CAPABILITY_HANDSHAKE.md "
                "until a human reviews this experiment's real evidence and updates that file explicitly. "
                "Being QUALIFICATION_MODE_ARMED is never itself proof the capability works.",
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace-dir", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--capability", default="foreground_wait")
    args = p.parse_args()
    print(json.dumps(check(args.workspace_dir, args.project, args.capability)))


if __name__ == "__main__":
    main()
