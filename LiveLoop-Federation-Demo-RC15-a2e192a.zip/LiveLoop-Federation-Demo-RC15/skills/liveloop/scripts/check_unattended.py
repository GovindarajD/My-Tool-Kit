"""External liveness check for cooperative_wait.py (Q4; packaged into the
skill seq228, REQ-44).

Deliberately a SEPARATE process/invocation from cooperative_wait.py itself --
a waiter that has died (killed, crashed, orphaned) cannot report its own
death; only an external observer reading its last heartbeat can. This
script does exactly that and nothing else: it reads the heartbeat file
cooperative_wait.py writes on every internal poll tick and classifies
relationship state from its staleness. Unchanged from the pre-seq228
version other than its location -- it never imported wake_dispatcher or
anything else outside the standard library, so it needed no dependency fix,
only to move alongside the rest of the skill's packaged scripts.

Honesty constraint (Q4 requirement 5, explicit): this project has never
found or qualified a native, externally-triggerable wake mechanism for an
already-running interactive Claude Code session (see master plan section
25 -- the VS Code command-routing path was falsified, and the only proven
mechanisms are a direct human instruction in-chat, or the separate headless
Control Bridge, both out of scope for THIS mechanism). So AGENT_UNATTENDED
here maps directly to HUMAN_RECOVERY_REQUIRED -- it does not invent or
claim a native-wake fallback that does not exist.
"""

import argparse
import json
import time
from pathlib import Path

DEFAULT_HEARTBEAT_PATH = Path(__file__).parent / "evidence" / "cooperative_wait_heartbeat.json"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--heartbeat-path", default=str(DEFAULT_HEARTBEAT_PATH))
    p.add_argument("--grace-period-seconds", type=int, default=60,
                    help="How stale a heartbeat must be before the relationship is "
                         "classified AGENT_UNATTENDED rather than merely WAITING.")
    args = p.parse_args()

    path = Path(args.heartbeat_path)
    if not path.exists():
        print(json.dumps({"state": "NO_ACTIVE_RELATIONSHIP"}))
        return

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        # An unreadable/corrupt heartbeat is itself evidence of no live,
        # well-behaved waiter -- fail toward AGENT_UNATTENDED, not silence.
        print(json.dumps({
            "state": "AGENT_UNATTENDED",
            "recovery": "HUMAN_RECOVERY_REQUIRED",
            "detail": f"heartbeat file unreadable: {e}",
        }))
        return

    now = time.time()
    last_heartbeat_at = data.get("last_heartbeat_at", 0)
    age = now - last_heartbeat_at

    if age > args.grace_period_seconds:
        print(json.dumps({
            "state": "AGENT_UNATTENDED",
            "recovery": "HUMAN_RECOVERY_REQUIRED",
            "detail": (
                f"heartbeat stale by {age:.1f}s (grace period {args.grace_period_seconds}s). "
                "No supported native Claude wake exists for this mechanism -- the operator "
                "must type \"Continue your role.\" (or equivalent) to resume cognition."
            ),
            "relationship_id": data.get("relationship_id"),
            "cycle": data.get("cycle"),
        }))
    else:
        print(json.dumps({
            "state": "WAITING",
            "relationship_id": data.get("relationship_id"),
            "cycle": data.get("cycle"),
            "heartbeat_age_seconds": round(age, 1),
        }))


if __name__ == "__main__":
    main()
