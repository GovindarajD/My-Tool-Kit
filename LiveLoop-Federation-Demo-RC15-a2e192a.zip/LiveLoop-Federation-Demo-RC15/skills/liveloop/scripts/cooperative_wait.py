"""Cooperative same-session terminal wait (seq184/Q4; packaged into the skill
seq228, REQ-44) -- an alternative wake primitive to the external CREATE/RESUME
Control Bridge path (dev/vscode-control-bridge/), which remains a separate,
repo-development-only mechanism not part of the distributable skill.

Deterministic transport/control only: uses mcp_client.fetch_delta_max_seq (no
parallel messaging/relevance system) to detect that something new exists for
a participant, then prints one minimal, content-free line and exits. It never
reads message content and never decides anything -- the calling agent (the
same session that launched this, blocked in a foreground/background-task
wait) is responsible for fetching its own Delta and deciding
ACT/WAIT/ESCALATE/RESPOND once released, identical to every other wake path
in this project.

v2 (seq228): previously imported `wake_dispatcher` from the repo's
dev/s1.5c-wake-integration/ tree for this same fetch_delta_max_seq call and
its LL_BIN/LL_DATA_DIR constants -- an accidental dependency on the source
repository. Now uses this skill's own packaged mcp_client.py, with the
runtime descriptor (how to launch ll-mcp) resolved from the workspace's own
.mcp.json / .liveloop-setup.json / explicit overrides, exactly as
setup_liveloop.py does -- SETUP_LIVELOOP must have already run successfully
in this workspace before this script is invoked.

Q4 resilience (unchanged by this move): an ordinary transient internal poll
error/timeout is swallowed and retried with bounded backoff -- it must NOT
end this tool call. Only a genuinely irrecoverable transport failure (too
many consecutive errors) or the outer RELATIONSHIP deadline ends the wait. A
heartbeat lease file lets an external, separate check (check_unattended.py)
distinguish a live waiter from one that died uncleanly, without this process
needing to observe itself.
"""

import argparse
import json
import sys
import time
import uuid
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import mcp_client  # noqa: E402 -- packaged with this skill, no external repo path

DEFAULT_HEARTBEAT_PATH = HERE / "evidence" / "cooperative_wait_heartbeat.json"

# Bounded backoff for transient internal poll errors -- retried, never
# surfaced as an exit (Q4 requirement 1). If this many CONSECUTIVE polls
# fail, the transport is classified as genuinely broken (not transient),
# and the wait ends with FATAL_WAITER_LOST rather than silently retrying
# all the way to the relationship deadline pretending nothing is wrong.
MAX_CONSECUTIVE_POLL_ERRORS = 5


# RC11: the server-verifiable half of "I am listening". While this waiter runs it tells the server (report_presence, state
# LISTENING, declared interval 30 s -> the server treats it as stale after 90 s) so the Team page can show Listening only
# when a live waiter is actually reporting. Best effort: a failure never ends the wait (the heartbeat file and the poll are
# unchanged); the result says whether the last report succeeded.
PRESENCE_INTERVAL_SECONDS = 30


def report_presence(runtime, project, participant, instance_id, state, detail=None):
    args = {"project_key": project, "participant": participant, "instance_id": instance_id, "state": state,
            "declared_interval_seconds": PRESENCE_INTERVAL_SECONDS}
    if detail:
        args["detail"] = detail
    _result, err = mcp_client.call_tool(runtime, "report_presence", args, client_name="liveloop-cooperative-wait")
    return err is None


def write_heartbeat(path, relationship_id, cycle, budget_deadline, extra=None):
    payload = {
        "relationship_id": relationship_id,
        "cycle": cycle,
        "last_heartbeat_at": time.time(),
        "budget_deadline": budget_deadline,
    }
    if extra:
        payload.update(extra)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload), encoding="utf-8")
    except OSError:
        pass  # heartbeat write failure is itself just a missed beat, not fatal to the wait


def clear_heartbeat(path):
    try:
        if path.exists():
            path.unlink()
    except OSError:
        pass


def check_single_waiter(heartbeat_path, relationship_id, poll_interval_seconds):
    """seq464 (Stage-1 freeze, item 5): the default heartbeat path is one file
    per skill installation, not per participant/session -- a real gap found
    live this engagement (two cooperative_wait.py calls for the same
    participant were started back-to-back, cycle 81 and 82, without the first
    one's TIMEOUT/EVENT_DETECTED result being consumed first; both are
    read-only polls so no harm resulted, but nothing structurally prevented a
    genuinely harmful overlap -- e.g. two waiters racing to consume the same
    EVENT_DETECTED). This is a lightweight, best-effort guard, not a hard
    distributed lock: if a heartbeat already exists, is recent (within 3x the
    poll interval -- i.e. plausibly still alive), and belongs to a DIFFERENT
    relationship_id, refuse to start a second waiter over it. A caller that
    is genuinely re-arming its OWN relationship (same relationship_id) is
    always allowed through -- this guards against a second, distinct waiter
    starting concurrently, not against the normal TIMEOUT->re-arm cycle.
    Returns (ok: bool, detail: str | None)."""
    try:
        if not heartbeat_path.exists():
            return True, None
        existing = json.loads(heartbeat_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return True, None  # unreadable/corrupt heartbeat is not a valid reason to block a new one
    existing_rel = existing.get("relationship_id")
    if existing_rel == relationship_id:
        return True, None  # same relationship re-arming, not a second waiter
    age = time.time() - existing.get("last_heartbeat_at", 0)
    if age < poll_interval_seconds * 3:
        return False, (
            f"heartbeat at {heartbeat_path} is {age:.1f}s old (relationship_id={existing_rel!r}, "
            f"cycle={existing.get('cycle')}) -- plausibly a still-live waiter for a different "
            f"relationship; refusing to start a second one on the same heartbeat path"
        )
    return True, None  # stale heartbeat from a dead/crashed waiter -- safe to take over


def wait_for_event(runtime, participant, project, baseline_seq, timeout_seconds=1800,
                    poll_interval_seconds=10, relationship_id=None, cycle=1, heartbeat_path=None):
    """The importable core of the wait loop (seq386) -- extracted so a single
    orchestrator (e.g. qualify_and_wait.py) can perform this same bounded
    wait as one step of a larger in-process sequence, without shelling out to
    a second Python process. Returns the same result dict this script's CLI
    prints; callers that want the exact CLI behavior get it via main() below,
    unchanged."""
    relationship_id = relationship_id or str(uuid.uuid4())
    heartbeat_path = Path(heartbeat_path) if heartbeat_path else DEFAULT_HEARTBEAT_PATH
    deadline = time.time() + timeout_seconds

    consecutive_errors = 0
    last_err = None
    instance_id = f"cw-{uuid.uuid4().hex[:12]}"
    last_presence_at = 0.0
    presence_ok = False

    def result(state, **detail):
        return {"state": state, "relationship_id": relationship_id, "cycle": cycle, "presence_reported": presence_ok, **detail}

    ok, detail = check_single_waiter(heartbeat_path, relationship_id, poll_interval_seconds)
    if not ok:
        return result("SINGLE_WAITER_VIOLATION", detail=detail)

    while time.time() < deadline:
        write_heartbeat(heartbeat_path, relationship_id, cycle, deadline)
        if time.time() - last_presence_at >= PRESENCE_INTERVAL_SECONDS:
            presence_ok = report_presence(runtime, project, participant, instance_id, "LISTENING", detail=f"cooperative_wait cycle {cycle}")
            last_presence_at = time.time()

        max_seq, err, message_ids = mcp_client.fetch_delta_max_seq(runtime, participant, project)

        if err:
            # Ordinary transient error: swallowed, retried, bounded backoff --
            # does NOT end this call (Q4 requirement 1).
            consecutive_errors += 1
            last_err = err
            if consecutive_errors >= MAX_CONSECUTIVE_POLL_ERRORS:
                clear_heartbeat(heartbeat_path)
                report_presence(runtime, project, participant, instance_id, "DEGRADED", detail="waiter lost")
                return result("FATAL_WAITER_LOST", detail=f"{consecutive_errors} consecutive poll errors, last: {last_err}")
            # Bounded backoff: same fixed poll interval, capped by the
            # MAX_CONSECUTIVE_POLL_ERRORS ceiling above rather than an
            # unbounded/growing delay -- deterministic, not open-ended.
            time.sleep(poll_interval_seconds)
            continue

        consecutive_errors = 0  # a clean poll resets the error streak

        if max_seq is not None and max_seq > baseline_seq:
            clear_heartbeat(heartbeat_path)
            report_presence(runtime, project, participant, instance_id, "WORK_PENDING", detail="event detected; about to process")
            return result("EVENT_DETECTED", seq_seen=max_seq, wake_id=None)

        time.sleep(poll_interval_seconds)

    clear_heartbeat(heartbeat_path)
    return result("TIMEOUT", baseline_seq=baseline_seq)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--project", required=True)
    p.add_argument("--participant", required=True)
    p.add_argument("--baseline-seq", type=int, required=True)
    p.add_argument("--timeout-seconds", type=int, default=1800,
                    help="WAIT-SLICE deadline for this single call (seq236: product default is "
                         "1800s/30min, not a relationship-level deadline -- a joined relationship "
                         "re-arms a new slice after each TIMEOUT via SKILL.md's normal loop; "
                         "override with a short value for bounded testing). Ordinary internal "
                         "poll errors do not count against this; only elapsed wall-clock does.")
    p.add_argument("--poll-interval-seconds", type=int, default=10)
    p.add_argument("--relationship-id", default=None,
                    help="Correlates heartbeats across multiple re-armed cycles of the same "
                         "overall relationship; generated if omitted.")
    p.add_argument("--cycle", type=int, default=1)
    p.add_argument("--heartbeat-path", default=None,
                    help="Defaults to a path scoped by --project/--participant (seq464: the old "
                         "single shared-file default let two waiters for different participants "
                         "silently clobber each other's heartbeat -- see check_single_waiter()). "
                         "Pass explicitly only to intentionally share a heartbeat across calls.")
    p.add_argument("--workspace-dir", required=True,
                    help="Workspace root containing .mcp.json / .liveloop-setup.json for runtime discovery.")
    p.add_argument("--ll-bin", default=None)
    p.add_argument("--ll-data-dir", default=None)
    args = p.parse_args()

    if args.heartbeat_path is None:
        safe_project = "".join(c if c.isalnum() else "_" for c in args.project)
        safe_participant = "".join(c if c.isalnum() else "_" for c in args.participant)
        args.heartbeat_path = str(HERE / "evidence" / f"cooperative_wait_heartbeat__{safe_project}__{safe_participant}.json")

    workspace = Path(args.workspace_dir)
    try:
        runtime = mcp_client.resolve_runtime(
            mcp_json_path=workspace / ".mcp.json",
            setup_json_path=workspace / ".liveloop-setup.json",
            explicit_ll_bin=args.ll_bin,
            explicit_ll_data_dir=args.ll_data_dir,
        )
    except mcp_client.RuntimeNotFound as e:
        print(json.dumps({"state": "FATAL_WAITER_LOST", "detail": f"no runtime discoverable: {e}"}))
        return

    outcome = wait_for_event(
        runtime, args.participant, args.project, args.baseline_seq,
        timeout_seconds=args.timeout_seconds, poll_interval_seconds=args.poll_interval_seconds,
        relationship_id=args.relationship_id, cycle=args.cycle, heartbeat_path=args.heartbeat_path,
    )
    print(json.dumps(outcome), flush=True)


if __name__ == "__main__":
    main()
