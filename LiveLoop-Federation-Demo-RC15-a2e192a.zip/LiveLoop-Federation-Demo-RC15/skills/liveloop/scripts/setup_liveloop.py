"""SETUP_LIVELOOP -- discover-before-create provisioning (seq212, seq228, seq234, REQ-44).

v2 (seq228): fixed the fresh-agent acceptance failure found by testing this
skill in a genuinely clean workspace (only .claude/skills/liveloop present,
no dev/ source tree). v1 imported `wake_dispatcher` from
`dev/s1.5c-wake-integration` for MCP-subprocess plumbing and used its
hardcoded LL_BIN/LL_DATA_DIR pointing at this repo's own build -- an
accidental dependency on the LiveLoop source repository being present, which
v1 masked by asking the human to hand-write .mcp.json / copy dev files. That
violated the single-skill bootstrap invariant. Fixed by: (1) vendoring the
MCP-subprocess plumbing into this skill's own mcp_client.py (no external
import), (2) discovering the runtime descriptor (how to launch ll-mcp) from
the workspace's own .mcp.json / this workspace's persisted setup record /
explicit overrides, in that bounded order (mcp_client.resolve_runtime), and
(3) when discoverable but not yet configured in .mcp.json, WRITING the
ll-mcp entry itself (merge-safe, preserving unrelated servers, never
duplicating) instead of just reporting the gap to a human.

v3 (seq234): the LiveLoop data model is project-scoped by design (Participant
rows carry project_id, name unique per project; no cross-project membership
table exists -- confirmed by inspecting dev/contracts/CONTRACT_V1.md section
2, not invented). That means the SAME logical agent/human identity operating
in a SECOND project is a genuinely separate Participant row, discovered/
created the same way (whois-then-register_participant, already idempotent
per (project, name) at the MCP tool level). v2's `.liveloop-setup.json` was a
flat, single-project record; comparing its `participant_id` against a live
`whois` result for a DIFFERENT `--project` would false-positive an
`IDENTITY_CONFLICT` (comparing unrelated participants across projects, not a
real conflict). Fixed by keying the persisted record by project
(`{"projects": {<project>: {...}}}`), with a backward-compatible read path
for the old flat v2 file (treated as a single legacy entry for the one
project it names, never silently discarded).

Separate from JOIN_LIVELOOP: this establishes stable identity + connectivity
+ capability profile ONCE per harness/workspace (now: once per
harness/workspace/project combination); JOIN enters a relationship using
what SETUP already established.

Stable identity is persisted to `.liveloop-setup.json` in the workspace
root -- a new, narrowly-scoped file (distinct from `.liveloop-bridge.json`,
which is Control-Bridge-specific) so restarts/rejoins resolve the same
participant without re-registering. As of seq228 it also persists the
resolved `runtime` descriptor (source of truth for future setup runs in the
same workspace, per resolve_runtime's documented discovery order); as of
seq234 it can hold more than one project's entry at once.

v4 (seq306, Stage 2 C0 prep): `--participant`/`--project`/`--harness` were
CLI-required, which meant a fresh agent could only learn them from a human
telling it each time -- a real question, even in a workspace whose identity
is already known and fixed (e.g. a provisioned Stage-2 md01 participant).
Fixed by making those three args optional and, when omitted, reading them
from an optional **declarative config file**, `.liveloop-config.json`, in
the workspace root (schema `liveloop-config-v1`; see PROVISIONING.md for the
full schema, precedence rules, and the decision table for when a question is
still legitimate). This file is intentionally distinct from
`.liveloop-setup.json`: the config file is human/architect-authored,
checked into the workspace, and states *desired* identity; the setup file is
machine-generated, workspace-local, resolved state. Precedence is CLI arg >
config file > neither present. If a value is still missing after both
sources are checked, this script fails closed with `NOT_CONFIGURED` naming
exactly which field(s) are missing -- it never guesses from the workspace
folder name or any other heuristic, matching seq306 item 7. This file format
and this script are unchanged with respect to *where* the skill is packaged
(`.claude/skills/liveloop/` or `.github/skills/liveloop/`) -- both the
config file and the setup file live at the workspace root, not inside the
skill folder, so the same script resolves identically regardless of which
harness's skill-root loaded it.
"""

import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import mcp_client  # noqa: E402 -- packaged with this skill, no external repo path


def check_mcp_config(mcp_json_path):
    """Read-only check: does .mcp.json exist and contain an ll-mcp entry?"""
    p = Path(mcp_json_path)
    if not p.exists():
        return {"exists": False, "has_ll_mcp": False, "other_servers": []}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        return {"exists": True, "has_ll_mcp": False, "other_servers": [], "error": str(e)}
    servers = data.get("mcpServers", {})
    return {
        "exists": True,
        "has_ll_mcp": "ll-mcp" in servers,
        "other_servers": [k for k in servers if k != "ll-mcp"],
    }


def load_setup_record(setup_path):
    """Load `.liveloop-setup.json`, migrating an old flat v2 (single-project)
    record into the v3 (`{"projects": {<project>: {...}}}`) shape in memory
    (seq234). Never writes during migration -- the caller's normal
    SETUP_READY write path persists the v3 shape once this project's setup
    actually succeeds; an untouched second project's entry in an
    already-v3 file is preserved as-is. Returns {} if the file doesn't exist
    or is corrupt (corrupt is treated as "start fresh," matching v2's prior
    behavior of falling through to live discovery)."""
    if not setup_path.exists():
        return {}
    try:
        data = json.loads(setup_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if "projects" in data:
        return data  # already v3
    if "project" in data and "participant_id" in data:
        # Legacy flat v2 record -- wrap it as this one project's entry
        # rather than discarding it silently.
        legacy_project = data["project"]
        return {
            "schema": data.get("schema", "liveloop-setup-v2"),
            "mcp_config_path": data.get("mcp_config_path"),
            "runtime": data.get("runtime"),
            "projects": {
                legacy_project: {
                    "participant_id": data.get("participant_id"),
                    "participant_name": data.get("participant_name"),
                    "harness": data.get("harness"),
                    "capabilities": data.get("capabilities", {}),
                    "setup_at": data.get("setup_at"),
                    "setup_state": data.get("setup_state", "SETUP_READY"),
                }
            },
        }
    return {}  # unrecognized shape -- treat as absent rather than guess


def load_desired_config(config_path):
    """Read the optional declarative `.liveloop-config.json` (seq306,
    schema `liveloop-config-v1`). Returns (config: dict|None, error: str|None).
    A missing file is not an error (config: None, error: None) -- absence
    simply means CLI args are the only source. A present-but-corrupt/
    unparseable file IS an error (returned explicitly, never silently
    treated as absent) so a broken config is reported rather than masked by
    silently falling through to CLI-required behavior."""
    p = Path(config_path)
    if not p.exists():
        return None, None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        return None, f"{config_path} exists but could not be read/parsed: {e}"
    if not isinstance(data, dict):
        return None, f"{config_path} does not contain a JSON object"
    return data, None


def resolve_identity_args(args, config):
    """Precedence: CLI arg > declarative config file value > missing.
    Never infers from the workspace folder name or any other heuristic
    (seq306 item 7) -- a value absent from both sources stays missing and is
    reported as such by the caller. Returns (resolved: dict, missing: list[str])."""
    fields = ("participant", "project", "harness")
    resolved = {}
    missing = []
    for field in fields:
        cli_value = getattr(args, field)
        if cli_value is not None:
            resolved[field] = cli_value
        elif config is not None and config.get(field):
            resolved[field] = config[field]
        else:
            missing.append(field)
    return resolved, missing


def write_ll_mcp_entry(mcp_json_path, runtime):
    """Merge-safe write of the ll-mcp entry (seq228 item B4): preserves any
    existing file's other servers/settings untouched, never duplicates
    ll-mcp, creates the file only if it genuinely doesn't exist yet. Returns
    (written: bool, detail: str)."""
    p = Path(mcp_json_path)
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            return False, f"existing .mcp.json is unreadable/corrupt, refusing to overwrite: {e}"
    else:
        data = {}
    servers = data.setdefault("mcpServers", {})
    if "ll-mcp" in servers:
        return False, "ll-mcp entry already present (should have been detected by check_mcp_config)"
    servers["ll-mcp"] = {"command": runtime.command, "args": runtime.args}
    try:
        p.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as e:
        return False, f"could not write .mcp.json: {e}"
    return True, f"wrote ll-mcp entry (source: {runtime.source})"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--participant", default=None,
                    help="Overrides .liveloop-config.json's participant field when given. "
                         "If omitted, read from that file; if absent from both, SETUP fails "
                         "closed with NOT_CONFIGURED.")
    p.add_argument("--project", default=None,
                    help="Overrides .liveloop-config.json's project field when given.")
    p.add_argument("--harness", default=None,
                    help="Overrides .liveloop-config.json's harness field when given.")
    p.add_argument("--workspace-dir", required=True)
    p.add_argument("--foreground-wait-capable", action="store_true")
    p.add_argument("--native-wake-capable", action="store_true")
    p.add_argument("--ll-bin", default=None,
                    help="Explicit override: path to the ll.exe/ll binary (last-resort discovery source).")
    p.add_argument("--ll-data-dir", default=None,
                    help="Explicit override: LiveLoop data directory (paired with --ll-bin).")
    args = p.parse_args()

    workspace = Path(args.workspace_dir)
    setup_path = workspace / ".liveloop-setup.json"
    mcp_path = workspace / ".mcp.json"
    config_path = workspace / ".liveloop-config.json"

    # 0. Resolve identity args: CLI > declarative config file > missing
    # (seq306). Done before any other step so a NOT_CONFIGURED workspace
    # fails closed immediately, without a partial .mcp.json provisioning
    # attempt first.
    desired_config, config_err = load_desired_config(config_path)
    if config_err:
        print(json.dumps({"state": "SETUP_FAILED", "detail": config_err}))
        return
    resolved, missing = resolve_identity_args(args, desired_config)
    if missing:
        print(json.dumps({
            "state": "NOT_CONFIGURED",
            "detail": f"missing required field(s) not given via CLI arg and not found in "
                      f"{config_path} (if present): {', '.join(missing)}. This script never "
                      "infers identity from the workspace folder name or any other heuristic; "
                      "either pass the missing CLI arg(s) or add them to .liveloop-config.json.",
            "missing_fields": missing,
            "config_file_present": desired_config is not None,
        }))
        return
    args.participant, args.project, args.harness = (
        resolved["participant"], resolved["project"], resolved["harness"],
    )

    # 1. Preflight: MCP config check (read-only).
    mcp_status = check_mcp_config(mcp_path)

    if not mcp_status["has_ll_mcp"]:
        # seq228 item B: don't just report the gap -- try to discover a
        # runtime and provision it ourselves before falling back to asking
        # a human for a path.
        try:
            runtime = mcp_client.resolve_runtime(
                mcp_json_path=mcp_path if mcp_status["exists"] else None,
                setup_json_path=setup_path,
                explicit_ll_bin=args.ll_bin,
                explicit_ll_data_dir=args.ll_data_dir,
            )
        except mcp_client.RuntimeNotFound as e:
            print(json.dumps({
                "state": "LIVELOOP_RUNTIME_NOT_FOUND",
                "detail": str(e),
                "mcp_status": mcp_status,
            }))
            return

        written, detail = write_ll_mcp_entry(mcp_path, runtime)
        if not written:
            print(json.dumps({
                "state": "SETUP_FAILED",
                "detail": f"discovered a runtime but could not provision .mcp.json: {detail}",
                "runtime": runtime.to_dict(),
            }))
            return

        print(json.dumps({
            "state": "SETUP_RESTART_REQUIRED",
            "detail": f"{detail}; the harness must reload .mcp.json for the ll-mcp entry to "
                      "take effect (edits to a live session's config never apply in place) -- "
                      "restart, then re-run SETUP_LIVELOOP.",
            "runtime": runtime.to_dict(),
            "mcp_status": mcp_status,
        }))
        return

    # has_ll_mcp -- resolve the same runtime descriptor from the now-present
    # config for the connectivity checks below.
    runtime = mcp_client._from_mcp_json(mcp_path)
    if runtime is None:
        print(json.dumps({
            "state": "SETUP_FAILED",
            "detail": ".mcp.json reports an ll-mcp entry but it could not be parsed back out",
            "mcp_status": mcp_status,
        }))
        return

    # 2. Discover-before-create: local record first, then live whois.
    # seq234: the local record is now keyed by project (v3) -- only THIS
    # project's own entry is ever compared against a live whois for THIS
    # project, so a second project's identity can never false-positive an
    # IDENTITY_CONFLICT against an unrelated participant from a different
    # project (see module docstring). load_setup_record/project entries
    # below handle the backward-compatible read of an old flat v2 file.
    full_record = load_setup_record(setup_path)
    local_entry = full_record.get("projects", {}).get(args.project)

    live, err = mcp_client.whois(runtime, args.participant, args.project)
    if err:
        print(json.dumps({"state": "SETUP_FAILED", "detail": err}))
        return

    if local_entry and live:
        if local_entry.get("participant_id") != live.get("id"):
            print(json.dumps({
                "state": "IDENTITY_CONFLICT",
                "detail": "local .liveloop-setup.json entry for this project does not match live whois id",
                "project": args.project,
                "local_id": local_entry.get("participant_id"), "live_id": live.get("id"),
                "recovery": "HUMAN_RESOLUTION_REQUIRED",
            }))
            return
        # Idempotent: same identity, nothing to change.
        participant_id = live["id"]
        outcome = "REUSED"
    elif live:
        # Registered previously (e.g. by another process, or a prior setup
        # for this same project) but no local entry for THIS project --
        # recover it. A local entry existing for a DIFFERENT project is
        # irrelevant here and never consulted.
        participant_id = live["id"]
        outcome = "RECOVERED"
    else:
        # Not found anywhere. Pre-seq315: this script reported NOT_REGISTERED
        # and told the calling agent to call register_participant itself.
        # register_participant is now admin-gated (seq315/seq319, P0 security
        # fix -- see dev/contracts/AGENT_ENROLLMENT_DESIGN.md); a normal
        # agent has no admin_token and must never attempt it. The only
        # legitimate path is claim_enrollment with a token an admin already
        # issued and delivered via .liveloop-config.json's optional
        # `enrollment_token` field.
        enrollment_token = (desired_config or {}).get("enrollment_token")
        if not enrollment_token:
            print(json.dumps({
                "state": "ENROLLMENT_REQUIRED",
                "detail": "no existing participant found and no enrollment_token in "
                          f"{config_path} -- an admin must issue an invite (create_enrollment) "
                          "and deliver its one-time token via that file's enrollment_token "
                          "field. This script never calls register_participant itself; that "
                          "tool is admin-gated bootstrap only (seq315).",
            }))
            return

        claimed, claim_err = mcp_client.claim_enrollment(
            runtime, enrollment_token, args.project, args.participant,
            role=(desired_config or {}).get("role"),
        )
        if claim_err:
            state = "SETUP_FAILED"
            for marker in ("ENROLLMENT_EXPIRED", "ENROLLMENT_REPLAYED", "ENROLLMENT_MISMATCH"):
                if marker in claim_err:
                    state = marker
                    break
            print(json.dumps({"state": state, "detail": claim_err}))
            return

        # Success: consume the token so a stale copy of this file can never
        # be replayed (seq315 item -- single-use in practice, not just in
        # the server's bookkeeping). Never leave a reusable secret sitting in
        # a checked-in file after it has served its purpose.
        if desired_config is not None and "enrollment_token" in desired_config:
            desired_config = dict(desired_config)
            del desired_config["enrollment_token"]
            try:
                config_path.write_text(json.dumps(desired_config, indent=2), encoding="utf-8")
            except OSError:
                pass  # best-effort redaction; claim already succeeded server-side

        participant_id = claimed["id"]
        outcome = "CLAIMED"

    capabilities = {
        "communication": True,
        "foreground_wait": args.foreground_wait_capable,
        "native_wake": args.native_wake_capable,
    }
    full_record["schema"] = "liveloop-setup-v3"
    full_record["mcp_config_path"] = str(mcp_path)
    full_record["runtime"] = runtime.to_dict()  # shared across all projects in this workspace
    full_record.setdefault("projects", {})[args.project] = {
        "participant_id": participant_id,
        "participant_name": args.participant,
        "harness": args.harness,
        "capabilities": capabilities,
        "setup_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "setup_state": "SETUP_READY",
    }
    setup_path.write_text(json.dumps(full_record, indent=2), encoding="utf-8")

    print(json.dumps({
        "state": "SETUP_READY",
        "outcome": outcome,
        "participant_id": participant_id,
        "capabilities": capabilities,
        "mcp_status": mcp_status,
    }))


if __name__ == "__main__":
    main()
