"""Human attention projection -- compact, vendor-neutral event blocks (seq245/253/255/259/260/262/266/270/283/288, REQ-44).

Problem this solves: in agent transcripts, meaningful LiveLoop relationship/work/control
transitions get lost among Bash/MCP/tool-call noise. This script does NOT talk to LiveLoop and
holds no state (matching "do not duplicate governance in scripts") -- it takes one event's
minimal fields and prints ONE compact block to stdout. The calling agent includes that block
verbatim in its own chat reply for the current turn. This works in any harness without any
VS Code/IDE dependency, because it is just text the agent's own reply already contains -- not
a UI feature. The VS Code Control Bridge's optional status-bar projection (--evidence-path)
is deferred/optional tooling outside this skill (see DEPARTURE_AND_ATTENTION_DESIGN.md B2);
the Markdown path below is the actual, required, portable attention mechanism.

Only high-signal events are accepted (the --event choices below) -- ambient mechanics (poll,
heartbeat, cursor update, SILENT_IDLE, a plain wait re-arm) have no corresponding --event
value, so there is no way to accidentally render a block for them; this is enforced by there
being no such choice, not by convention alone.

seq259 (attention UX refinement, live-visible PASS confirmed by the human owner) restructured
this into three pieces, per instruction:
1. AttentionEvent -- a plain data model (this script's own dataclass), carrying no rendering
   logic. Renderers consume it; they never redefine what an event IS.
2. Renderers -- render_markdown() (native Markdown/blockquote, the default and only REQUIRED
   path -- no ANSI, no terminal box-drawing, safe for any chat/Markdown host) and
   render_rich() (an OPTIONAL prototype for terminal/CLI hosts specifically, using the `rich`
   library -- guarded import, never a hard dependency; falls back to render_markdown() if
   `rich` isn't installed or --renderer rich wasn't explicitly requested).
3. Severity -- three tiers (AMBIENT is never reachable here by construction -- see above;
   INFORMATIONAL and ATTENTION_REQUIRED are the two this script actually renders, each with
   its own visual weight in both renderers).

seq260 added an optional LiveContext live-status footer (Link/Work/State); seq262 refined the
card layout from real screenshot feedback (heading stands alone, display aliases, truncation).

seq266/270: a design-first self-review (dev/skills/liveloop/design/UX_REVIEW.md) found this
script's own output was being duplicated by its CALLER -- the printed block re-pasted a second
time into the calling agent's own prose. That is a calling-convention fix (SKILL.md's "Human
attention projection" section: call this exactly once, never re-paste its output), not
something this script itself can enforce. What this script *did* gain from that review: a
second icon axis (EVENT_TYPE_ICONS, keyed by event rather than severity) so a scanning human
can tell "a task arrived" from "a result landed" from "something needs attention" by shape,
layered on top of the existing, unchanged severity-based blockquote logic -- severity still
decides quoting; the event type now also decides the glyph.

seq283/288: a follow-up self-review found the durable LIVELOOP_STATUS record (built by
status_payload.py, sent as plain JSON) had never been given a human-facing projection at all --
only the smaller set of discrete "event" types (WORK_RECEIVED, RESULT, etc.) had cards. seq288
closes that gap by extending EVENT_LABELS/EVENT_SEVERITY/EVENT_TYPE_ICONS with the durable
status vocabulary itself (JOINING, CATCHING_UP, PROCESSING, WAIT_ARMING, WAITING,
HUMAN_RECOVERY_REQUIRED) -- zero new rendering code, the exact same AttentionEvent/LiveContext/
render_markdown/render_rich machinery, one semantic model rather than a parallel card system.
The durable status message itself is unchanged and still raw JSON on purpose (see
DEPARTURE_AND_ATTENTION_DESIGN.md's B1c three-layer ownership boundary: host-owned MCP evidence
/ durable LiveLoop status / human projection -- three distinct layers, never conflated).

seq300 (final UX refinement, freezing this area absent a functional defect): after seeing the
real live WAITING card, the human owner found routine healthy-state cards too verbose --
mechanics were correct, presentation was not glanceable. Resolved by tying card DENSITY to the
severity axis that already exists, rather than adding a third dimension: every
INFORMATIONAL-severity event now renders as ONE compact line (icon + "LiveLoop · LABEL" + an
em-dash + a short subject -- the caller's own --detail if given, else a built-in default per
event type from EVENT_DEFAULT_SUBJECT); `LiveContext` is accepted but NOT rendered in compact
mode at all -- diagnostic Link/Work/State detail stays available in the durable LIVELOOP_STATUS
JSON and MCP/tool evidence, never deleted, just not repeated in the routine human projection
(item 4's explicit instruction). ATTENTION_REQUIRED events are completely unchanged: full
multi-line card, blockquote, Link/Work/State footer when context is given -- exactly the v9
format, since that's precisely where the human said the detail is actually needed.
"""

import argparse
import json
import sys
import time
from dataclasses import dataclass
from typing import Optional

# Windows consoles commonly default to a legacy codepage (cp1252) that can't
# encode the emoji used below, raising UnicodeEncodeError on plain print().
# Reconfigure stdout to UTF-8 explicitly rather than dropping the icons --
# they're the point of a compact, scannable block. Python 3.7+'s
# TextIOWrapper.reconfigure; guarded since some non-standard stdio wrappers
# (rare, but seen in embedded/harness contexts) may not implement it.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except AttributeError:
    pass

INFORMATIONAL = "INFORMATIONAL"
ATTENTION_REQUIRED = "ATTENTION_REQUIRED"

EVENT_LABELS = {
    "JOINED": "Joined",
    "WORK_RECEIVED": "Work received",
    "APPROVAL_REQUIRED": "Approval required",
    "RESULT": "Result",
    "HANDOFF_REQUESTED": "Handoff requested",
    "HANDOFF_ACCEPTED": "Handoff accepted",
    "EXIT_ACCEPTED": "Exit accepted",
    "EXIT_PENDING": "Exit pending",
    "EXITED": "Exited",
    "AGENT_UNATTENDED": "Agent unattended",
    # seq288 (UX closure): human-projection labels for durable LIVELOOP_STATUS
    # lifecycle states that previously had no attention-card representation
    # at all (STATUS_SCHEMA.md's own vocabulary -- JOINING/CATCHING_UP/
    # PROCESSING/WAIT_ARMING/WAITING/HUMAN_RECOVERY_REQUIRED). Same
    # AttentionEvent/LiveContext/render_markdown/render_rich machinery,
    # zero new rendering code -- one semantic projection model, per
    # instruction not to build a parallel card system.
    "JOINING": "Joining",
    "CATCHING_UP": "Catching up",
    "PROCESSING": "Processing",
    "WAIT_ARMING": "Wait arming",
    "WAITING": "Waiting",
    "HUMAN_RECOVERY_REQUIRED": "Human recovery required",
}

# The severity mapping IS the "high-signal vs ambient" policy made concrete
# for the two tiers this script ever renders (seq245's original ambient
# exclusion -- poll/heartbeat/cursor/SILENT_IDLE/re-arm -- remains enforced
# by those event names simply not existing in EVENT_LABELS at all, so
# AMBIENT never reaches a renderer here; it is listed for completeness of
# the taxonomy the directive asked for, not because this script emits it).
# seq288: WAIT_ARMING/WAITING/CATCHING_UP/PROCESSING/JOINING are status-
# projection types, not automatically emitted on every transition -- exactly
# like every other event type in this script, the CALLING AGENT decides when
# a transition is human-relevant enough to project (e.g. first entry into
# WAITING after a JOIN) versus an ordinary re-arm that stays silent (no new
# heuristic invented here; SKILL.md's existing "agent decides relevance"
# discipline, unchanged, now just has cards available for these states too).
EVENT_SEVERITY = {
    "JOINED": INFORMATIONAL,
    "WORK_RECEIVED": INFORMATIONAL,
    "APPROVAL_REQUIRED": ATTENTION_REQUIRED,
    "RESULT": INFORMATIONAL,
    "HANDOFF_REQUESTED": INFORMATIONAL,
    "HANDOFF_ACCEPTED": INFORMATIONAL,
    "EXIT_ACCEPTED": INFORMATIONAL,
    "EXIT_PENDING": ATTENTION_REQUIRED,
    "EXITED": INFORMATIONAL,
    "AGENT_UNATTENDED": ATTENTION_REQUIRED,
    "JOINING": INFORMATIONAL,
    "CATCHING_UP": INFORMATIONAL,
    "PROCESSING": INFORMATIONAL,
    "WAIT_ARMING": INFORMATIONAL,
    "WAITING": INFORMATIONAL,
    "HUMAN_RECOVERY_REQUIRED": ATTENTION_REQUIRED,
}

# seq266/270 (design proposal -> approved production change): a second icon
# axis, layered on top of EVENT_SEVERITY rather than replacing it -- severity
# still controls blockquote-wrapping (see render_markdown/render_rich); this
# lets a scanning human tell "a task arrived" from "a result landed" from
# "something needs attention" by shape, not just by reading the label text.
# Plain Unicode glyphs only, matching seq262's own already-approved icons --
# no new font/emoji dependency, no variation selectors.
EVENT_TYPE_ICONS = {
    "JOINED": "◉",
    "WORK_RECEIVED": "◉",
    "RESULT": "✓",
    "APPROVAL_REQUIRED": "⚠",
    "HANDOFF_REQUESTED": "⇄",
    "HANDOFF_ACCEPTED": "⇄",
    "EXIT_ACCEPTED": "◉",
    "EXIT_PENDING": "⚠",
    "EXITED": "✓",
    "AGENT_UNATTENDED": "⚠",
    # seq288: status-projection icons. A pending/waiting/working family (◌)
    # distinct from the "activity/success" family (◉/✓) above, so a scanning
    # human can tell "the relationship is idling/listening" from "something
    # actually happened" at a glance -- the whole point of adding these.
    "JOINING": "◉",
    "CATCHING_UP": "◌",
    "PROCESSING": "◌",
    "WAIT_ARMING": "◌",
    "WAITING": "◌",
    "HUMAN_RECOVERY_REQUIRED": "⚠",
}

# seq300: built-in short subjects for compact INFORMATIONAL cards, used only
# when the caller doesn't pass --detail. Every INFORMATIONAL event has one --
# ATTENTION_REQUIRED events don't need this (they render expanded, always
# with their own --detail as the actionable reason, per SKILL.md).
EVENT_DEFAULT_SUBJECT = {
    "JOINED": "Joined and listening",
    "WORK_RECEIVED": "New work received",
    "RESULT": "Complete",
    "HANDOFF_REQUESTED": "Handoff requested",
    "HANDOFF_ACCEPTED": "Handoff accepted",
    "EXIT_ACCEPTED": "Exit accepted",
    "EXITED": "Exited",
    "JOINING": "Joining",
    "CATCHING_UP": "Catching up",
    "PROCESSING": "Processing",
    "WAIT_ARMING": "Arming wait",
    "WAITING": "Listening for next event",
}


@dataclass
class AttentionEvent:
    """Plain data -- no rendering logic here. `event` must be a key of
    EVENT_LABELS (enforced by argparse's --event choices before this is
    constructed)."""
    event: str
    participant: str
    project: str
    seq: Optional[int] = None
    detail: Optional[str] = None

    @property
    def label(self):
        return EVENT_LABELS[self.event]

    @property
    def severity(self):
        return EVENT_SEVERITY[self.event]


TOP_OBJECT_TYPES = ("TASK", "APPROVAL", "HANDOFF", "EXIT", "RESULT", "CONTROL")


@dataclass
class LiveContext:
    """seq260: a second, optional layer under the event card -- what the
    relationship/work/listening state looks like AT RENDER TIME, per the
    three-axes model from STATE_MODEL.md (seq236): relationship membership
    (`link`), work commitment (`commitment_state`, `top_object_*`), and
    listening state (`state`, `cursor_seq`). Every field is optional and
    caller-supplied -- this script makes no MCP calls, so it can only ever
    render what the caller already knows; a missing field is omitted from
    its row entirely, never guessed or defaulted to a placeholder (seq260
    requirement 4: "never inferred")."""
    link: Optional[str] = None               # relationship membership, e.g. "JOINED", "EXIT_PENDING"
    relationship_id: Optional[str] = None
    counterpart: Optional[str] = None        # the specific external participant relevant to THIS event
    top_object_type: Optional[str] = None    # one of TOP_OBJECT_TYPES
    top_object_ref: Optional[str] = None     # short ref/subject for the top object
    commitment_state: Optional[str] = None   # "OPEN" / "NONE"
    state: Optional[str] = None              # listening/processing axis, e.g. "PROCESSING", "WAITING"
    cursor_seq: Optional[int] = None
    waiter_cycle: Optional[int] = None

    def is_empty(self):
        return not any([self.link, self.relationship_id, self.counterpart, self.top_object_type,
                         self.top_object_ref, self.commitment_state, self.state,
                         self.cursor_seq is not None, self.waiter_cycle is not None])

    def rows(self, self_alias=None, code=lambda s: s):
        """Up to 3 compact rows (seq260 requirement 3; seq262 visual
        refinement), each included only if it has at least one real field --
        never a placeholder row for entirely-absent data.

        `self_alias` (seq262): the rendering agent's own display alias, used
        only for the Link row's `counterpart <-> self` arrow -- LiveContext
        itself has no notion of "self," so this stays a rendering-time
        parameter rather than a stored field (the dataclass would otherwise
        need to duplicate AttentionEvent.participant).
        `code`: wraps a state token for inline-code display in Markdown
        (backticks) or is a no-op identity function for renderers that don't
        want that (e.g. render_rich, which uses its own styling instead)."""
        out = []

        if self.link:
            link_value = code(self.link)
            if self.counterpart and self_alias:
                link_value += f" · {_display_alias(self.counterpart)} ↔ {self_alias}"
            elif self_alias:
                link_value += f" · {self_alias}"
            out.append(("Link", link_value))

        work_bits = []
        if self.top_object_type:
            obj = code(self.top_object_type)
            if self.top_object_ref:
                obj += f" · {_truncate(self.top_object_ref, 40)}"
            work_bits.append(obj)
        if self.commitment_state:
            work_bits.append(f"commitment {code(self.commitment_state)}")
        if work_bits:
            out.append(("Work", " · ".join(work_bits)))

        state_bits = []
        if self.state:
            state_bits.append(code(self.state))
        if self.cursor_seq is not None:
            state_bits.append(f"cursor {self.cursor_seq}")
        if self.waiter_cycle is not None:
            state_bits.append(f"cycle {self.waiter_cycle}")
        if state_bits:
            out.append(("State", " · ".join(state_bits)))

        return out


def _display_alias(name):
    """seq262: a safe, short display form for a participant name -- strips a
    common 'liveloop-' prefix if present (e.g. 'liveloop-architect-01' ->
    'architect-01'), otherwise returns the name unchanged. This affects
    DISPLAY only; every internal field (AttentionEvent.participant,
    LiveContext.counterpart, the --evidence-path JSON record) still stores
    the canonical name exactly as given -- never mutated, never looked up
    against a registry (this script makes no MCP calls)."""
    if name and name.startswith("liveloop-"):
        return name[len("liveloop-"):]
    return name


def _truncate(text, max_len):
    """seq262 requirement 7: safely truncate long text rather than letting a
    verbose --detail/--top-object-ref blow out the card's line budget."""
    if text and len(text) > max_len:
        return text[: max_len - 1].rstrip() + "…"
    return text


def render_markdown(evt, context=None):
    """The required, portable renderer -- plain Markdown, no ANSI, no box-
    drawing.

    seq300 (final refinement): density now follows severity, the axis that
    already existed -- no third dimension added.

    INFORMATIONAL -> exactly ONE line:
        {icon} LiveLoop · {LABEL} — {subject}
    `context` is accepted (for call-site uniformity) but deliberately NOT
    rendered here -- diagnostic Link/Work/State detail stays in the durable
    LIVELOOP_STATUS JSON and MCP evidence, never in the routine card (item 4
    of the seq300 directive: hidden from the projection, not deleted).
    `subject` is the caller's own --detail if given (truncated as before),
    else EVENT_DEFAULT_SUBJECT[evt.event].

    ATTENTION_REQUIRED -> unchanged from seq262/v9's expanded, multi-line,
    blockquoted card (heading stands alone, italic detail, Link/Work/State
    footer when context is given) -- this is deliberately where the detail
    stays, per the human's own instruction that this is where it's needed."""
    icon = EVENT_TYPE_ICONS[evt.event]

    if evt.severity == INFORMATIONAL:
        subject = _truncate(evt.detail, 100) if evt.detail else EVENT_DEFAULT_SUBJECT[evt.event]
        return f"{icon} LiveLoop · {evt.label.upper()} — {subject}"

    # ATTENTION_REQUIRED: full expanded card, unchanged from v9.
    lines = [f"**{icon} LiveLoop · {evt.label.upper()}**"]
    if evt.detail:
        lines.append(f"*{_truncate(evt.detail, 100)}*")

    have_context = bool(context) and not context.is_empty()
    if have_context:
        self_alias = _display_alias(evt.participant)
        rows = context.rows(self_alias=self_alias, code=lambda s: f"`{s}`")
        if rows:
            lines.append("---")
            for label, value in rows:
                lines.append(f"**{label}** {value}")
    else:
        # No context supplied -- identity has nowhere else to live.
        identity_parts = [evt.participant, evt.project]
        if evt.seq is not None:
            identity_parts.append(f"seq{evt.seq}")
        lines.append(" · ".join(identity_parts))

    # The whole card -- heading, detail, and footer -- stays inside one
    # consistent blockquote, so the actionable reason and live context
    # read as a single unit rather than a mixed quoted/unquoted card.
    return "\n".join(f"> {l}" for l in lines)


def render_rich(evt, context=None):
    """OPTIONAL prototype renderer for terminal/CLI hosts specifically
    (seq259). Guarded import -- `rich` is never a hard dependency of this
    skill or of LiveLoop participation; if it isn't installed, or a caller
    asks for it without having it, this falls back to render_markdown()
    automatically rather than erroring. When available, renders a Panel
    whose border style reflects severity (info vs warning), rendered to a
    string via a Console captured in-memory (no direct terminal write here
    -- this script's job is producing text for the caller to place, not
    owning stdout). seq260: same optional LiveContext footer as
    render_markdown(), rendered as extra lines inside the same panel."""
    try:
        import io
        from rich.console import Console
        from rich.panel import Panel
        from rich.text import Text
    except ImportError:
        return render_markdown(evt, context)

    # file=io.StringIO() is deliberate -- Console defaults `file` to real
    # stdout when left as None, which would print directly here AND get
    # printed again by main()'s own print() of this function's return value
    # (a real double-output bug caught during qualification). Capturing into
    # an in-memory buffer keeps this function a pure string-producer, like
    # render_markdown() above, with no direct terminal write of its own.
    buf = io.StringIO()
    console = Console(file=buf, width=72, force_terminal=True, color_system="standard")

    if evt.severity == INFORMATIONAL:
        # seq300: same one-line compactness as render_markdown -- no panel/
        # border for routine states, just a single styled line.
        subject = _truncate(evt.detail, 100) if evt.detail else EVENT_DEFAULT_SUBJECT[evt.event]
        line = f"{EVENT_TYPE_ICONS[evt.event]} LiveLoop · {evt.label.upper()} — {subject}"
        console.print(Text(line, style="cyan"))
        return buf.getvalue().rstrip("\n")

    # ATTENTION_REQUIRED: unchanged expanded panel.
    title = f"{EVENT_TYPE_ICONS[evt.event]} LiveLoop · {evt.label.upper()}"
    body_lines = []
    if evt.detail:
        body_lines.append(_truncate(evt.detail, 100))

    have_context = bool(context) and not context.is_empty()
    if have_context:
        self_alias = _display_alias(evt.participant)
        rows = context.rows(self_alias=self_alias)  # code=identity (no backticks in a Rich panel)
        if rows:
            body_lines.append("─" * 24)
            for label, value in rows:
                body_lines.append(f"{label}: {value}")
    else:
        identity_parts = [evt.participant, evt.project]
        if evt.seq is not None:
            identity_parts.append(f"seq{evt.seq}")
        body_lines.append(" · ".join(identity_parts))
    text = Text("\n".join(body_lines))

    console.print(Panel(text, title=title, border_style="yellow", expand=False))
    return buf.getvalue().rstrip("\n")


RENDERERS = {"markdown": render_markdown, "rich": render_rich}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--event", required=True, choices=list(EVENT_LABELS.keys()))
    p.add_argument("--participant", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--detail", default=None, help="One short human-readable line of context.")
    p.add_argument("--seq", type=int, default=None)
    p.add_argument("--renderer", default="markdown", choices=list(RENDERERS.keys()),
                    help="'markdown' (default, required/portable path) or 'rich' (optional "
                         "terminal prototype -- falls back to markdown automatically if the "
                         "`rich` package isn't installed).")
    p.add_argument("--evidence-path", default=None,
                    help="Optional: also append this event as JSON to this file, for the "
                         "separate, deferred VS Code Control Bridge status-bar projection.")
    # seq260: LiveContext -- all optional, all caller-supplied (this script
    # makes no MCP calls of its own, per its own design principle), omitted
    # from the rendered footer entirely when not passed.
    p.add_argument("--link", default=None, help="Relationship membership at render time, e.g. JOINED, EXIT_PENDING.")
    p.add_argument("--relationship-id", default=None)
    p.add_argument("--counterpart", default=None, help="The specific external participant relevant to this event.")
    p.add_argument("--top-object-type", default=None, choices=list(TOP_OBJECT_TYPES))
    p.add_argument("--top-object-ref", default=None)
    p.add_argument("--live-commitment-state", default=None, choices=["OPEN", "NONE"],
                    help="Distinct from any --detail wording -- the LiveContext footer's own commitment field.")
    p.add_argument("--state", default=None, help="Listening/processing axis at render time, e.g. PROCESSING, WAITING.")
    p.add_argument("--cursor-seq", type=int, default=None)
    p.add_argument("--waiter-cycle", type=int, default=None)
    args = p.parse_args()

    evt = AttentionEvent(event=args.event, participant=args.participant, project=args.project,
                          seq=args.seq, detail=args.detail)
    context = LiveContext(
        link=args.link, relationship_id=args.relationship_id, counterpart=args.counterpart,
        top_object_type=args.top_object_type, top_object_ref=args.top_object_ref,
        commitment_state=args.live_commitment_state, state=args.state,
        cursor_seq=args.cursor_seq, waiter_cycle=args.waiter_cycle,
    )
    print(RENDERERS[args.renderer](evt, context))

    if args.evidence_path:
        from pathlib import Path
        record = {
            "event": evt.event, "participant": evt.participant, "project": evt.project,
            "detail": evt.detail, "seq": evt.seq, "severity": evt.severity,
            "logged_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        try:
            path = Path(args.evidence_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except OSError:
            pass  # evidence-file write failure never blocks the primary output


if __name__ == "__main__":
    main()
