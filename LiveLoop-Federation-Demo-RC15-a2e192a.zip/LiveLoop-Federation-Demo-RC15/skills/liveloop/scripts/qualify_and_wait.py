"""qualify_and_wait.py -- single-tool-call qualification orchestrator (seq386).

Why this exists: three real retests (seq377/383/386) all showed the same
failure shape against GitHub Copilot VS Code -- a turn that ran
`verify_join.py`, reported the receipt in prose, and ended there, never
reaching `LIVELOOP_CATCHUP`, the qualification-mode check, or a wait. A
documentation fix (seq383, explicit "this is one continuous procedure"
framing) did not change the observed behavior on retest. The working theory
is that each intermediate prose "reply" the multi-step procedure asked for
was itself read by the host/model as a natural place to end the turn.

This script removes that opportunity by collapsing verify -> qualification
check -> experimental status publish -> bounded wait into ONE tool
invocation. The calling agent still only gets to see the result after this
single call returns -- there is no intermediate point where it is asked to
produce prose and then decide whether to continue. All the same fail-closed
authority checks from `verify_join.py` and `check_qualification_mode.py`
still run, unchanged, inside this one call -- nothing about the security
posture is relaxed to make this easier to invoke.

This is a disposable-fixture qualification tool, not a production
lifecycle primitive: it performs LiveLoop writes itself (publishing the
experimental status message) rather than leaving that to the calling
agent's own `send_message` call, which every other script in this package
deliberately avoids (see `status_payload.py`'s own docstring, "this script
never talks to LiveLoop itself"). That's a narrow, explicit, justified
exception for this one measurement harness -- not a new pattern for
production scripts to follow.

Being reachable by this script is never itself evidence a capability works.
`CAPABILITY_HANDSHAKE.md` is only ever updated by a human reviewing the
real result this call returns.
"""

import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import mcp_client  # noqa: E402
import verify_join  # noqa: E402
import check_qualification_mode  # noqa: E402
import cooperative_wait  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace-dir", required=True)
    p.add_argument("--project", required=True)
    p.add_argument("--participant", default=None,
                    help="Overrides the stored setup record's participant_name. If omitted, "
                         "read from .liveloop-setup.json's entry for --project, same as verify_join.py.")
    p.add_argument("--capability", default="foreground_wait")
    p.add_argument("--timeout-seconds", type=int, default=300,
                    help="Bounded wait-slice for this experiment. Default 300s (5 min), short "
                         "for a disposable qualification drill -- override for a longer window.")
    p.add_argument("--poll-interval-seconds", type=int, default=10)
    p.add_argument("--relationship-id", default=None)
    p.add_argument("--cycle", type=int, default=1)
    args = p.parse_args()

    def out(result):
        print(json.dumps(result, indent=2))
        return result

    # Step 1: machine-verified JOIN, exactly as verify_join.py's own CLI
    # would run it -- same authority, same fail states, same fail-closed
    # behavior. Any non-JOIN_VERIFIED result stops here.
    verify_result = verify_join.verify(args.workspace_dir, args.project, args.participant)
    if verify_result["state"] != "JOIN_VERIFIED":
        out({"orchestrator_stage": "verify", **verify_result})
        sys.exit(1)

    participant_name = verify_result["participant_name"]

    # Step 2: qualification-mode gate, exactly as check_qualification_mode.py's
    # own CLI would run it -- an unarmed or mismatched marker stops here,
    # regardless of how clean step 1's result was.
    qual_result = check_qualification_mode.check(args.workspace_dir, args.project, args.capability)
    if qual_result["state"] != "QUALIFICATION_MODE_ARMED":
        out({"orchestrator_stage": "qualification_check", "verify": verify_result, **qual_result})
        sys.exit(1)

    # Step 3: publish the self-labeled experimental status message. This is
    # the one place this script performs a LiveLoop write itself -- see
    # module docstring for why that's a deliberate, narrow exception here.
    workspace = Path(args.workspace_dir)
    runtime = mcp_client._from_mcp_json(workspace / ".mcp.json") or mcp_client._from_setup_record(workspace / ".liveloop-setup.json")
    if runtime is None:
        out({"orchestrator_stage": "status_publish", "verify": verify_result, "qualification": qual_result,
             "state": "SERVER_VERIFICATION_FAILED", "detail": "no runtime descriptor resolvable"})
        sys.exit(1)

    status_payload = {
        "schema": "liveloop-status-v1",
        "participant": participant_name,
        "project": args.project,
        "role": "qualification-probe",
        "lifecycle_state": "WAIT_ARMING",
        "commitment_state": "NONE",
        "last_seen_seq": verify_result.get("cursor_last_seen_seq"),
        "last_transition_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "reason": f"qualify_and_wait.py experiment for capability '{args.capability}'",
        "recovery_required": False,
        "active_task_refs": [],
        "qualification_experiment": args.capability,
        "qualification_experiment_note": (
            "EXPERIMENTAL -- this capability is NOT qualified in production. This status was "
            "produced by qualify_and_wait.py's single-tool-call orchestrator, not ordinary "
            "lifecycle behavior."
        ),
    }
    status_msg, status_err = mcp_client.call_tool(
        runtime, "send_message",
        {"project_key": args.project, "from": participant_name, "to": [participant_name],
         "subject": "LIVELOOP_STATUS", "body_md": json.dumps(status_payload),
         "directive": "INFORMATION_ONLY"},
        client_name="qualify-and-wait",
    )
    if status_err:
        out({"orchestrator_stage": "status_publish", "verify": verify_result, "qualification": qual_result,
             "state": "SERVER_VERIFICATION_FAILED", "detail": status_err})
        sys.exit(1)

    baseline_seq = status_msg["message"]["seq"] if status_msg and "message" in status_msg else verify_result.get("cursor_last_seen_seq", 0)

    # Step 4: the bounded wait itself, exactly cooperative_wait.py's own
    # logic (Q4 resilience unchanged -- transient poll errors swallowed and
    # retried, only a genuinely broken transport or the timeout ends this).
    wait_result = cooperative_wait.wait_for_event(
        runtime, participant_name, args.project, baseline_seq,
        timeout_seconds=args.timeout_seconds, poll_interval_seconds=args.poll_interval_seconds,
        relationship_id=args.relationship_id, cycle=args.cycle,
    )

    out({
        "orchestrator_stage": "complete",
        "verify": verify_result,
        "qualification": qual_result,
        "status_message_seq": baseline_seq,
        "wait": wait_result,
    })
    if wait_result["state"] not in ("EVENT_DETECTED", "TIMEOUT"):
        sys.exit(1)


if __name__ == "__main__":
    main()
