"""Focused tests for setup_liveloop.py's declarative-config resolution (seq306).

Plain stdlib unittest, no test framework dependency, no MCP connectivity --
matches this skill's existing convention of dependency-free scripts. These
tests cover the pure logic added in v4 (config loading, CLI/config
precedence, fail-closed NOT_CONFIGURED); the full zero-question SETUP_READY
path and skill-root portability (.claude/skills vs .github/skills) were
qualified live against a disposable fixture project and a real ll-mcp
runtime, recorded in the master plan rather than re-run here (they need a
live MCP server, which this file intentionally does not depend on).

Run directly: python test_setup_liveloop.py
"""

import argparse
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import setup_liveloop as sl


def _args(participant=None, project=None, harness=None):
    return argparse.Namespace(participant=participant, project=project, harness=harness)


class LoadDesiredConfigTests(unittest.TestCase):
    def test_missing_file_is_not_an_error(self):
        with tempfile.TemporaryDirectory() as d:
            config, err = sl.load_desired_config(Path(d) / ".liveloop-config.json")
        self.assertIsNone(config)
        self.assertIsNone(err)

    def test_valid_config_loads(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-config.json"
            p.write_text(json.dumps({
                "schema": "liveloop-config-v1",
                "project": "p1", "participant": "a1", "harness": "claude-code",
            }), encoding="utf-8")
            config, err = sl.load_desired_config(p)
        self.assertIsNone(err)
        self.assertEqual(config["project"], "p1")

    def test_corrupt_file_is_an_explicit_error_not_treated_as_absent(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-config.json"
            p.write_text("{not valid json", encoding="utf-8")
            config, err = sl.load_desired_config(p)
        self.assertIsNone(config)
        self.assertIsNotNone(err)
        self.assertIn("could not be read/parsed", err)

    def test_non_object_json_is_an_error(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-config.json"
            p.write_text("[1, 2, 3]", encoding="utf-8")
            config, err = sl.load_desired_config(p)
        self.assertIsNone(config)
        self.assertIsNotNone(err)


class ResolveIdentityArgsTests(unittest.TestCase):
    def test_cli_args_alone_resolve_with_no_config(self):
        resolved, missing = sl.resolve_identity_args(
            _args("a1", "p1", "claude-code"), None)
        self.assertEqual(missing, [])
        self.assertEqual(resolved, {"participant": "a1", "project": "p1", "harness": "claude-code"})

    def test_config_alone_resolves_with_no_cli_args(self):
        config = {"project": "p1", "participant": "a1", "harness": "claude-code"}
        resolved, missing = sl.resolve_identity_args(_args(), config)
        self.assertEqual(missing, [])
        self.assertEqual(resolved, {"participant": "a1", "project": "p1", "harness": "claude-code"})

    def test_cli_arg_takes_precedence_over_config(self):
        config = {"project": "p1", "participant": "a1", "harness": "claude-code"}
        resolved, missing = sl.resolve_identity_args(_args(harness="copilot"), config)
        self.assertEqual(missing, [])
        self.assertEqual(resolved["harness"], "copilot")
        self.assertEqual(resolved["participant"], "a1")

    def test_missing_field_in_both_sources_is_reported_fail_closed(self):
        config = {"project": "p1", "participant": "a1"}  # no harness
        resolved, missing = sl.resolve_identity_args(_args(), config)
        self.assertEqual(missing, ["harness"])

    def test_no_config_and_no_cli_args_reports_all_three_missing(self):
        resolved, missing = sl.resolve_identity_args(_args(), None)
        self.assertEqual(set(missing), {"participant", "project", "harness"})

    def test_never_infers_from_anything_but_the_two_named_sources(self):
        # A config file with an unrelated extra field (e.g. a stray "role" or
        # "workspace_hint") must not leak into identity resolution -- only
        # the three named fields are ever consulted (seq306 item 7).
        config = {"project": "p1", "participant": "a1", "harness": "claude-code",
                  "role": "coding-agent", "workspace_hint": "should-be-ignored"}
        resolved, missing = sl.resolve_identity_args(_args(), config)
        self.assertEqual(missing, [])
        self.assertEqual(set(resolved.keys()), {"participant", "project", "harness"})

    def test_enrollment_token_field_is_ignored_by_identity_resolution(self):
        # seq315: enrollment_token is a separate, orthogonal field -- present
        # or absent, it must never satisfy/interfere with the three identity
        # fields' own resolution.
        config = {"project": "p1", "participant": "a1", "harness": "claude-code",
                  "enrollment_token": "deadbeef"}
        resolved, missing = sl.resolve_identity_args(_args(), config)
        self.assertEqual(missing, [])
        self.assertNotIn("enrollment_token", resolved)

    def test_empty_string_config_value_is_treated_as_missing(self):
        # A blank field in a committed config file is not a valid value --
        # must fail closed like a wholly absent field, never silently pass
        # an empty string through as if it were configured.
        config = {"project": "p1", "participant": "", "harness": "claude-code"}
        resolved, missing = sl.resolve_identity_args(_args(), config)
        self.assertEqual(missing, ["participant"])


if __name__ == "__main__":
    unittest.main()
