"""Internal, packaged MCP stdio client for the liveloop skill (seq228, REQ-44).

Fix for the fresh-agent acceptance failure (seq228): the skill's own helper
scripts previously imported `wake_dispatcher` from `dev/s1.5c-wake-integration`
for exactly this MCP-subprocess plumbing (initialize/tools-call/timeout-bounded
readline) and for the `LL_BIN`/`LL_DATA_DIR` constants, which pointed at THIS
repository's own build. That made the skill silently depend on the LiveLoop
source repository being present, which a fresh distributed copy of just the
skill folder does not have. This module vendors the same proven plumbing
(the request/response shape and timeout handling are carried over unchanged --
not reinvented) so the skill has zero import dependency outside itself.

Runtime discovery (seq228 item B): rather than hardcoding a binary/data-dir
path, this module resolves "how do I start the ll-mcp server" from the same
place a harness itself would -- the workspace's `.mcp.json` `ll-mcp` entry --
falling back to explicit overrides only when that entry doesn't exist yet
(the exact case SETUP_LIVELOOP is trying to establish). See `resolve_runtime()`.
"""

import json
import os
import queue
import subprocess
import threading
import time
from pathlib import Path

MCP_CALL_TIMEOUT_SECONDS = 30


class McpCallTimeout(Exception):
    pass


class RuntimeNotFound(Exception):
    """No discoverable way to start the ll-mcp server (seq228 item B7)."""


def _readline_with_timeout(proc, timeout_seconds):
    """Bounded readline -- `Popen.stdout.readline()` has no built-in timeout
    and would otherwise block indefinitely if the child never responds.
    Carried over verbatim from the previously-external wake_dispatcher.py
    (same proven behavior, now packaged inside the skill)."""
    q = queue.Queue(maxsize=1)

    def _reader():
        try:
            q.put(proc.stdout.readline())
        except Exception as e:  # pipe closed, process killed, etc.
            q.put(e)

    t = threading.Thread(target=_reader, daemon=True)
    t.start()
    try:
        result = q.get(timeout=timeout_seconds)
    except queue.Empty:
        raise McpCallTimeout(f"no response within {timeout_seconds}s")
    if isinstance(result, Exception):
        raise result
    return result


class RuntimeDescriptor:
    """How to launch the ll-mcp server: a command + args list, exactly the
    shape a `.mcp.json` `mcpServers` entry already uses. Kept as a small
    dataclass-like object (not just a tuple) so `resolve_runtime`'s callers
    can report *where* the descriptor came from, for honest SETUP reporting."""

    def __init__(self, command, args, source):
        self.command = command
        self.args = args or []
        self.source = source  # e.g. "mcp_json", "env", "explicit", "setup_record"

    def as_popen_args(self):
        return [self.command] + list(self.args)

    def to_dict(self):
        return {"command": self.command, "args": self.args, "source": self.source}


def _from_mcp_json(mcp_json_path):
    p = Path(mcp_json_path)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    entry = data.get("mcpServers", {}).get("ll-mcp")
    if not entry or "command" not in entry:
        return None
    return RuntimeDescriptor(entry["command"], entry.get("args", []), "mcp_json")


def _from_setup_record(setup_json_path):
    p = Path(setup_json_path)
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    runtime = data.get("runtime")
    if not runtime or "command" not in runtime:
        return None
    return RuntimeDescriptor(runtime["command"], runtime.get("args", []), "setup_record")


def _from_env():
    ll_bin = os.environ.get("LL_BIN")
    ll_data_dir = os.environ.get("LL_DATA_DIR")
    if not ll_bin or not ll_data_dir:
        return None
    return RuntimeDescriptor(ll_bin, ["mcp", "--data-dir", ll_data_dir], "env")


def resolve_runtime(mcp_json_path=None, setup_json_path=None, explicit_ll_bin=None, explicit_ll_data_dir=None):
    """Discover how to launch the ll-mcp server, in the bounded, documented
    order required by seq228 item B2/B3: an already-working workspace MCP
    config first (it is definitionally correct, since the harness itself
    would use it), then this workspace's own persisted setup record (a prior
    successful resolution, so a second SETUP_LIVELOOP run in the same
    workspace does not need to re-ask), then explicit overrides. This never
    scans the filesystem/machine outside these named, bounded locations.

    Returns a RuntimeDescriptor, or raises RuntimeNotFound naming exactly
    which of the bounded sources were checked (seq228 item B7 -- this must
    identify a legitimate installation/config prerequisite, never instruct
    copying source-repo files)."""
    if explicit_ll_bin and explicit_ll_data_dir:
        return RuntimeDescriptor(explicit_ll_bin, ["mcp", "--data-dir", explicit_ll_data_dir], "explicit")

    checked = []
    if mcp_json_path is not None:
        checked.append(str(mcp_json_path))
        d = _from_mcp_json(mcp_json_path)
        if d:
            return d
    if setup_json_path is not None:
        checked.append(str(setup_json_path))
        d = _from_setup_record(setup_json_path)
        if d:
            return d
    checked.append("environment variables LL_BIN + LL_DATA_DIR")
    d = _from_env()
    if d:
        return d

    raise RuntimeNotFound(
        "No LiveLoop runtime descriptor discoverable. Checked (in order): "
        + "; ".join(checked)
        + ". Legitimate prerequisite: install the LiveLoop runtime and either "
        "(a) configure this workspace's .mcp.json ll-mcp entry yourself, or "
        "(b) set LL_BIN and LL_DATA_DIR environment variables, or "
        "(c) pass --ll-bin/--ll-data-dir explicitly."
    )


def call_tool(runtime, tool_name, arguments, client_name="liveloop-skill", timeout_seconds=MCP_CALL_TIMEOUT_SECONDS):
    """Spawn the ll-mcp server per `runtime`, perform the MCP handshake, call
    exactly one tool, and tear the process down. One-shot -- callers needing
    multiple calls in the same session should extend this, not multiply
    subprocess spawns per call; the current callers (whois checks, single
    fetch_delta polls) are each already one-shot by nature so this matches
    them without new complexity.

    Returns (result_dict_or_None, error_string_or_None)."""
    proc = subprocess.Popen(
        runtime.as_popen_args(),
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1,
    )
    try:
        def req(m):
            proc.stdin.write(json.dumps(m) + "\n")
            proc.stdin.flush()
            return json.loads(_readline_with_timeout(proc, timeout_seconds))

        req({"jsonrpc": "2.0", "id": 0, "method": "initialize", "params": {
            "protocolVersion": "2024-11-05", "capabilities": {},
            "clientInfo": {"name": client_name, "version": "1.0.0"},
        }})
        proc.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n")
        proc.stdin.flush()

        resp = req({
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        })
        if "error" in resp:
            return None, f"jsonrpc error: {resp['error']}"
        result = resp.get("result", {})
        if result.get("isError"):
            return None, f"tool error: {result['content'][0]['text']}"
        content = result["content"][0]["text"]
        return json.loads(content), None
    except McpCallTimeout as e:
        return None, f"MCP call timed out: {e}"
    finally:
        proc.stdin.close()
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def whois(runtime, participant_name, project_key):
    """Read-only connectivity + identity check. Returns (participant_dict_or_None, err).
    err is None both on success and on a genuine "not found" (that is a
    normal outcome for discover-before-create, not a connectivity error)."""
    result, err = call_tool(runtime, "whois", {"project_key": project_key, "name": participant_name},
                             client_name="liveloop-setup")
    if err:
        if "no participant named" in err.lower() or "not found" in err.lower():
            return None, None
        return None, err
    return result, None


def claim_enrollment(runtime, token, project_key, participant_name, role=None):
    """Claim an invite-kind enrollment (seq315/seq319) -- the normal agent
    onboarding path, replacing what used to be a direct register_participant
    self-call. Returns (participant_dict_or_None, err). err is None only on
    success; a denial (ENROLLMENT_REQUIRED/EXPIRED/REPLAYED/MISMATCH) comes
    back as a non-None err string that setup_liveloop.py classifies by
    prefix -- never silently retried as if it were a transient failure."""
    args = {"token": token, "project_key": project_key, "participant_name": participant_name}
    if role:
        args["role"] = role
    result, err = call_tool(runtime, "claim_enrollment", args, client_name="liveloop-setup")
    return result, err


def fetch_delta_max_seq(runtime, participant, project_key):
    """Returns (max_seq, err, message_ids) for this participant -- identical
    semantics to the previously-external wake_dispatcher.fetch_delta_max_seq
    (see that module's own docstring, carried over here verbatim): derived
    ONLY from the delta's `messages` list, never from cursor.last_seen_seq,
    to avoid the deterministic echo-wake finding that motivated this rule
    originally."""
    result, err = call_tool(runtime, "fetch_delta", {"participant": participant, "project_key": project_key},
                             client_name="liveloop-cooperative-wait")
    if err:
        return None, err, []
    messages = result.get("messages", [])
    if not messages:
        return None, None, []
    max_seq = max(m["message"]["seq"] for m in messages)
    ids = [m["message"]["id"] for m in messages]
    return max_seq, None, ids


def get_message_recipients(runtime, message_id):
    result, err = call_tool(runtime, "get_message_recipients", {"message_id": message_id},
                             client_name="liveloop-verify")
    if err:
        return None, err
    return result, None
