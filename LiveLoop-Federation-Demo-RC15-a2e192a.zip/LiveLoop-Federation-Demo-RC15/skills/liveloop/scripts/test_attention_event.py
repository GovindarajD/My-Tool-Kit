"""Focused tests for attention_event.py's renderers (seq259, REQ-44).

Plain stdlib unittest, no test framework dependency -- run directly:
    python test_attention_event.py
Matches this skill's existing convention of dependency-free scripts.
"""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import attention_event as ae


class SeverityTaxonomyTests(unittest.TestCase):
    def test_every_labeled_event_has_a_severity(self):
        for event in ae.EVENT_LABELS:
            self.assertIn(event, ae.EVENT_SEVERITY)

    def test_ambient_events_have_no_event_choice_at_all(self):
        # Enforced by construction, not convention: these must not appear as
        # keys anywhere, so there is no way to accidentally render them.
        for ambient in ("POLL", "HEARTBEAT", "CURSOR_UPDATE", "SILENT_IDLE", "REARM", "TIMEOUT"):
            self.assertNotIn(ambient, ae.EVENT_LABELS)

    def test_attention_required_events_are_the_expected_set(self):
        attention_required = {e for e, s in ae.EVENT_SEVERITY.items() if s == ae.ATTENTION_REQUIRED}
        self.assertEqual(attention_required,
                          {"APPROVAL_REQUIRED", "EXIT_PENDING", "AGENT_UNATTENDED", "HUMAN_RECOVERY_REQUIRED"})

    def test_status_projection_events_exist_and_are_informational(self):
        # seq288: the new durable-status projection types, all INFORMATIONAL
        # except the already-attention-required recovery state.
        for event in ("JOINING", "CATCHING_UP", "PROCESSING", "WAIT_ARMING", "WAITING"):
            self.assertIn(event, ae.EVENT_LABELS)
            self.assertEqual(ae.EVENT_SEVERITY[event], ae.INFORMATIONAL)
        self.assertEqual(ae.EVENT_SEVERITY["HUMAN_RECOVERY_REQUIRED"], ae.ATTENTION_REQUIRED)


class MarkdownRendererTests(unittest.TestCase):
    def test_informational_is_one_compact_line(self):
        # seq300: INFORMATIONAL events collapse to exactly one line, no
        # blockquote, no bold markup, no separate detail line.
        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", seq=5, detail="d")
        out = ae.render_markdown(evt)
        self.assertEqual(len(out.splitlines()), 1)
        self.assertNotIn(">", out)
        self.assertNotIn("**", out)
        self.assertEqual(out, f"{ae.EVENT_TYPE_ICONS['RESULT']} LiveLoop · RESULT — d")

    def test_informational_uses_default_subject_without_detail(self):
        evt = ae.AttentionEvent(event="WAITING", participant="p", project="proj")
        out = ae.render_markdown(evt)
        self.assertEqual(out, f"{ae.EVENT_TYPE_ICONS['WAITING']} LiveLoop · WAITING — Listening for next event")

    def test_every_default_subject_covers_every_informational_event(self):
        for event, severity in ae.EVENT_SEVERITY.items():
            if severity == ae.INFORMATIONAL:
                self.assertIn(event, ae.EVENT_DEFAULT_SUBJECT)

    def test_informational_ignores_context_entirely(self):
        # seq300 item 1/4: Link/Work/State never appear in the routine
        # projection, even if the caller passes a full LiveContext -- the
        # diagnostic detail stays in durable status/MCP evidence, not here.
        evt = ae.AttentionEvent(event="WORK_RECEIVED", participant="p", project="proj", detail="d")
        ctx = ae.LiveContext(link="JOINED", counterpart="architect-01", state="PROCESSING", cursor_seq=1)
        with_ctx = ae.render_markdown(evt, ctx)
        without_ctx = ae.render_markdown(evt, None)
        self.assertEqual(with_ctx, without_ctx)
        self.assertNotIn("architect-01", with_ctx)
        self.assertNotIn("Link", with_ctx)

    def test_attention_required_uses_blockquote_and_icon(self):
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="p", project="proj", seq=6, detail="d")
        out = ae.render_markdown(evt)
        self.assertTrue(out.startswith("> "))
        self.assertIn(ae.EVENT_TYPE_ICONS["EXIT_PENDING"], out)

    def test_every_event_has_a_type_icon(self):
        # seq270: the new per-event-type icon axis must cover every event
        # this script accepts, with no fallback/placeholder icon anywhere.
        for event in ae.EVENT_LABELS:
            self.assertIn(event, ae.EVENT_TYPE_ICONS)

    def test_type_icons_distinguish_result_from_work_received(self):
        # The whole point of the seq270 icon axis: same INFORMATIONAL
        # severity, visibly different icons (success vs activity).
        self.assertNotEqual(ae.EVENT_TYPE_ICONS["RESULT"], ae.EVENT_TYPE_ICONS["WORK_RECEIVED"])

    def test_heading_stands_alone_no_concatenation(self):
        # seq262: heading must not concatenate participant/project/seq/detail.
        evt = ae.AttentionEvent(event="WORK_RECEIVED", participant="coding-agent-phase1a",
                                 project="liveloop", seq=260, detail="Attention UX enhancement")
        out = ae.render_markdown(evt)
        heading = out.splitlines()[0]
        self.assertNotIn("coding-agent-phase1a", heading)
        self.assertNotIn("liveloop", heading)
        self.assertNotIn("260", heading)

    def test_detail_is_italic_on_its_own_line(self):
        # ATTENTION_REQUIRED only -- INFORMATIONAL's compact one-liner has no
        # separate italic detail line (see test_informational_is_one_compact_line).
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="p", project="proj", detail="a detail")
        out = ae.render_markdown(evt)
        self.assertIn("*a detail*", out)

    def test_long_detail_is_truncated(self):
        long_text = "x" * 200
        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", detail=long_text)
        out = ae.render_markdown(evt)
        self.assertNotIn(long_text, out)
        self.assertIn("…", out)

    def test_display_alias_strips_liveloop_prefix(self):
        self.assertEqual(ae._display_alias("liveloop-architect-01"), "architect-01")
        self.assertEqual(ae._display_alias("coding-agent-phase1a"), "coding-agent-phase1a")

    def test_link_row_shows_counterpart_arrow_self(self):
        # ATTENTION_REQUIRED only -- INFORMATIONAL ignores context entirely
        # (see test_informational_ignores_context_entirely).
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="coding-agent-phase1a", project="liveloop", detail="d")
        ctx = ae.LiveContext(link="JOINED", counterpart="liveloop-architect-01")
        out = ae.render_markdown(evt, ctx)
        self.assertIn("architect-01 ↔ coding-agent-phase1a", out)

    def test_normal_informational_card_is_at_most_six_lines(self):
        evt = ae.AttentionEvent(event="WORK_RECEIVED", participant="coding-agent-phase1a",
                                 project="liveloop", detail="Attention UX enhancement")
        ctx = ae.LiveContext(link="JOINED", counterpart="liveloop-architect-01",
                              top_object_type="TASK", top_object_ref="seq260",
                              commitment_state="OPEN", state="PROCESSING", cursor_seq=260)
        out = ae.render_markdown(evt, ctx)
        self.assertLessEqual(len(out.splitlines()), 6)

    def test_no_field_duplication(self):
        # seq259's own complaint: seq shown twice. ATTENTION_REQUIRED only --
        # INFORMATIONAL's compact one-liner doesn't show seq at all unless
        # it's part of the caller's own --detail text (not this script's
        # concern; verified separately that the renderer itself never adds it).
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="p", project="proj", seq=255, detail="detail text")
        out = ae.render_markdown(evt)
        self.assertEqual(out.count("255"), 1)

    def test_informational_never_adds_seq_on_its_own(self):
        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", seq=255, detail="detail text")
        out = ae.render_markdown(evt)
        self.assertNotIn("255", out)

    def test_no_seq_line_when_seq_is_none(self):
        evt = ae.AttentionEvent(event="JOINED", participant="p", project="proj", seq=None, detail=None)
        out = ae.render_markdown(evt)
        self.assertNotIn("seq", out.lower())

    def test_no_ansi_escapes(self):
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="p", project="proj", seq=1, detail="d")
        out = ae.render_markdown(evt)
        self.assertNotIn("\x1b[", out)


class LiveContextTests(unittest.TestCase):
    def test_empty_context_renders_no_footer(self):
        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", seq=5)
        ctx = ae.LiveContext()
        self.assertTrue(ctx.is_empty())
        out = ae.render_markdown(evt, ctx)
        self.assertEqual(out, ae.render_markdown(evt, None))

    def test_missing_fields_are_omitted_not_placeheld(self):
        # Only `state` provided -- Link and Work rows must not appear at all.
        ctx = ae.LiveContext(state="WAITING")
        rows = ctx.rows()
        self.assertEqual([label for label, _ in rows], ["State"])
        self.assertNotIn("None", rows[0][1])

    def test_full_context_produces_exactly_three_rows(self):
        ctx = ae.LiveContext(link="JOINED", counterpart="architect-01",
                              top_object_type="TASK", top_object_ref="seq260",
                              commitment_state="OPEN", state="PROCESSING", cursor_seq=260)
        rows = ctx.rows()
        self.assertEqual([label for label, _ in rows], ["Link", "Work", "State"])

    def test_each_top_object_type_renders(self):
        for obj_type in ae.TOP_OBJECT_TYPES:
            ctx = ae.LiveContext(top_object_type=obj_type, top_object_ref="ref")
            rows = ctx.rows()
            self.assertEqual(len(rows), 1)
            self.assertIn(obj_type, rows[0][1])

    def test_attention_required_with_context_stays_fully_quoted(self):
        evt = ae.AttentionEvent(event="EXIT_PENDING", participant="p", project="proj", seq=6, detail="d")
        ctx = ae.LiveContext(link="EXIT_PENDING", top_object_type="HANDOFF", top_object_ref="Task A")
        out = ae.render_markdown(evt, ctx)
        for line in out.splitlines():
            self.assertTrue(line.startswith(">"))

    def test_no_footer_separator_without_context(self):
        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", seq=5)
        out = ae.render_markdown(evt, None)
        self.assertNotIn("---", out)

    def test_stale_or_none_values_never_appear_as_text(self):
        ctx = ae.LiveContext(link=None, counterpart=None, cursor_seq=None)
        self.assertEqual(ctx.rows(), [])


class MirrorParityTests(unittest.TestCase):
    def test_dev_and_claude_mirrors_are_byte_identical(self):
        here = Path(__file__).resolve()
        # This file lives at either dev/skills/liveloop/scripts/ or
        # .claude/skills/liveloop/scripts/ -- locate its counterpart and
        # diff the actual attention_event.py module, not this test file
        # (avoids a false failure while this very test is being authored
        # in only one of the two locations mid-edit).
        skill_root = here.parent.parent
        if "dev" in skill_root.parts:
            other_root = Path(str(skill_root).replace(
                str(Path("dev") / "skills" / "liveloop"), str(Path(".claude") / "skills" / "liveloop")))
        else:
            other_root = Path(str(skill_root).replace(
                str(Path(".claude") / "skills" / "liveloop"), str(Path("dev") / "skills" / "liveloop")))
        other_module = other_root / "scripts" / "attention_event.py"
        if not other_module.exists():
            self.skipTest(f"counterpart mirror not found at {other_module} -- run after both are synced")
        this_module = skill_root / "scripts" / "attention_event.py"
        self.assertEqual(this_module.read_bytes(), other_module.read_bytes())


class RichRendererFallbackTests(unittest.TestCase):
    def test_falls_back_to_markdown_when_rich_unavailable(self):
        """rich is not a dependency of this environment by default (verified
        during seq259 qualification: installed temporarily to prototype,
        then uninstalled). This test simulates that exact absence via a
        meta_path blocker, rather than assuming the ambient environment's
        installed-package state, so it is deterministic either way."""
        import builtins
        real_import = builtins.__import__

        def blocking_import(name, *args, **kwargs):
            if name == "rich" or name.startswith("rich."):
                raise ImportError(f"{name} blocked for fallback test")
            return real_import(name, *args, **kwargs)

        evt = ae.AttentionEvent(event="RESULT", participant="p", project="proj", seq=5, detail="d")
        builtins.__import__ = blocking_import
        try:
            out = ae.render_rich(evt)
        finally:
            builtins.__import__ = real_import
        # Fell back to the markdown renderer's exact output.
        self.assertEqual(out, ae.render_markdown(evt))


if __name__ == "__main__":
    unittest.main()
