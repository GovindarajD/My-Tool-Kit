"""Regression test for status_payload.py's accepted lifecycle states.

Real-world defect (found live, 2026-09-27, first genuine degraded-harness
JOIN in this project's history): `JOINED_ACTIVE` is a documented required
status (CAPABILITY_HANDSHAKE.md, SKILL.md's JOIN_LIVELOOP step 6) for a
harness without `foreground_wait`, but `status_payload.py`'s
`--lifecycle-state` choices never included it -- the script rejected the
one call the instructions require for exactly this case, forcing the
calling agent to hand-construct the JSON instead (the thing this script
exists to prevent). Fixed by adding it to the choices list; this test pins
that fix and guards every other currently-accepted state against a future
accidental removal.

Run directly: python test_status_payload.py
"""

import json
import subprocess
import sys
import unittest
from pathlib import Path

SCRIPT = str(Path(__file__).parent / "status_payload.py")

ALL_STATES = [
    "NOT_JOINED", "JOINING", "CATCHING_UP", "PROCESSING", "WAIT_ARMING",
    "WAITING", "JOINED_ACTIVE", "EXIT_PENDING", "EXITING", "EXITED",
    "AGENT_UNATTENDED", "HUMAN_RECOVERY_REQUIRED",
]


def run(lifecycle_state):
    return subprocess.run(
        [sys.executable, SCRIPT,
         "--participant", "p1", "--project", "proj", "--role", "coding-agent",
         "--lifecycle-state", lifecycle_state, "--commitment-state", "NONE",
         "--last-seen-seq", "1", "--reason", "test"],
        capture_output=True, text=True,
    )


class LifecycleStateChoicesTests(unittest.TestCase):
    def test_every_documented_state_is_accepted(self):
        for state in ALL_STATES:
            with self.subTest(state=state):
                proc = run(state)
                self.assertEqual(proc.returncode, 0, proc.stderr)
                payload = json.loads(proc.stdout)
                self.assertEqual(payload["lifecycle_state"], state)

    def test_joined_active_specifically_is_accepted(self):
        # Pins the exact regression: this call used to fail with argparse's
        # "invalid choice" before JOINED_ACTIVE was added.
        proc = run("JOINED_ACTIVE")
        self.assertEqual(proc.returncode, 0, proc.stderr)

    def test_unknown_state_is_still_rejected(self):
        proc = run("NOT_A_REAL_STATE")
        self.assertNotEqual(proc.returncode, 0)


class QualificationExperimentLabelingTests(unittest.TestCase):
    def test_omitted_flag_produces_no_qualification_fields(self):
        proc = run("WAIT_ARMING")
        payload = json.loads(proc.stdout)
        self.assertNotIn("qualification_experiment", payload)
        self.assertNotIn("qualification_experiment_note", payload)

    def test_flag_self_labels_the_payload(self):
        # seq380: this is the mechanism that makes an experimental
        # unqualified-capability drill impossible to mistake for a real
        # qualified WAITING -- the raw status JSON carries its own label.
        proc = subprocess.run(
            [sys.executable, SCRIPT,
             "--participant", "p1", "--project", "proj", "--role", "coding-agent",
             "--lifecycle-state", "WAIT_ARMING", "--commitment-state", "NONE",
             "--last-seen-seq", "1", "--reason", "test",
             "--qualification-experiment", "foreground_wait"],
            capture_output=True, text=True,
        )
        payload = json.loads(proc.stdout)
        self.assertEqual(payload["qualification_experiment"], "foreground_wait")
        self.assertIn("EXPERIMENTAL", payload["qualification_experiment_note"])


if __name__ == "__main__":
    unittest.main()
