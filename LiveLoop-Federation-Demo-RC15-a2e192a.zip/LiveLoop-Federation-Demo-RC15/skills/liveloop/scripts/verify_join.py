"""verify_join.py -- machine-verified JOIN receipt (seq365, architect decision).

Root cause this closes: seq363 found a non-Claude harness (GitHub Copilot VS
Code) narrate a false "Joined LiveLoop" against project `md01` from stale
local scaffolding (`CLAUDE.md`/`role.json`), without the server ever
confirming anything -- `md01`'s `coder-b-01` identity was actually revoked,
and the real intended enrollment (`mock-drill-01-run-a`) sat unclaimed the
whole time. `setup_liveloop.py` was already sound (it always calls live
`whois` and never trusts a local file alone), but nothing made JOIN's own
success claim independently, deterministically checkable -- a harness could
(as observed) simply not run it and narrate success anyway.

This script is that independent check. It is the ONLY thing SKILL.md's
JOIN_LIVELOOP step 2 permits a harness to render success from: a structured
JSON PASS receipt built entirely from live server evidence at the moment of
the call, or an explicit, named FAIL state. A harness's own prose reasoning,
a cached `.liveloop-setup.json` entry, or any local role/task file (CLAUDE.md,
role.json, or anything else this project doesn't own) is never sufficient by
itself -- this script is the single source of truth for "did I actually
join," and its raw JSON is what must appear verbatim in the calling agent's
report, never paraphrased into a prose "Joined" claim.

Truth/precedence contract (architect decision, seq365 item 1): the
server-issued/bound identity (live `whois` result) is authoritative.
`.liveloop-config.json` states desired intent; `.liveloop-setup.json` caches
the resulting binding. Neither the config file's own claims nor any
historical role/package file may substitute for a live check, and a mismatch
between the desired config and the actual server binding fails closed as
`IDENTITY_CONTEXT_CONFLICT` -- it is never silently reconciled by picking one
side.

Zero dev-tree dependency, matching every other script in this package --
uses only `mcp_client.py`, packaged alongside this file.
"""

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import mcp_client  # noqa: E402


def load_json(path):
    p = Path(path)
    if not p.exists():
        return None, None
    try:
        return json.loads(p.read_text(encoding="utf-8")), None
    except (json.JSONDecodeError, OSError) as e:
        return None, f"{path} exists but could not be read/parsed: {e}"


def load_setup_project_entry(setup_path, project_key):
    """Same v3/legacy-v2 read path as setup_liveloop.py's load_setup_record,
    narrowed to just the one project entry this call cares about."""
    data, err = load_json(setup_path)
    if err:
        return None, err
    if not data:
        return None, None
    if "projects" in data:
        return data.get("projects", {}).get(project_key), None
    if data.get("project") == project_key and "participant_id" in data:
        return {
            "participant_id": data.get("participant_id"),
            "participant_name": data.get("participant_name"),
        }, None
    return None, None


def digest(fields):
    """A short, deterministic digest of the receipt's evidentiary fields --
    not a security token, just a compact way for a human/dashboard to spot
    two receipts that silently differ without diffing full JSON."""
    canonical = json.dumps(fields, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def _fail(state, detail, **extra):
    out = {"state": state, "detail": detail}
    out.update(extra)
    return out


def verify(workspace_dir, project, participant=None):
    """The importable core of this script (seq386) -- returns the same
    receipt/fail dict the CLI prints, without printing or exiting, so a
    single in-process orchestrator (e.g. qualify_and_wait.py) can call this
    as one step of a larger bounded sequence. main() below wraps this
    unchanged for the existing CLI contract."""
    workspace = Path(workspace_dir)
    setup_path = workspace / ".liveloop-setup.json"
    mcp_path = workspace / ".mcp.json"
    config_path = workspace / ".liveloop-config.json"

    local_entry, err = load_setup_project_entry(setup_path, project)
    if err:
        return _fail("SETUP_REQUIRED", err, project_key=project)
    if not local_entry:
        return _fail(
            "SETUP_REQUIRED",
            f"no .liveloop-setup.json entry for project '{project}' -- run "
            "SETUP_LIVELOOP for this project before JOIN_LIVELOOP can verify anything.",
            project_key=project,
        )

    participant_name = participant or local_entry.get("participant_name")
    if not participant_name:
        return _fail("SETUP_REQUIRED", "setup record has no participant_name and none was given", project_key=project)

    # Truth/precedence contract: if a desired .liveloop-config.json is present
    # and names a project/participant for this workspace, it must agree with
    # what is about to be verified -- a stale or conflicting config is a fail-
    # closed IDENTITY_CONTEXT_CONFLICT, never silently overridden either way.
    desired_config, cfg_err = load_json(config_path)
    if cfg_err:
        return _fail("SETUP_REQUIRED", cfg_err, project_key=project)
    if desired_config:
        cfg_project = desired_config.get("project")
        cfg_participant = desired_config.get("participant")
        if cfg_project and cfg_project != project:
            return _fail(
                "IDENTITY_CONTEXT_CONFLICT",
                f".liveloop-config.json declares project '{cfg_project}' but JOIN is verifying "
                f"'{project}' -- these must match exactly. This is fail-closed by design: "
                "no local file, prose, or historical role package may override which project is "
                "being joined.",
                project_key=project, config_project=cfg_project,
            )
        if cfg_participant and cfg_participant != participant_name:
            return _fail(
                "IDENTITY_CONTEXT_CONFLICT",
                f".liveloop-config.json declares participant '{cfg_participant}' but JOIN is "
                f"verifying '{participant_name}' -- these must match exactly.",
                project_key=project, config_participant=cfg_participant, verifying_participant=participant_name,
            )

    runtime = mcp_client._from_mcp_json(mcp_path)
    if runtime is None:
        runtime = mcp_client._from_setup_record(setup_path)
    if runtime is None:
        return _fail("SERVER_VERIFICATION_FAILED", "no runtime descriptor resolvable from .mcp.json or .liveloop-setup.json", project_key=project)

    # Deliberately NOT `whois` here: whois's server-side lookup
    # (find_participant_by_name) excludes retired/revoked rows entirely, so
    # a revoked identity looks identical to "never existed" through that
    # tool -- both fail closed, but a revoked identity deserves its own
    # honest diagnosis rather than being indistinguishable from
    # ENROLLMENT_REQUIRED. list_participants has no such filter, so this
    # script can tell the two apart and report REVOKED accurately.
    roster, err = mcp_client.call_tool(runtime, "list_participants", {"project_key": project}, client_name="liveloop-verify-join")
    if err:
        return _fail("SERVER_VERIFICATION_FAILED", err, project_key=project, participant_name=participant_name)
    live = next((row for row in (roster or []) if row.get("name") == participant_name), None)
    if live is None:
        return _fail(
            "ENROLLMENT_REQUIRED",
            f"no live participant named '{participant_name}' in project '{project}' -- "
            "either it was never claimed, or it no longer exists under this name. Run "
            "SETUP_LIVELOOP with a valid enrollment_token, do not proceed to JOIN.",
            project_key=project, participant_name=participant_name,
        )

    if local_entry.get("participant_id") and local_entry["participant_id"] != live.get("id"):
        return _fail(
            "IDENTITY_CONTEXT_CONFLICT",
            "local .liveloop-setup.json entry for this project does not match the live "
            "whois id -- the cached binding is stale relative to the server. Fail closed; "
            "requires explicit human resolution (re-run SETUP_LIVELOOP, or correct the "
            "workspace's identity files), never silently picked automatically.",
            project_key=project, local_id=local_entry.get("participant_id"), live_id=live.get("id"),
        )

    if live.get("retired_at"):
        return _fail(
            "REVOKED",
            f"participant '{participant_name}' in project '{project}' is retired/revoked "
            f"(retired_at={live['retired_at']}) -- a revoked identity can never be reported as "
            "joined, regardless of what any local file claims.",
            project_key=project, participant_id=live["id"], retired_at=live["retired_at"],
        )

    cursor_result, cursor_err = mcp_client.call_tool(
        runtime, "get_cursor", {"project_key": project, "participant": participant_name},
        client_name="liveloop-verify-join",
    )
    if cursor_err:
        return _fail("SERVER_VERIFICATION_FAILED", f"get_cursor failed: {cursor_err}", project_key=project, participant_id=live["id"])

    verified_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    receipt_fields = {
        "project_key": project,
        "project_id": live.get("project_id"),
        "participant_id": live["id"],
        "participant_name": live.get("name"),
        "status": live.get("status"),
        "verified_at": verified_at,
        "cursor_last_seen_seq": cursor_result.get("last_seen_seq") if cursor_result else None,
    }
    return {
        "state": "JOIN_VERIFIED",
        **receipt_fields,
        "evidence_digest": digest(receipt_fields),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace-dir", required=True)
    p.add_argument("--project", required=True,
                    help="Project key to verify against -- always required explicitly, "
                         "never inferred (matches setup_liveloop.py's own discipline).")
    p.add_argument("--participant", default=None,
                    help="Overrides the stored setup record's participant_name when given. "
                         "If omitted, read from .liveloop-setup.json's entry for --project.")
    p.add_argument("--ll-bin", default=None)
    p.add_argument("--ll-data-dir", default=None)
    args = p.parse_args()

    result = verify(args.workspace_dir, args.project, args.participant)
    print(json.dumps(result))
    if result["state"] != "JOIN_VERIFIED":
        sys.exit(1)


if __name__ == "__main__":
    main()
