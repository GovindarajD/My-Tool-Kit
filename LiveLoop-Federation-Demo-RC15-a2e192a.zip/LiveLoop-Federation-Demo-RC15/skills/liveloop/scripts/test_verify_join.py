"""Focused tests for verify_join.py's pure logic (seq365, architect decision).

Plain stdlib unittest, no MCP connectivity -- matches setup_liveloop.py's own
test convention. These cover the setup-record parsing and digest helpers,
which need no live server. The full live-evidence path (whois/get_cursor
against a real ll-mcp server, the REVOKED/ENROLLMENT_REQUIRED/
IDENTITY_CONTEXT_CONFLICT/JOIN_VERIFIED states end to end) is qualified via
the `scenario_h_join_verification` fixture drill against a disposable
project, recorded in the master plan rather than re-run here.

Run directly: python test_verify_join.py
"""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import verify_join as vj


class LoadSetupProjectEntryTests(unittest.TestCase):
    def test_missing_file_returns_none_not_error(self):
        with tempfile.TemporaryDirectory() as d:
            entry, err = vj.load_setup_project_entry(Path(d) / ".liveloop-setup.json", "p1")
        self.assertIsNone(entry)
        self.assertIsNone(err)

    def test_v3_shape_returns_the_named_projects_entry_only(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-setup.json"
            p.write_text(json.dumps({
                "schema": "liveloop-setup-v3",
                "projects": {
                    "p1": {"participant_id": "id-1", "participant_name": "a1"},
                    "p2": {"participant_id": "id-2", "participant_name": "a2"},
                },
            }), encoding="utf-8")
            entry, err = vj.load_setup_project_entry(p, "p1")
        self.assertIsNone(err)
        self.assertEqual(entry["participant_id"], "id-1")

    def test_v3_shape_missing_project_returns_none(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-setup.json"
            p.write_text(json.dumps({"projects": {"p1": {"participant_id": "id-1"}}}), encoding="utf-8")
            entry, err = vj.load_setup_project_entry(p, "p2")
        self.assertIsNone(err)
        self.assertIsNone(entry)

    def test_legacy_flat_v2_shape_matching_project_is_read(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-setup.json"
            p.write_text(json.dumps({
                "project": "p1", "participant_id": "id-1", "participant_name": "a1",
            }), encoding="utf-8")
            entry, err = vj.load_setup_project_entry(p, "p1")
        self.assertIsNone(err)
        self.assertEqual(entry["participant_id"], "id-1")

    def test_legacy_flat_v2_shape_for_a_different_project_is_never_matched(self):
        # This is the exact seq363 shape of bug this whole hardening pass
        # exists to prevent: a cached record for one project must never be
        # silently treated as evidence for a different project.
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-setup.json"
            p.write_text(json.dumps({
                "project": "md01", "participant_id": "id-1", "participant_name": "coder-b-01",
            }), encoding="utf-8")
            entry, err = vj.load_setup_project_entry(p, "mock-drill-01-run-a")
        self.assertIsNone(err)
        self.assertIsNone(entry)

    def test_corrupt_file_is_an_explicit_error(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".liveloop-setup.json"
            p.write_text("{not valid json", encoding="utf-8")
            entry, err = vj.load_setup_project_entry(p, "p1")
        self.assertIsNone(entry)
        self.assertIsNotNone(err)


class DigestTests(unittest.TestCase):
    def test_digest_is_deterministic_for_same_fields(self):
        fields = {"a": 1, "b": "x"}
        self.assertEqual(vj.digest(fields), vj.digest(dict(fields)))

    def test_digest_is_order_independent(self):
        self.assertEqual(vj.digest({"a": 1, "b": 2}), vj.digest({"b": 2, "a": 1}))

    def test_digest_differs_for_different_fields(self):
        self.assertNotEqual(vj.digest({"a": 1}), vj.digest({"a": 2}))


class LoadJsonTests(unittest.TestCase):
    def test_missing_file_is_not_an_error(self):
        with tempfile.TemporaryDirectory() as d:
            data, err = vj.load_json(Path(d) / "nope.json")
        self.assertIsNone(data)
        self.assertIsNone(err)

    def test_valid_file_loads(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.json"
            p.write_text('{"a": 1}', encoding="utf-8")
            data, err = vj.load_json(p)
        self.assertIsNone(err)
        self.assertEqual(data["a"], 1)

    def test_corrupt_file_is_an_explicit_error(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.json"
            p.write_text("{not json", encoding="utf-8")
            data, err = vj.load_json(p)
        self.assertIsNone(data)
        self.assertIsNotNone(err)


if __name__ == "__main__":
    unittest.main()
