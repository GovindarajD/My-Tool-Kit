# liveloop / communication — per-wake governance module

Absorbed from the former standalone `local-communication` skill (seq226 consolidation,
REQ-44) into `liveloop`'s internal `communication/` module — this is the substance the
`PROCESSING` state (`STATE_MODEL.md`) runs, not a separate skill an agent needs to know
about or invoke on its own. **MCP provides the WHAT; this module provides the HOW**
(blueprint file 01's key architectural rule, unchanged by this move).

The LiveLoop MCP server (`dev/contracts/CONTRACT_V1.md`, implemented in `live-loop/`)
exposes generic communication primitives — messaging, directives, approvals, organization,
queries. It does not know or enforce *your* workflow. This module is that workflow, derived
from actually operating the server (see [FRICTION_LOG.md](FRICTION_LOG.md) for the trial
that produced it — this is not speculative).

## Master procedure (runs inside `PROCESSING`, per event)

1. **communication-intake** — read your delta, triage by directive, decide what needs a
   closer look.
2. For anything ambiguous: **clarification-and-response** — ask, don't guess.
3. For anything with an attached directive that implies action:
   **authority-and-approval-check** — verify permission structurally before acting.
4. For anything requiring more history than the delta gave you:
   **thread-context-retrieval** — pull only what's needed.
5. For attachments referenced anywhere in step 1-4: **attachment-handling**.
6. After acting: **communication-organization** — file it your way.
7. Periodically (not every wake): **communication-hygiene** — sweep for stale items.
8. If participating in a channel: **channel-participation** — distinguish ambient discussion
   from directed requests.
9. When asked to justify a decision or trace an outcome: **audit-and-trace**.

## Sub-skills

- [communication-intake](sub-skills/communication-intake.md)
- [thread-context-retrieval](sub-skills/thread-context-retrieval.md)
- [clarification-and-response](sub-skills/clarification-and-response.md)
- [authority-and-approval-check](sub-skills/authority-and-approval-check.md)
- [attachment-handling](sub-skills/attachment-handling.md)
- [communication-organization](sub-skills/communication-organization.md)
- [channel-participation](sub-skills/channel-participation.md)
- [communication-hygiene](sub-skills/communication-hygiene.md)
- [audit-and-trace](sub-skills/audit-and-trace.md)

## Ground rules (apply across all sub-skills — unchanged, verbatim, since governance must not
weaken across this consolidation)

- **Never infer authority from prose.** "Go ahead", "sounds good", "I don't see value in
  version 2" are not authorization. Only an explicit directive + (if `approval_required`) a
  resolved `approval_state` of `approved`, checked via `get_action_state`, establishes
  permission. See `authority-and-approval-check`.
- **Delta first, full context only when needed.** Call `fetch_delta` before
  `query_communication`/`fetch_thread`; only expand to full thread history when the delta's
  inline directive summary or your own judgment says it's necessary. This is a real token/
  efficiency concern, not just tidiness — see `thread-context-retrieval`.
- **Organization is yours, not the server's.** `organize`'s folder/tag/state values are
  free text scoped to you (`CONTRACT_V1.md` section 7). Pick a small, consistent vocabulary
  and hold to it — the server enforces nothing here.
- **The server will not stop you from acting without authority.** `action_permitted` in
  `get_action_state` is advisory data. Skipping the check is a governance violation, not
  something LiveLoop prevents (`FRICTION_LOG.md` item 4). Treat the check as mandatory.
- **Supersession beats recency.** A later plain message never overrides an earlier directive.
  Only an explicit `issue_directive(..., supersedes_directive_id: <id>)` does, and
  `get_action_state`'s `effective_directive`/`superseded` fields are how you find out.

## Tool reference (grounded in the actual tool surface)

| Need | Tool |
|---|---|
| Register self / look up a peer | `register_participant`, `whois`, `list_participants` |
| Send / reply | `send_message`, `reply_message` |
| Channel | `create_channel`, `post_channel_message` |
| What's new for me | `fetch_delta` (preferred), `fetch_inbox` |
| Structured search | `query_communication`, `fetch_thread` |
| Attachments | `get_attachment_meta`, `get_attachment_content` |
| Confirm receipt | `acknowledge_message` |
| Action semantics | `issue_directive`, `respond_to_approval`, `get_action_state` |
| Evidence of work done | `record_execution_reference` |
| My own filing | `organize`, `find_orphaned` |
| Checkpoint | `get_cursor`, `update_cursor` |
| Justify a decision | `get_audit_chain` |
