# Gate 4 Friction Log

Per blueprint file 08, the communication skill must come from "actually operating the
enhanced MCP" during a realistic multi-agent trial, not be authored speculatively. This log
records that trial and what it changed.

## Trial setup

`dev/skills/gate4_trial.py` drives the real `ll` binary over the actual stdio MCP transport
(not in-process — a genuine JSON-RPC client, same as a real MCP host would use), playing three
personas: an Architect agent, a Coding agent, and a Human operator, through a full
request → approval → delta → acknowledge → organize → execute → result → audit cycle. Full
transcript: `dev/skills/gate4_trial_transcript.txt`.

## Friction found and how it was resolved

1. **`fetch_delta`/`fetch_inbox` returned bare messages with no hint of an attached
   directive.** The blueprint's own `communication-intake` procedure (file 08) says: after
   reading the delta, "(3) inspect action/authority metadata" — but the coder persona had to
   make a *second* tool call (`fetch_thread`) per message just to discover whether a directive
   existed at all, before it could even decide whether a third call
   (`get_action_state`) was worth making. For an agent skimming a delta of many messages,
   that's an extra round trip per message merely to triage.

   **Fix**: `fetch_delta` and `fetch_inbox` now return `{"message": ..., "directives": [{id,
   directive, approval_required, approval_state}, ...]}` per entry — a lightweight summary,
   not the full `get_audit_chain`-style detail. See `directive_summaries`/
   `with_directive_summaries` in `crates/liveloop-mcp/src/server.rs`. This is a response-shape
   change from the original CONTRACT_V1.md sketch (message lists are now enriched objects, not
   raw `Message`), recorded here rather than by editing the frozen v1 contract doc.

2. **`organize`, `get_cursor`, `update_cursor` took a raw participant ID while every other
   tool takes `project_key` + participant name.** This was a deliberate Gate 2 shortcut
   (recorded as deviation #5 in `dev/GATE2_REPORT.md`) that looked reasonable in isolation but
   fails in practice: a freshly-invoked agent has no memory of the ULID from its own
   `register_participant` call several turns/sessions ago, so it would have to call `whois`
   first just to convert its own name into an ID before it could advance its cursor or file a
   message — a pure papercut with no benefit.

   **Fix**: all three tools now take `project_key` + `participant` (name), matching every
   other tool. Consistency across the tool surface turned out to matter more than the minor
   convenience of skipping one lookup in the two or three tools that used to be ID-based.

3. **(Observed, not changed) `get_audit_chain` is intentionally "expensive."** Its payload for
   a 2-message thread was ~2.9 KB — full recipients/attachments/directives/approvals/acks per
   message. That's correct for an *audit* tool (completeness matters more than economy there),
   but it means a skill should prefer `get_action_state` for routine "is this still blocked"
   checks and reach for `get_audit_chain` only when it actually needs to produce or inspect
   evidence. This became a documented rule in the `authority-and-approval-check` and
   `audit-and-trace` sub-skills below, not a server change.

4. **(Observed, not changed) The server never stops an agent from acting without checking
   authority — it only reports permission state truthfully.** `get_action_state`'s
   `action_permitted` field is advisory data, not an enforcement gate; nothing in the MCP
   layer prevents a coding agent from calling `record_execution_reference`/`reply_message`
   before approval exists. This is intentional (blueprint file 01: the module does not police
   agents, per "MCP provides the WHAT; Skills provide the HOW") but it means the
   `authority-and-approval-check` sub-skill is load-bearing, not a nice-to-have — it's the only
   thing standing between an agent and skipping the approval gate. Documented explicitly below.

Both code fixes are covered by the existing scenario test suite (re-run clean, 18/18) after
the change — see `dev/GATE2_REPORT.md`'s Scenario addendum for the before/after on fix #1.
