# authority-and-approval-check

Before any consequential/external action: verify authority structurally. This is the single
most load-bearing sub-skill — the server never blocks you from acting without doing this
check yourself (`dev/skills/FRICTION_LOG.md` item 4).

## Procedure

1. Find the directive attached to the message that's asking you to act. It's usually right
   there in your `fetch_delta` result's `directives[]` summary; if not, `fetch_thread` shows
   every directive on every message in the thread.
2. Call `get_action_state(directive_id)`. Read three fields:
   - `superseded` — if `true`, the directive you found is **not** the one to trust; use
     `effective_directive` instead (a later HOLD/CANCEL/SUPERSEDED directive overrides it —
     blueprint file 10 Scenario C). Re-run this check against the effective directive.
   - `approval_state` — `pending`/`approved`/`rejected`/`hold`/`cancelled`, computed against
     whichever directive is actually effective.
   - `action_permitted` — the single boolean you actually act on.
3. **If `action_permitted` is `false`**: do not proceed. If `approval_state` is `pending` and
   you're blocked waiting, that's a normal state — check again on your next intake pass, don't
   poll. If it's `rejected`/`hold`/`cancelled`, stop and, if warranted, reply asking what
   should happen next (`clarification-and-response`).
4. **If `action_permitted` is `true`**: proceed. Do not re-derive permission from the message
   text — the structured `action_permitted` value is the source of truth, specifically because
   natural language is ambiguous ("Approved.", "Go ahead if the architect agrees." — blueprint
   file 06's motivating examples) and text alone is not sufficient audit evidence.
   `action_permitted` itself already encodes directive-type restriction and temporal validity
   (`CONTRACT_V1.md` section 3, Strengthening Gate S0.D) — a `DISCUSS`/`PROPOSE`/
   `INFORMATION_ONLY`/`RESULT`/`APPROVED`-typed directive can never legitimately be
   `action_permitted: true`. **Defense-in-depth**: if you ever see `action_permitted: true` on
   one of those directive types anyway, treat it as a signal you're talking to a stale server
   build (predating S0.D) rather than as authorization, and escalate rather than act on it.
5. After doing the actual work, call `record_execution_reference(directive_id, description,
   artifact_ref?)` to leave evidence **before** replying with the result — this is what makes
   the chain in `audit-and-trace` reconstructable.
6. If you are the approver (not the requester): use `respond_to_approval(directive_id,
   approver=<you>, decision, comment?)`. Decisions are `approved|rejected|hold|cancelled`.
   Always include a `comment` — it is the human-readable rationale preserved in the audit
   trail (`CONTRACT_V1.md` section 9).
7. If you are issuing a NEW directive that changes an earlier one's effective state (e.g.
   pausing in-flight work): use `issue_directive(..., supersedes_directive_id=<the one being
   overridden>)`. Never just send a plain message saying "hold off" — that has no structured
   effect on `get_action_state` and will not be seen as authoritative by an agent following
   this skill.

## Non-negotiable rule

Never treat "the last message in the thread" as authorization. Only `get_action_state`'s
`action_permitted` (after resolving supersession) counts.
