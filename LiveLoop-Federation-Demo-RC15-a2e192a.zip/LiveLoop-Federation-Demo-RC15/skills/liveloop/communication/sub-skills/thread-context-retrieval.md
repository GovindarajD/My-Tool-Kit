# thread-context-retrieval

Reconstruct only the context actually required for the communication in front of you.

## Procedure

1. Start from the message/directive ID you already have (from `fetch_delta` or a reply you're
   handling).
2. If you only need to know "is this permitted right now" — call `get_action_state(directive_id)`
   directly. Do **not** call `fetch_thread`/`get_audit_chain` just to answer that question; they
   return far more than you need (a 2-message thread's audit payload is already ~3KB — see
   `dev/skills/FRICTION_LOG.md` item 3).
3. If you need the conversational context (what was said, in what order) — call
   `fetch_thread(thread_id)`. This returns every message in the thread with its recipients,
   attachments, directives+approvals, and acknowledgements in one call; you don't need to
   fetch each message individually.
4. If you need cross-thread context (e.g. "what else has this participant sent me recently") —
   use `query_communication` with `participant`/`since_seq`/`text` filters, not a manual scan
   of `fetch_inbox`.
5. Stop as soon as you have what you need for the decision at hand. Expanding "just in case"
   defeats the point of the delta/cursor model.

## When NOT to use this sub-skill

If `authority-and-approval-check` is all you need (most cases involving a directive), go
straight there — it's a single targeted call, not a context expansion.
