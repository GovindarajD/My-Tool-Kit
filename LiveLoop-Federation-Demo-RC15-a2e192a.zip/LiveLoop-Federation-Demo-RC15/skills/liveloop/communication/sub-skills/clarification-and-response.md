# clarification-and-response

On genuine ambiguity: do not guess. Ask, in the same thread, and wait.

## Procedure

1. Identify the specific ambiguity — not "this is unclear" but the concrete decision point
   (e.g. "which cache backend: in-memory or Redis?"), so the person/agent you ask can answer
   in one message.
2. Reply in the **same thread**, addressed back to whoever can resolve it:
   `reply_message(message_id=<the ambiguous message>, from=<you>, body_md=<specific question>,
   directive="DISCUSS")`. `reply_message` addresses the original message's sender by default
   (Gate 2 scope — it does not reply-all to every original recipient; see
   `dev/GATE2_REPORT.md` deviation #4), which is exactly what you want for a targeted
   clarification.
3. Do **not** treat the act of asking as fulfilling any pending approval/ack requirement on
   the original message — a clarification reply is `DISCUSS`, not `APPROVED`/`ACK_REQUIRED`
   resolution. Verified in `scenario_b_clarification_loop.rs`: the original directive's
   `action_permitted` stays `false` throughout a clarification exchange.
4. Stop after asking. Re-check on your next scheduled `communication-intake` pass (via
   `fetch_delta`), not by polling in a loop — this bounds the exchange and prevents
   autonomous ping-pong (blueprint file 10 Scenario B's explicit validation target).
5. When the answer arrives, resume normal intake handling of that thread — including, if
   applicable, `authority-and-approval-check` before acting on the clarified instruction.

## Anti-pattern

Silently picking the more-likely interpretation and proceeding. If the directive is
`APPROVAL_REQUIRED` or the ambiguity affects what gets built, the cost of asking is far lower
than the cost of a wrong, already-executed guess.
