# channel-participation

Consume rolling channel context without treating every message as an assigned task.

## The model

A channel is a thread with a persistent participant list (`create_channel`). Messages posted
via `post_channel_message` reach every member, but addressing still distinguishes directed
from ambient (`CONTRACT_V1.md` section 4):

- If you're named in `mentions`, you're a `to` recipient — directed attention.
- Otherwise, you're a `cc` recipient — ambient/observer.

Both show up in your `fetch_delta` the same way (a channel post is still a message with
recipients), so lean on the recipient `kind` — visible via `fetch_thread`'s `recipients[]` — to
decide how to treat it, not on the mere fact that you're a channel member.

## Procedure

1. Treat `cc` channel messages as background context: worth a skim during
   `communication-intake`, but not something to act on or reply to by default.
2. Treat `to` (mentioned) channel messages exactly like a directed mailbox message: run
   `authority-and-approval-check` if a directive is attached, respond if a question is
   directed at you.
3. Never assume "I'm in this channel" implies "I must do something about this thread." Channel
   membership is awareness, not assignment (blueprint file 10 Scenario E's explicit
   validation: channel != task assignment).
4. The full channel history stays queryable by every member regardless of who was mentioned on
   which message — use `query_communication(thread_id=<channel_id>, participant=<you>)` if you
   need to catch up on everything, or `fetch_thread(thread_id=<channel_id>)` for full detail.
5. When posting to a channel yourself, only set `mentions` for participants who genuinely need
   to act — over-mentioning defeats the purpose of ambient discussion and creates false
   urgency for everyone else.
