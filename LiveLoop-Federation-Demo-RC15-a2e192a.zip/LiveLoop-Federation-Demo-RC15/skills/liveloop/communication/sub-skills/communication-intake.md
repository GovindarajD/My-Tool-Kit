# communication-intake

Inspect new/delta communication efficiently, without loading the whole mailbox.

## Procedure

1. `fetch_delta(project_key, participant=<your name>)`. This returns
   `{"messages": [{"message": ..., "directives": [...]}], "cursor": ...}` — each entry already
   carries a lightweight directive summary (id, directive value, approval_required,
   approval_state), so you can triage without a second call per message
   (`dev/skills/FRICTION_LOG.md` item 1).
2. For each entry, classify:
   - **Directed at me** — check the message's recipients if unsure (`fetch_thread` gives full
     `recipients[]` with `kind: to|cc`), but usually the fact it's in your delta at all plus
     `directive` is enough.
   - **Observer-only (cc)** — lower priority; skim, don't act.
   - **Has a directive implying action** (`ACTION_REQUESTED`, `PROCEED`,
     `CONFIRM_BEFORE_ACTION`, `APPROVAL_REQUIRED`) — route to `authority-and-approval-check`
     before doing anything consequential.
   - **`DISCUSS`/`PROPOSE`/`INFORMATION_ONLY`** — no action gate; route to
     `clarification-and-response` only if something is genuinely unclear.
3. Expand to full thread context (`thread-context-retrieval`) only for entries you're actually
   going to act on or respond to — not for every delta entry.
4. After processing (acknowledging, replying, organizing) every entry you intend to handle
   this pass, advance your checkpoint: `update_cursor(project_key, participant, seq=<highest
   seq you actually processed>)`. Do **not** advance past messages you deferred — advancing
   the cursor means "I've dealt with this," not "I've seen this."
5. Update your own filing for each processed entry (`communication-organization`) so future
   `find_orphaned` calls don't re-surface it.

## Why delta-first, not query_communication

`query_communication` is more general but requires you to already know what you're looking
for. `fetch_delta` is the default "what's new" primitive and is the one built for context
efficiency (blueprint file 05's procedure: fetch delta first, inspect metadata, retrieve only
relevant context, expand history only when necessary).
