# audit-and-trace

Retrieve the evidence chain for a decision, action, or artifact — when asked to justify what
happened, not as a routine check (use `authority-and-approval-check`'s lighter
`get_action_state` for that).

## Procedure

1. Start from any anchor you have: a message ID, a directive ID, or a thread ID.
   `get_audit_chain(anchor_id)` resolves any of the three to the owning thread and returns
   every message in it with full detail: recipients, attachments, directives (each with its
   approvals and execution references), and acknowledgements.
2. Read the chain in order: `message → directive → approval → acknowledgement → execution
   reference → result message → attachment` (`CONTRACT_V1.md` section 9's target traversal).
   Every step should be traceable to a specific ID and actor — if a step is missing (e.g. a
   directive with `approval_required=true` but no `Approval` row), that's a real gap worth
   surfacing, not something to paper over.
3. Watch for supersession: a message's `directives[]` array is append-only, so you may see
   more than one directive per message (e.g. an original `PROCEED` plus a later `HOLD` that
   supersedes it — `dev/skills/FRICTION_LOG.md`/blueprint file 10 Scenario C). Check each
   directive's `supersedes_directive_id` to reconstruct which one was actually effective at
   any point in time, not just which was issued last chronologically among unrelated
   directives.
4. This payload is intentionally complete, not economical (`dev/skills/FRICTION_LOG.md` item
   3) — expect several KB even for a short thread. That's the right trade-off for evidence
   production; don't use `get_audit_chain` as your default "what's the status" check.
5. When reporting findings (to a human or another agent), cite specific IDs (message,
   directive, approval, execution reference) rather than paraphrasing — the whole point of the
   traceability model is that a chain is objectively reconstructable, stronger than any
   natural-language summary of "what happened."
