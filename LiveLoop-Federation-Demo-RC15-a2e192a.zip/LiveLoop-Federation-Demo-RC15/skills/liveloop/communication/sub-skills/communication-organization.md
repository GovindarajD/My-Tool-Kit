# communication-organization

Use the server's generic primitives to implement *your own* organization discipline. The
server has no opinion on what "waiting" or "done" means — that's entirely this sub-skill's
job (`CONTRACT_V1.md` section 7 / blueprint file 07's explicit "no task-manager creep" rule).

## The primitive: `organize(project_key, participant, target_type, target_id, action, value?)`

`target_type` is `"message"` or `"thread"`. `action` is one of:

| action | `value` meaning |
|---|---|
| `move_folder` | folder name (created on first use, scoped to you) |
| `add_tag` / `remove_tag` | tag name (many-to-many, scoped to you) |
| `set_state` | any free-text state value you define |
| `archive` / `unarchive` | (none) |
| `pin` / `unpin` | (none) |

All of this is **per-participant** — organizing a message doesn't change how anyone else sees
it, and different agents can use entirely different disciplines on the same shared messages
without conflict.

## A workable minimal discipline (adapt as needed)

- `set_state` to one of: `new` (implicit — no organization row yet), `waiting` (blocked on
  someone else), `in_progress` (you're actively on it), `done` (finished, about to archive).
- `move_folder` only for durable groupings you'll want to filter by later (e.g. a specific
  project workstream), not as a substitute for state.
- `archive` once a thread is genuinely finished — this hides it from your default working set
  without deleting anything; `query_communication(..., archived=false)` becomes your default
  "active" view, `archived=true` your "done" view.
- `pin` sparingly, for the few things you need surfaced regardless of state.

## Reactivation

An archived thread is not gone. If it receives a new reply, it's still fully present in
`fetch_thread` history; call `organize(..., action="unarchive")` to bring it back into your
active view. Verified in `scenario_d_mailbox_organization.rs`.

## Hygiene

`find_orphaned(project_key, participant)` returns messages addressed to you (`to`) with
neither an acknowledgement nor any organization record — your unclassified backlog. Run it
periodically (see `communication-hygiene`), not on every intake pass.
