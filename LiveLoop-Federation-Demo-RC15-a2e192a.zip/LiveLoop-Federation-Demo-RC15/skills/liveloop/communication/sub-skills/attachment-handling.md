# attachment-handling

Discover, verify, and use attachments; associate generated artifacts with the right
message/thread.

## Procedure

1. Discover: attachments show up in `send_message`/`reply_message` responses
   (`attachments: [...]`) and in `fetch_thread`'s per-message detail. There is no separate
   "list all attachments" tool at Gate 2 scope — attachments are always discovered through the
   message that carries them.
2. Verify provenance before trusting content: `get_attachment_meta(attachment_id)` gives
   `filename, media_type, size_bytes, sha256, created_at` and implicitly `message_id` — trace
   it back to its sending message/thread if provenance matters for the decision at hand.
3. Retrieve content only when you actually need it: `get_attachment_content(attachment_id)`
   returns base64-encoded bytes read live from the durable Git archive (not just the SQLite
   row) — this doubles as an integrity check, since a missing/corrupted archive file surfaces
   as a tool error rather than silently returning stale data.
4. When you produce your own artifact as a result of the work (a diff, a report, a build
   output): **before choosing how to deliver it, check the recipient's Capability Profile**
   (`dev/mock-drill-01-activation/capability-profiles/<role>.json`, schema in
   `dev/LIVELOOP_STRENGTHENING_MASTER_PLAN.md` S0.E) rather than guessing or assuming your own
   capabilities are shared. `["filesystem", "git"]` → a path or commit-SHA reference is fine.
   `["mcp_only"]` → **individually-readable attachments only** (`text/markdown`/`text/plain`,
   one file per attachment) — never a zip (no archive-extract capability) and never a bare
   path/SHA (not dereferenceable). This was learned the hard way, twice, delivering to
   `liveloop-architect-01` before this check existed (`00_ACTIVATION_PACKAGE_OVERVIEW.md`'s
   addendum) — the profile check exists specifically so that mistake isn't repeated per
   participant. Attach it to your `reply_message` call's `attachments` field (`filename`,
   `media_type`, `content_base64`), addressed back into the same thread. Don't describe the
   artifact only in prose — attach it so it's retrievable and traceable (`get_audit_chain`
   includes attachments per message).
5. Never require a human to go find the file in the repo manually — if it's relevant to the
   thread, it belongs as an attachment on a message in that thread (blueprint file 04's
   explicit rule).
