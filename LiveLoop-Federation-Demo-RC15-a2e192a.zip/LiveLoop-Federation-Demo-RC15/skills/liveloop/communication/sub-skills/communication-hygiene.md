# communication-hygiene

Periodic sweep — not every wake — to keep your mailbox from silently accumulating debris that
`communication-intake` alone won't catch (intake only looks at the delta; hygiene looks at
everything outstanding).

## What to check, and how

1. **Unacknowledged directed messages**: `query_communication(project_key, participant=<you>,
   archived=false)` and check which `ack_required` messages have no corresponding
   acknowledgement (cross-reference `fetch_thread` per candidate, or track this yourself as
   you process intake — Gate 2 has no single "unacked" query yet, see Gate 5/Phase 1B gap
   register).
2. **Unclassified/orphaned communication**: `find_orphaned(project_key, participant=<you>)` —
   messages addressed to you with neither an ack nor any organization record. Anything here
   fell through `communication-intake`; file or acknowledge it now.
3. **Stale waiting conversations**: anything you `set_state`'d to `waiting` — if it's been
   waiting an unreasonable time for your workflow, follow up (`clarification-and-response`) or
   escalate rather than leaving it silently stuck.
4. **Unresolved approval requests**: for directives you issued with `approval_required=true`,
   check `get_action_state` — if still `pending` after a long time, consider whether to nudge
   the approver or `issue_directive(..., directive="CANCEL", supersedes_directive_id=<id>)` if
   it's no longer relevant.
5. **Completed communication ready to archive**: anything `set_state`'d to `done` with no
   further expected activity — `organize(..., action="archive")` it so your active view
   (`archived=false`) stays representative of real outstanding work, not history.

## Cadence

Hygiene is a background sweep, not a per-message action — run it on a schedule appropriate to
your own workflow (e.g. once per session, or every N intake passes), not on every
`communication-intake` call. Mixing the two defeats the point of intake being fast/delta-only.
