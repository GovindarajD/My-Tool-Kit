# Declarative provisioning (seq306, Stage 2 C0 prep)

This document exists because a real gap was found: `SETUP_LIVELOOP` required a human (or an
agent's own guess) to supply `participant`/`project`/`harness` on every run, even in a
workspace whose identity is already fixed and known in advance (a provisioned Stage-2
participant). That is a genuine, avoidable question. This document defines the declarative
config file that removes it, and — just as importantly — the decision table for the handful of
cases where a question remains legitimate and must not be short-circuited.

## Two files, two owners — do not conflate them

| File | Author | Nature | Purpose |
|---|---|---|---|
| `.liveloop-config.json` | Human/architect, checked into the workspace | Declarative, desired state | States *who this workspace's participant is supposed to be* |
| `.liveloop-setup.json` | `setup_liveloop.py`, machine-generated | Resolved, actual state | Records *what was actually discovered/created* (participant id, runtime descriptor, capabilities, timestamps) |

`.liveloop-setup.json`'s schema and role (v3, seq234) are unchanged by this document. Never
write identity-resolution logic that reads `.liveloop-setup.json` as if it were the declarative
input — it is the output of a prior run, not the request for one.

A third, unrelated file, `.liveloop-bridge.json`, is Control-Bridge-specific (optional/deferred
tooling per `DISTRIBUTION.md`) and is not part of this contract at all.

## `.liveloop-config.json` schema (`liveloop-config-v1`)

Location: workspace root (same directory as `.mcp.json` and `.liveloop-setup.json` — never
inside the skill folder, so the same file works no matter which packaging location loaded the
skill; see *Vendor neutrality* below).

```json
{
  "schema": "liveloop-config-v1",
  "project": "liveloop",
  "participant": "coding-agent-phase1a",
  "role": "coding-agent",
  "harness": "claude-code",
  "enrollment_token": "<one-time pairing token from an admin's create_enrollment invite -- omit once claimed>"
}
```

Fields:
- `project` (string, required for zero-question setup) — the LiveLoop `project_key`.
- `participant` (string, required for zero-question setup) — the participant name a
  `claim_enrollment` call (see below) or a live `whois` resolves to.
- `harness` (string, required for zero-question setup) — passed through to
  `.liveloop-setup.json`'s `harness` field unchanged (e.g. `claude-code`, `github-copilot`).
- `role` (string, optional) — not consumed by `setup_liveloop.py`'s identity resolution itself,
  but is passed to `claim_enrollment` as the declared role to verify against the invite, and
  carried here so `JOIN_LIVELOOP`/`status_payload.py` calls in the same workspace have a single
  declared source for `--role` too, instead of a second place to hardcode or ask for it.
- `enrollment_token` (string, optional, **seq315/seq319**) — the one-time pairing token an admin
  issued via `create_enrollment` (typically through the dashboard's *Invite Agent* flow),
  delivered here for a not-yet-bound participant to claim. **Consumed and removed from this file
  automatically** by `setup_liveloop.py` on a successful claim — never left sitting in a
  checked-in file after it has served its purpose, and never written into `.liveloop-setup.json`
  (which stays a record of resolved, non-secret state). Absent for an already-bound participant
  (the ordinary `whois`-then-reuse path, unchanged) and absent for a not-yet-invited workspace
  (which correctly reports `ENROLLMENT_REQUIRED` instead of guessing).

**Registration is no longer something a normal agent does to itself (seq315/seq319, P0
security fix).** Before this fix, an agent whose `whois` came back empty would call
`register_participant` itself. A real incident showed this was unsafe: a workspace with stale
`role.json`/config content could silently bind to an old, real identity in an unrelated project
just by naming it. `register_participant` is now admin-gated (requires the server's local
bootstrap admin token) and exists only for admin/test bootstrap — **`setup_liveloop.py` never
calls it**. The only path from "no existing participant" to a bound identity is
`claim_enrollment` with a token an admin issued in advance. Full design, threat model, and the
enrollment state machine: `dev/contracts/AGENT_ENROLLMENT_DESIGN.md`.

The file is optional. Its complete absence is not an error — it simply means every field must
come from a CLI arg instead (the pre-seq306 behavior, unchanged for workspaces that don't use
this mechanism).

## Precedence rule

For each of `participant`/`project`/`harness`: **explicit CLI arg to `setup_liveloop.py` wins
over the config file's value, which wins over nothing.** A value present in neither source is
reported as missing — it is never inferred from the workspace folder name, the skill's own
packaging path, environment variables, or any other heuristic (this is the one absolute rule of
this whole mechanism: fail closed, never guess).

An empty-string value in the config file (`"participant": ""`) counts as absent, not as a
configured blank — this is enforced in `resolve_identity_args()` and covered by
`test_setup_liveloop.py`.

## Outcomes added to `setup_liveloop.py` by this change

- `NOT_CONFIGURED` (new, seq306): one or more of `participant`/`project`/`harness` resolved to
  nothing from either source. The response's `missing_fields` array names exactly which. This
  is a fail-closed report, not a partial attempt — no `.mcp.json` write, no `whois` call happens
  first.
- `SETUP_READY`, `SETUP_RESTART_REQUIRED`, `IDENTITY_CONFLICT`, `SETUP_FAILED`,
  `LIVELOOP_RUNTIME_NOT_FOUND` are unchanged in meaning and are reached identically whether
  identity came from CLI args, from the config file, or a mix of both — the resolution step
  above is a pure preprocessing pass in front of the existing logic, not a parallel code path.
- A present-but-corrupt `.liveloop-config.json` reports `SETUP_FAILED` naming the parse error —
  it is never silently treated as absent (that would hide a real authoring mistake in a
  checked-in file).
- **`NOT_REGISTERED` is retired (seq315/seq319)** — it used to mean "the agent should call
  `register_participant` itself and re-run." That tool is now admin-gated; a normal agent has no
  admin token and must never attempt it. The same "no existing participant" situation now splits
  into two honest outcomes instead:
  - `ENROLLMENT_REQUIRED` — no existing participant, and no `enrollment_token` in
    `.liveloop-config.json` either. The workspace must wait for an admin to issue an invite.
  - `claim_enrollment` is attempted automatically when an `enrollment_token` **is** present,
    yielding either `SETUP_READY`/`CLAIMED` on success, or one of three new fail-closed
    outcomes naming exactly what went wrong: `ENROLLMENT_EXPIRED` (the invite's expiry has
    passed), `ENROLLMENT_REPLAYED` (this token was already claimed, revoked, or never valid —
    covers both "someone else claimed it first" and "a stale copy of an already-used config
    file is being replayed"), `ENROLLMENT_MISMATCH` (the project/participant/role declared
    locally doesn't match what the invite actually says — never silently bound to the caller's
    own values). On success, the now-spent `enrollment_token` is automatically removed from
    `.liveloop-config.json` so a stale copy of that file can never be replayed.

## Decision table — when a question is still legitimate

Zero-question setup only removes the *avoidable* question ("what is this workspace's
declared identity" — answerable once, in advance, by whoever provisions the workspace). It must
never remove a question that reflects a genuine runtime ambiguity a script cannot safely
resolve on its own:

| Situation | Still asks / stops? | Why |
|---|---|---|
| Config file complete, no `.liveloop-setup.json` yet, participant not yet registered, no `enrollment_token` | **Yes — `ENROLLMENT_REQUIRED`** (seq315/seq319, supersedes the old `NOT_REGISTERED`) | An unauthenticated agent binding its own identity is exactly the security gap this fix closes; only an admin-issued invite can authorize a first claim now |
| Config file complete including a valid, unexpired, unclaimed `enrollment_token` | No question — `claim_enrollment` runs automatically, reports `SETUP_READY`/`CLAIMED` | The admin already approved this exact project/participant/role combination by issuing the invite; presenting its token is the mechanical, safe, single-use action this design delegates to the agent |
| `enrollment_token` present but expired/already-claimed/mismatched | **Yes — `ENROLLMENT_EXPIRED`/`ENROLLMENT_REPLAYED`/`ENROLLMENT_MISMATCH`, naming exactly which** | Each is real evidence of either a stale file, a race, or a config error — never silently retried or resolved in the caller's favor |
| Config file complete, local record and live `whois` disagree on participant id | **Yes — `IDENTITY_CONFLICT`, `HUMAN_RESOLUTION_REQUIRED`** | Two different identities existing under one declared name is evidence of a real mistake (stale config, workspace reused for a different agent, etc.) that a script must not silently pick a side on |
| `.mcp.json` missing the `ll-mcp` entry, but a runtime is discoverable | No question — provisions it, reports `SETUP_RESTART_REQUIRED` | Mechanical, reversible, already-established behavior (seq228), unrelated to this change |
| No runtime discoverable anywhere (no `.mcp.json`, no prior setup record, no env vars, no explicit override) | **Yes — `LIVELOOP_RUNTIME_NOT_FOUND`, names the legitimate prerequisite** | There is genuinely no safe value to assume; this names an infrastructure gap, not an identity gap |
| Config file present but missing a required field | **Yes — `NOT_CONFIGURED`, names exactly which field** | An incomplete declarative config is itself the ambiguity; guessing the missing field (e.g. from the folder name) would be exactly the heuristic this mechanism is built to avoid |
| Config file corrupt/unparseable | **Yes — `SETUP_FAILED`, names the parse error** | A broken checked-in file is an authoring defect that needs a human/architect fix, not a silent fallback |
| Workspace declares a role but the calling agent's actual behavior would contradict it | Out of scope for this script | Role *consistency* enforcement, if ever needed, belongs in `JOIN_LIVELOOP`/governance, not identity provisioning |

The through-line: this mechanism collapses exactly one class of question (a declared,
unambiguous identity that was previously re-asked every run) and leaves every other stop
untouched, because every other stop already represented a genuine ambiguity, not a repeated
formality.

## Vendor neutrality (`.claude/skills/liveloop` vs `.github/skills/liveloop`)

`setup_liveloop.py` (and `.liveloop-config.json`/`.liveloop-setup.json`/`.mcp.json`) operate
entirely on workspace-root files; nothing in this script's logic depends on which directory the
skill itself was loaded from. This was qualified directly (seq306): the packaged `scripts/`
directory was copied into a disposable fixture workspace under a `.github/skills/liveloop/`-
style path, run against a real `ll-mcp` runtime with a `.liveloop-config.json` at the workspace
root and zero CLI identity args, and reached the same `SETUP_READY` outcome as an equivalent
`.claude/skills/liveloop/`-style invocation, recovering the same registered participant via
live `whois` from a workspace with no prior local `.liveloop-setup.json` record. No code
changed between the two invocations — only the containing directory did. See the master plan's
seq306 section for the full transcript; the fixture itself was disposable and deleted after use.

## Stage-2 provisioning recipe (documentation only — not placed anywhere yet)

When a real Stage-2 workspace (e.g. a future md01 `coder-b-01`-style participant) is ready to be
onboarded deterministically, its provisioner would place a single file at that workspace's root:

```json
{
  "schema": "liveloop-config-v1",
  "project": "<the real project key>",
  "participant": "<the real participant name>",
  "role": "coding-agent",
  "harness": "github-copilot"
}
```

alongside whatever skill-packaging location that harness uses (`.github/skills/liveloop/` for
GitHub Copilot, mirrored byte-identically from this repo's `dev/skills/liveloop/` the same way
`.claude/skills/liveloop/` already is). From that point, `SETUP_LIVELOOP` and `JOIN_LIVELOOP`
both resolve identity with zero CLI args and zero human questions, falling back to the existing
`IDENTITY_CONFLICT`/`LIVELOOP_RUNTIME_NOT_FOUND`/`NOT_CONFIGURED` stops only for the genuinely
ambiguous cases in the table above.

**This recipe is documentation only.** Per the authorizing directive's explicit scope, this
task does not place a `.liveloop-config.json` or a `.github/skills/liveloop/` mirror into any
real md01 workspace, does not start a GitHub Copilot C0 session, and does not register or JOIN
any Stage-2 participant. Doing any of that is separate future work requiring its own directive.
