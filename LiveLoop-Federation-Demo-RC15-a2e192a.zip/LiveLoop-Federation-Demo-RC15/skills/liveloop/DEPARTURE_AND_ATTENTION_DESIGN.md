# Graceful departure + human attention projection — co-design (seq245, REQ-44)

Design decisions for two related pieces of work, both scoped to the single public `liveloop`
skill (no new skill, no parallel authority): (A) `EXIT_LIVELOOP` becomes a responsible
departure from a persistent relationship, not an abrupt kill; (B) high-signal LiveLoop events
become visible to the human without turning every poll/heartbeat into transcript noise.

Written *before* implementing (per seq245's instruction not to implement the seq242/243
candidate literally) — the sections below are the resolved design, and `SKILL.md`/
`STATE_MODEL.md`/`STATUS_SCHEMA.md` implement exactly this.

## A1. Exit boundary / watermark — the key design correction

The seq242/243 candidate proposed snapshotting the participant's own `cursor.last_seen_seq` at
exit-intent time. **seq245 correctly flagged this as wrong**: the cursor only reflects what the
agent has already *fetched and processed* — it says nothing about messages that were already
routed to this participant, sitting unobserved, at the moment exit intent is established. If
watermark = stale cursor, an already-queued-but-unread message would have `seq >` that stale
cursor and get **misclassified as post-departure** even though it existed before departure was
ever requested — exactly the failure mode seq245 asked to avoid.

**Resolved design**: on accepting a valid exit condition, immediately perform one *closing*
`fetch_delta` call before anything else. `exit_watermark_seq = max(seq)` across that delta's
messages (or, if that delta is empty, the current `cursor.last_seen_seq` — nothing was queued,
so the boundary is exactly where the agent already stood). This uses only the existing,
already-monotonic per-project `seq` field (`CONTRACT_V1.md` section 2) — no new distributed
ordering, no new server field, no schema change. It correctly captures "already routed before
intent, whether previously observed or not," because the closing fetch necessarily surfaces
everything sitting in the queue at that exact moment.

Everything in that closing delta (`seq ≤ exit_watermark_seq`) is **pre-boundary work**: must be
dispositioned (completed, handed off with verified acceptance, or truthfully escalated) before
`SAFE_EXIT`. Anything arriving *after* that fetch (`seq > exit_watermark_seq`) is **post-boundary**:
acknowledged, never silently absorbed as a new commitment, and does not affect gate evaluation.

## A2. Disposition vocabulary — minimum terms, no parallel workflow engine

No new MCP/server-side directive values are introduced (`CONTRACT_V1.md`'s directive enum is
unchanged). Three small, documented *conventions* — plain-text tags in message bodies and the
existing `LIVELOOP_STATUS.reason`/`active_task_refs` fields — are enough:

- **`DEPARTURE_DECLINED`** — reply sent for a post-boundary message: departure is already in
  progress, this item was not admitted as a new commitment, and (if determinable) who to
  redirect to.
- **`HANDOFF_REQUESTED`** — reply/message naming a specific successor participant and the
  obligation being transferred. Not yet resolved.
- **`HANDOFF_ACCEPTED`** — the state once acceptance is *verified* (A3 below), not merely sent.

These are vocabulary for message bodies and status `reason` strings, not new enum values
anywhere in the MCP contract or `exit_gate_check.py`'s inputs.

## A3. Handoff acceptance — verified, not assumed

seq245's requirement 7 is explicit: sending a handoff message is not completion. LiveLoop
already exposes exactly the primitive needed: `get_message_recipients(message_id)` returns each
recipient's `ack_at` (`CONTRACT_V1.md` section 2's `Recipient.ack_at`, confirmed live this
round). A handoff is **`HANDOFF_ACCEPTED`** only when `get_message_recipients` on the handoff
message shows the named successor's `ack_at` is non-null (they called `acknowledge_message`
themselves). Until then it remains `HANDOFF_REQUESTED` and the commitment is still open — no
new tool, no new contract field.

## A4. Associated parties — deterministic, bounded, not a broadcast

"Relevant associated parties" = (a) the sender of the message that established exit intent
(the requester), plus (b) the senders/recipients of any thread this agent holds a pre-boundary
open commitment against. Derived entirely from data already fetched while resolving those
commitments (`sender_id`/`get_message_recipients` on the relevant threads) — never
`list_participants` project-wide. This bounds notification to the parties actually affected,
per seq245's explicit "not project-wide broadcast" instruction.

## A5. Safe-exit gate — extended by *meaning*, not by new booleans

seq245 asked whether the existing five booleans can truthfully express the required
conditions, extending only where necessary. Resolved: **no new boolean is added to
`exit_gate_check.py`** — it stays a 5-input pure function, unchanged code. Instead,
`no_open_commitment`'s existing *meaning* is clarified precisely in `STATE_MODEL.md`: a
commitment with an outstanding `HANDOFF_REQUESTED` (not yet `HANDOFF_ACCEPTED`) counts as
still open. The calling agent computes that boolean honestly using A3's verification step; the
gate script itself needs no change. This is the smallest coherent extension — a documentation
change to an existing check's semantics, not new machinery.

## A6. Prompt acknowledgement vs. final confirmation

Two distinct, existing primitives, sequenced explicitly for departure (new SKILL.md step,
seq245 requirement 2/12):
- **Prompt**: on accepting a valid exit condition, `acknowledge_message` the request (already
  standard governance) **and** `reply_message` the requester immediately with "exit accepted,
  entering departure" (+ `EXIT_PENDING` if a boundary disposition is still outstanding, or
  straight to `SAFE_EXIT` if idle) — before any disposition work begins.
- **Final**: on reaching `SAFE_EXIT`, `reply_message`/`send_message` the same requester plus
  every A4 associated party with the `EXITED` confirmation, in addition to the existing
  self-addressed durable `LIVELOOP_STATUS` message (which stays, unchanged, as the durable
  lifecycle record other participants can query later).

## A7. Admission closure and departure-scoped observation

Once exit intent is accepted, `LIVELOOP_CATCHUP`'s interpretation narrows for the remainder of
the relationship: only messages relevant to resolving the boundary (control/approval/handoff-
acceptance/completion evidence for a pre-boundary item) are treated as actionable; anything
else — even if pre-boundary — that is not part of an already-identified open commitment is
`DEPARTURE_DECLINED` rather than opened as new work. `cooperative_wait.py` itself is
unchanged (it remains content-free/no relevance logic of its own, per its own design) — the
narrowing happens at the catch-up/governance layer, exactly where relevance judgment already
lives.

## A8. Fatal path unchanged

seq245 requirement 14 is already satisfied by existing, unmodified machinery: a stall during
departure resolution is indistinguishable, at the mechanism level, from a stall during any
other `WAITING`/`PROCESSING` episode — `check_unattended.py`'s external, never-self-assigned
`AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` classification applies exactly as before. No
special-casing needed or added.

## B1. Attention blocks — a packaged, vendor-neutral script

`scripts/attention_event.py`: a pure-logic CLI (no MCP calls, matching "do not duplicate
governance in scripts") that takes an event type + minimal fields and prints **one** compact
block to stdout. The calling agent includes that block verbatim in its own chat reply for the
harness it's running in — this works in **any** harness without any VS Code dependency,
because it's just text the LLM's own reply already contains.

High-signal event types (render a block): `JOINED`, `WORK_RECEIVED`, `APPROVAL_REQUIRED`,
`RESULT`, `HANDOFF_REQUESTED`, `HANDOFF_ACCEPTED`, `EXIT_ACCEPTED`, `EXIT_PENDING`, `EXITED`,
`AGENT_UNATTENDED`. Ambient mechanics (poll, heartbeat, cursor update, `SILENT_IDLE`, plain
re-arm) are **not** event types this script accepts at all — there is no way to accidentally
render a block for them, by construction, not by convention alone.

**seq300 addendum (final refinement, current production format)**: block density now follows
severity. `INFORMATIONAL` events render as exactly one line:
`{icon} LiveLoop · {LABEL} — {subject}` (subject = the caller's `--detail`, or a built-in
`EVENT_DEFAULT_SUBJECT` per event type, e.g. `WAITING`'s is "Listening for next event"). No
`LiveContext` footer, no separate detail line, no blockquote. `ATTENTION_REQUIRED` events
(`APPROVAL_REQUIRED`/`EXIT_PENDING`/`AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED`) keep the full
multi-line, blockquoted card with the `LiveContext` footer when given — unchanged from v9,
since this is deliberately where the human said the extra detail is actually needed.

**seq259 refinement (live-visible PASS confirmed by the human owner first)**: after seq253's
wiring fix made the block actually appear, the human owner asked for UX quality work,
restructuring the script into three separated pieces rather than one monolithic print:

1. **`AttentionEvent`** — a plain dataclass (event/participant/project/seq/detail) with zero
   rendering logic of its own. Renderers consume it; the data model never encodes presentation.
2. **`render_markdown()`** — the required, portable renderer: native Markdown/blockquote, no
   ANSI escapes, no terminal box-drawing, safe on any chat/Markdown host. Compact hierarchy
   (one bold header line, one `·`-joined identity line, one detail line — each field appears
   exactly once, closing a real duplication defect the human owner flagged: `seq255` had been
   appearing twice because the caller's own `--detail` text happened to restate it, not because
   the renderer itself duplicated anything — the renderer's own output is now verified
   single-occurrence-per-field by a dedicated test).
3. **`render_rich()`** — an *optional* terminal/CLI prototype using the `rich` library. Guarded
   import: if `rich` isn't installed (the default state of this environment — confirmed by
   temporarily installing it to prototype/qualify, then uninstalling it afterward, per the
   explicit "do not make Rich a requirement" instruction), or a caller requests it without
   having it, this silently falls back to `render_markdown()`'s exact output rather than
   erroring. Panels render with border color keyed to severity (yellow for
   `ATTENTION_REQUIRED`, cyan for `INFORMATIONAL`). A real bug was found and fixed while
   qualifying this: `rich.Console(file=None, ...)` defaults to real stdout, so the first
   version printed the panel directly *and* the caller's own `print()` printed it a second
   time (via `export_text`) — fixed by giving `Console` an explicit in-memory `io.StringIO`
   buffer, making the function a pure string-producer like `render_markdown()`, with no direct
   terminal write of its own.

**Severity taxonomy** (three tiers, matching the directive's own naming): `AMBIENT` events are
never reachable here at all — there is no `--event` choice for them, so the tier exists in the
taxonomy but never in this script's actual behavior, by construction. `INFORMATIONAL`
(`JOINED`, `WORK_RECEIVED`, `RESULT`, `HANDOFF_REQUESTED`, `HANDOFF_ACCEPTED`, `EXIT_ACCEPTED`,
`EXITED`) render as a plain card. `ATTENTION_REQUIRED` (`APPROVAL_REQUIRED`, `EXIT_PENDING`,
`AGENT_UNATTENDED`) render with a stronger visual: a Markdown blockquote + a warning icon in
`render_markdown()`, a yellow-bordered panel in `render_rich()`.

Tested: `scripts/test_attention_event.py` (plain `unittest`, no framework dependency, matching
this skill's existing scripts) — 9 focused tests covering the severity taxonomy, no-duplication,
no-ANSI-in-markdown, and the `rich`-unavailable fallback (simulated deterministically via an
import blocker rather than depending on the ambient environment's installed-package state).

## B1b. LiveContext — a second, optional footer layer (seq260)

After the human owner visually confirmed the event card itself, they asked for a small,
information-dense **live-status footer** beneath it — what the relationship/work/listening
state looks like *at render time*, not just what just happened. Resolved as a strict addition,
not a redesign:

- **`LiveContext`** — a second plain dataclass, fully optional and independent of
  `AttentionEvent`. Every field maps to one of `STATE_MODEL.md`'s three axes (seq236): `link`
  (relationship membership, e.g. `JOINED`/`EXIT_PENDING`) + `counterpart` (the specific external
  participant relevant to *this* event, never a guessed global peer); `top_object_type`
  (`TASK`/`APPROVAL`/`HANDOFF`/`EXIT`/`RESULT`/`CONTROL`) + `top_object_ref` + `commitment_state`
  (work commitment axis); `state` (listening/processing axis, e.g. `PROCESSING`/`WAITING`) +
  `cursor_seq` + `waiter_cycle`. This script makes no MCP calls, so every field is
  caller-supplied — a missing field is simply omitted from its row, never guessed, defaulted,
  or shown as a placeholder ("never inferred," per instruction).
- **Rendering**: up to 3 compact rows (`Link`/`Work`/`State`) after a plain `---` separator, each
  row appearing only if it has at least one real field. An event-only call (no `context`, or an
  empty one) renders byte-identical to before this change — fully backward compatible, verified
  by test.
- **Severity interaction**: for `ATTENTION_REQUIRED` events the footer rows are wrapped in the
  same blockquote as the rest of the card (one consistent quoted block, not a mixed
  quoted/unquoted card); `render_rich()` renders the same rows as extra lines inside the
  existing panel, separated by a plain rule character.
- **Tests added**: empty-context no-footer, missing-fields-omitted-not-placeheld, all-rows-present,
  every `TOP_OBJECT_TYPES` value renders, `ATTENTION_REQUIRED` stays fully quoted with a
  footer, no stale/`None` text ever appears, and a `dev`/`.claude` mirror byte-identity check
  (skips gracefully if the counterpart isn't synced yet, rather than false-failing mid-edit).
- **seq300 update**: this footer now renders **only for `ATTENTION_REQUIRED` events**.
  `INFORMATIONAL` events (the large majority — `JOINED`/`WORK_RECEIVED`/`RESULT`/`WAITING`/etc.)
  collapse to one compact line instead (see B1's seq300 addendum below) — `context` is still
  accepted at every call site for uniformity but is deliberately not rendered for them. This
  followed direct human feedback that routine healthy-state cards were correct but too verbose
  to be glanceable; the diagnostic detail this footer carries remains available in durable
  `LIVELOOP_STATUS` JSON and MCP evidence, never deleted, just not repeated in the routine card.

## B1c. Three-layer ownership boundary (seq283/288, made explicit)

seq283's own self-review analysis found this boundary had never been stated as a single,
explicit picture, even though every prior round respected it. Stated here directly:

1. **Host-owned machine evidence** — raw `ll-mcp` MCP tool-call invocation/result JSON,
   rendered by Claude Code's own transcript UI. Not produced by this skill, not suppressible by
   it, not claimed to be. Always present, always the ground truth for what actually happened at
   the protocol level.
2. **Durable LiveLoop machine status** — `LIVELOOP_STATUS` messages, built by
   `status_payload.py`, sent via `send_message` as plain JSON in the message body, durably
   stored and queryable (`query_communication`, per `STATUS_SCHEMA.md`). This is *our* format,
   but deliberately **not** redesigned by the seq245-270 UX work — its job is audit truth, not
   scannability, and it stays raw JSON on purpose.
3. **Human projection** — `attention_event.py`'s cards (seq245-270, extended seq288 to also
   cover durable-status lifecycle states via `JOINING`/`CATCHING_UP`/`PROCESSING`/
   `WAIT_ARMING`/`WAITING`/`HUMAN_RECOVERY_REQUIRED`). An *additional*, optional, human-facing
   rendering layered on top of layer 2's meaning — never itself the source of truth, never a
   replacement for layers 1 or 2, and coexisting with both rather than hiding either (per the
   standing constraint against suppressing host or MCP evidence).

Layers 2 and 3 share the same underlying transition (e.g. entering `WAITING`) but serve
different consumers: layer 2 is for any participant querying history later; layer 3 is for a
human scanning the current conversation right now. Producing both for the same transition is
not duplication in the bad sense (seq270's finding) as long as each is only produced **once** —
one `LIVELOOP_STATUS` message, and (when the agent judges the transition human-relevant) one
attention card, never a card re-pasted a second time in prose.

## B2. VSIX passive projection — OPTIONAL, DEFERRED (seq255 scope correction)

**seq255**: after seq253's build/install work, the human owner clarified the VSIX/Control
Bridge is not part of the required LiveLoop operational path at all — the background
cooperative waiter alone already proves the portable wake mechanism. B2 below is retained as a
design record of what was built (a real `liveloop-control-bridge-0.3.0.vsix`, built and
installed via the VS Code CLI, commit `5dc8a76`), but it is explicitly optional, deferred,
VS-Code-specific tooling: not required for, and carrying no dependency from, `SETUP_LIVELOOP`/
`JOIN_LIVELOOP`/wake/work/`WAIT`/`EXIT_LIVELOOP`. B1 (the Markdown-block mechanism) is the
actual, portable, required attention path across every harness. No further VSIX build,
install, or extension-host qualification work is in scope going forward unless separately
requested.

## B2 (original design, for reference) — additive to the existing Control Bridge, not a new authority

Inspected first, per seq245's instruction: `dev/vscode-control-bridge/extension.js` (v0.2.0)
already has exactly the right shape for this — a `statusBarItem` + `outputChannel`, populated
by passively polling a JSON-lines evidence file that a Python script appends to
(`bridge_poll.py` → `handlePollEvent`). It **never** calls MCP itself and never interprets
directive content — it only relays what the Python side already confirmed. That is the correct
pattern to extend, not replace.

**Design**: `attention_event.py` gains an `--evidence-path` option that, when given, *also*
appends the same event as one JSON line to `scripts/evidence/attention_events.jsonl` (in
addition to printing the Markdown block). The extension gains a **second**, independent status
bar item (`LiveLoop: <last high-signal event>`) that passively tails that file on the same
poll-timer pattern already in place — no MCP client in JavaScript, no new authority, degrades
to simply not showing (existing behavior) if the file doesn't exist. This is deliberately a
**second** status bar item, not a merge into the existing "LiveLoop Bridge: <stage>" one: the
Control Bridge's item reports the *wake-dispatch mechanism's* own state (a different concern)
and must not be conflated with the *LiveLoop relationship's* semantic state this item reports.

Explicitly out of scope this round (per seq245's own "keep optional/later unless genuinely
smallest implementation"): a full VS Code `ChatParticipant`/`ChatResponseStream` integration,
and any webview/card UI beyond the status bar text + output channel line. Both remain valid
future work if a stronger visual surface is wanted; B1 alone already solves the stated problem
(events lost in transcript noise) for every harness, including ones where this VSIX doesn't
even apply (Copilot, Codex).

## Compatibility / degradation across harnesses

- **Claude Code**: B1 works directly (the block is Markdown the agent's own reply contains).
  B2 (VSIX) is Claude-Code-specific tooling for *human-side* visibility in VS Code while a
  Claude Code session runs there — optional, additive, never required for the skill itself.
- **Copilot/Codex/other harnesses**: B1 still works (same mechanism — a script printing
  Markdown, no harness API used). B2 does not apply (no shared VSIX today) — degrades to "no
  passive projection," not a broken feature, consistent with `CAPABILITY_HANDSHAKE.md`'s
  existing honesty-over-parity discipline.

## Explicit non-goals (this round)

- No new MCP tools, no new `ActionDirective` enum values, no schema migration.
- No project-wide notification/broadcast mechanism.
- No VS Code webview/card UI, no `ChatParticipant` integration.
- No change to `action_permitted`/authority semantics anywhere.
- No touching `C:\MyWorkspace\AI Exercises\Trys\LiveLoopTry`.
- No second public skill, no parallel setup/join/exit surface.
