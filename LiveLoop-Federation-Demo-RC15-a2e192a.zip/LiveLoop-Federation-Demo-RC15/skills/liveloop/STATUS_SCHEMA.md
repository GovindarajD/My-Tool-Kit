# LiveLoop agent status — schema and storage (seq210, REQ-44)

## Storage decision: reuse LiveLoop's own message store, not a parallel truth source

LiveLoop's `CONTRACT_V1`/`CONTRACT_V1.1` data model has no native "participant presence"
entity. Rather than invent a side-channel file (a genuinely parallel, unsynchronized truth
source another participant would have no way to query), status is published as an
**`INFORMATION_ONLY` message**, sent by the agent to itself (`to: [own participant name]`),
with `subject: "LIVELOOP_STATUS"` and a structured JSON payload in the body. Any other
participant can query it with the *existing* `query_communication` tool (filter by sender +
subject), or a human can read it via the dashboard — no new storage, no new tool, reusing
exactly what section 24's audit already confirmed is durable (the Git-archived message
store).

This trades a small amount of message-volume noise (one status message per state transition)
for zero parallel-truth risk and zero new infrastructure — consistent with "reuse existing
storage/contracts where possible; avoid parallel truth" (seq210's own instruction).

## Schema (JSON body of the `LIVELOOP_STATUS` message)

```json
{
  "schema": "liveloop-status-v1",
  "participant": "coding-agent-phase1a",
  "project": "liveloop",
  "role": "coding-agent-phase1a",
  "lifecycle_state": "WAITING",
  "commitment_state": "OPEN",
  "last_seen_seq": 209,
  "waiter_relationship_id": "q4-live-01",
  "waiter_cycle": 2,
  "last_transition_at": "2026-09-26T02:01:07Z",
  "reason": "re-armed after processing seq209",
  "recovery_required": false,
  "active_task_refs": [],
  "exit_watermark_seq": null
}
```

| Field | Meaning |
|---|---|
| `lifecycle_state` | One of `STATE_MODEL.md`'s states. |
| `commitment_state` | `OPEN` (something accepted/in-progress) or `NONE` (free to exit cleanly). |
| `last_seen_seq` | The participant's own LiveLoop cursor at the time of this status. |
| `waiter_relationship_id`/`waiter_cycle` | Only present while `WAIT_ARMING`/`WAITING` — correlates to the Q4 heartbeat file's own fields. |
| `reason` | Free text, human-readable, why this transition happened. |
| `recovery_required` | `true` only when this status was published by `check_unattended.py`'s own caller reporting `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` — the agent's own live status never sets this true about itself (it can't know it's unattended; only an external observer can, per Q4's own design). |
| `active_task_refs` | Message/directive IDs the agent currently considers its open commitment(s), if any — lets another participant see *what* is keeping the agent from a clean exit. |
| `exit_watermark_seq` | (seq245) Only present from `EXIT_PENDING` onward: the `max(seq)` snapshot taken at exit-intent time (`STATE_MODEL.md`'s Safe-exit gate section, `DEPARTURE_AND_ATTENTION_DESIGN.md` A1) — the deterministic pre-/post-boundary line for departure. `null`/absent while not departing. |

## Querying another participant's status

`query_communication` filtered to `sender: <participant>, subject: "LIVELOOP_STATUS"`,
take the most recent by `seq` — that message's body is the current, self-reported status.
There is no cross-check against process liveness from LiveLoop's own side (that's
`check_unattended.py`'s job, run locally where the waiter itself lives) — a human/participant
reading a stale-looking `LIVELOOP_STATUS` message with no more recent activity is itself a
weak signal worth combining with `check_unattended.py` if locally available, not treated as
authoritative on its own.
