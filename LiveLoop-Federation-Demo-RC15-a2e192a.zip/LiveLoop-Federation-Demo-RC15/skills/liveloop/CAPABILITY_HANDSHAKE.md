# LiveLoop skill — per-harness capability handshake (seq210, REQ-44; vocabulary formalized seq395)

`JOINING` checks which capabilities the current harness actually has *before* deciding how
`WAIT_ARMING` should behave. No capability is claimed without a qualification round backing
it — matching this whole project's standing discipline (`AdapterCapabilities`, section 24's
Lifecycle Adapter Contract: `None`/unsupported is always honest, never guessed). Verdicts below
are `VERIFIED` / `PARTIAL` / `UNQUALIFIED` / `UNSUPPORTED`, mapped only from evidence that
already exists (qualification rounds, live drills) — never retroactively inferred or upgraded
because a *related* capability passed.

## Three distinct capabilities — do not conflate

seq392/seq395 found real evidence that these three had been getting blurred together. They are
answers to three different questions, and a harness can pass one without the others:

- **`foreground_wait`** (the mechanism this project also calls *cooperative_wait*): the agent
  deliberately runs `cooperative_wait.py` as an ordinary bounded tool call **within an
  already-active turn** the human/architect already started. The turn stays open; nothing
  external resumes anything. Proven for Claude Code (Q1/Q2/Q4, §25.5/25.8).
- **`session_resume`**: a deterministic, **external**, non-natural-language actuator (this
  project's own `wake_dispatcher.py` + a `LifecycleAdapter`) resumes an existing **dormant**
  session — one whose turn already ended — after observing a genuine LiveLoop event, with zero
  human prompt. The session is not continuously running or listening between events; the
  actuator is a separate deterministic process (proven for both Claude Code and Copilot CLI,
  see below), not a held LLM turn and not the host platform reacting on its own.
- **`native_wake`**: the host/platform **itself**, with no external actuator process at all,
  reacts to an external event and resumes/continues an **already-open interactive** session or
  turn. This is a stronger, different claim than `session_resume` — **a `session_resume` result
  must never be described as `native_wake`**, even informally. No harness has ever qualified
  this; two independent investigations (§25.6 for Claude Code, seq389 for GitHub Copilot VS
  Code) each separately found no supported host mechanism for it.

`WAIT_ARMING`/`WAITING` describe LiveLoop's own relationship-level listening readiness — they
are never, by themselves, proof that a model turn is being held open (that's specifically what
`foreground_wait` qualifies). `JOINED_ACTIVE` means the relationship exists and is durable, not
that anything is currently listening. `OBSERVED`/`read_at` is not claimed anywhere in this
table — that field remains unwired project-wide (seq389 finding, reconfirmed seq392, not fixed
here) regardless of which lifecycle capability a harness has.

| Capability | Claude Code | Copilot CLI | GitHub Copilot VS Code (agent mode) | Codex CLI | Antigravity CLI |
|---|---|---|---|---|---|
| `communication` | supported (this whole project) | supported (§24.8/24.9, VERIFIED) | **VERIFIED** — real `claim_enrollment` + message round-trip proven live (seq365–seq386, mock-drill-01-run-a `coder-b-01` and disposable fixture `fwq-probe-01`) | supported for tool *visibility*; tool *calls* blocked by the CLI's own non-interactive approval gap (§24.7/24.8, PARTIAL) | unqualified — investigation halted by a harness safety guardrail, not a product limitation (§24.8) |
| `foreground_wait` | **VERIFIED** (Q1/Q2/Q4, §25.5/25.8) | UNQUALIFIED — not the mechanism qualified at seq392 (that was `session_resume`) | UNQUALIFIED — repeated live retests (seq377/383/386) show the turn ending before arming any wait, even under an explicit qualification-mode escape hatch; not re-attempted since seq389's pivot to `session_resume` research | UNQUALIFIED | UNQUALIFIED |
| `session_resume` | **VERIFIED** — `ClaudeCodeAdapter`, Control Bridge POC items D/E/G: autonomous CREATE→RESUME→RESUME cycles, same session reused, zero human prompts (`dev/vscode-control-bridge/CONTROL_BRIDGE_POC.md`) | **VERIFIED** — `CopilotAdapter`, seq392: two full autonomous wake cycles (same session id both times), server-verified `ROUTED_DURABLE→ACKED→RESULT`, dead-session recovery correctly classified (`dev/scenarios/copilot_cli_autonomous_lifecycle_qualification.md`) | **UNSUPPORTED** — seq389 feasibility research found no VS Code API/command to inject into or resume an existing chat view from outside it; corroborates, not contradicts, the Claude Code finding below for the same host category | UNQUALIFIED — `CodexAdapter.create()` returns `None` (`capabilities.supports_create = False`), consistent with its existing PARTIAL `communication` status; never independently qualified | UNQUALIFIED |
| `native_wake` | **UNSUPPORTED** — falsified for VS Code command routing (§25.6): no `chatParticipants` registration, no command that resumes an existing session | N/A — no held-open interactive listening-session concept exists in this harness outside what `session_resume` already covers | **UNSUPPORTED** — seq389: no API/command found for async re-entry into the same visible chat UX without user input | UNQUALIFIED | UNQUALIFIED |

## Degradation rule

If `communication` is unsupported or unqualified: the skill cannot `JOIN_LIVELOOP` at all —
report this plainly, do not attempt a partial join.

If `communication` is supported but `foreground_wait` is not: `JOINING`/`CATCHING_UP`/
`PROCESSING` all work normally (this is exactly local-communication's existing scope); after
acting, the agent **cannot** autonomously enter `WAITING` — it must report
`JOINED_ACTIVE` (a degraded terminal-for-now status, not `WAITING`) and rely on the next
external trigger to resume it: a human message, or — where `session_resume` is qualified for
this specific harness (Claude Code, Copilot CLI) — the deterministic external actuator
(`wake_dispatcher.py` + the harness's own `LifecycleAdapter`). This is stated as an honest
capability gap, not routed around with an unqualified mechanism, and `JOINED_ACTIVE` is never
relabeled as `WAITING` just because an external actuator happens to be watching.

If `foreground_wait` is supported (Claude Code today): `WAIT_ARMING`/`WAITING` proceed as
designed in `STATE_MODEL.md`, using the already-qualified Q4 resilient waiter.

No harness currently supports `native_wake`. This is not treated as blocking — where
`session_resume` is qualified (Claude Code, Copilot CLI), the project's answer to "how does a
relationship continue without a human typing a prompt" is the deterministic external actuator
(`wake_dispatcher.py`/Control Bridge, §24), explicitly a different session identity than the one
`WAITING` extends. Where neither `foreground_wait` nor `session_resume` is qualified (GitHub
Copilot VS Code agent mode, Codex CLI, Antigravity CLI today), a relationship genuinely cannot
continue without a human message, and that is reported honestly rather than implied otherwise.

## Durable vs ephemeral state (seq395)

The invariant across every capability above is the **durable LiveLoop relationship**, not a
permanently alive model turn:

- **Durable** (server-side, in LiveLoop itself — nothing capability-specific needed): participant
  identity, `ActionDirective`/`Approval` authority state, cursor/Delta position, message/audit
  history, commitments/work references, execution evidence.
- **Durable** (host-adapter-specific, only relevant where `session_resume` is qualified): which
  session a relationship is bound to (`session_registry.json`'s entry shape: `liveloop_participant`,
  `liveloop_project`, `session_id`, `adapter`, `workspace_dir`) — this is what lets an external
  actuator find and resume the *same* session rather than creating a new one.
- **Ephemeral, unless a specific adapter persists it separately**: the actual model
  inference/context window per turn, any local process, any local waiter loop. A `LifecycleAdapter`
  contract already models this correctly (`create()`/`wake()`/`collect_evidence()` — evidence and
  identity persist, the process invocation itself does not) — this section states the principle
  explicitly rather than leaving it implicit.
