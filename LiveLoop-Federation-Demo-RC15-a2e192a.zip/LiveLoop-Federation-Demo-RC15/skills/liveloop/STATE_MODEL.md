# LiveLoop agent lifecycle — state model (seq210, seq236, REQ-44)

Formalizes the JOIN/CATCH-UP/PROCESS/WAIT/EXIT relationship an agent has with LiveLoop,
running *around* the per-wake governance workflow in this skill's own internal
[communication/GOVERNANCE.md](communication/GOVERNANCE.md) module (delta-first, authority
checks, supersession; absorbed from the former standalone `local-communication` skill,
seq226/REQ-44) — this file does not restate or duplicate that module, it sequences it.

**Three independent axes (seq236, made explicit after a real defect conflated the first two)**:
1. **Relationship membership** — is this agent joined to LiveLoop at all right now?
   (`NOT_JOINED`/`JOINING`.../`EXITED` vs. everything in between). Established once by
   `JOIN_LIVELOOP`, ended only by an actual exit condition (see `EXIT_LIVELOOP` in `SKILL.md`).
2. **Work commitment** (`commitment_state` in the status schema: `OPEN`/`NONE`) — is there a
   specific task currently accepted and in progress? Independent of axis 1: a joined
   relationship cycles through many commitments, each opening and closing, without the
   relationship itself ending.
3. **Listening state** (`lifecycle_state`'s `WAIT_ARMING`/`WAITING` vs. `PROCESSING`) — is the
   agent currently blocked in a wait-slice, or actively working?

**The seq236 defect, precisely**: a prior version of the transition table below sent
`PROCESSING` straight to `EXITING` once a commitment reached its terminal state (axis 2
closing), as if that also closed axis 1 (the relationship). It doesn't. A real fresh-agent
test found exactly this: finishing a task ended the whole relationship, forcing the human to
`JOIN_LIVELOOP` again for every subsequent task. Fixed below — `PROCESSING`'s terminal
transition is back to `WAIT_ARMING`, never `EXITING`; only the conditions listed under
`EXIT_LIVELOOP` in `SKILL.md` end axis 1.

## States

| State | Meaning |
|---|---|
| `UNCONFIGURED` | No `SETUP_LIVELOOP` has run yet for this harness/workspace. |
| `SETUP_DISCOVERY`→`IDENTITY_RESOLUTION`→`MCP_CONFIGURING`→`CONNECTIVITY_VERIFY`→`REGISTERING` | `setup_liveloop.py`'s internal sequence (seq212) — not separately surfaced as skill states; the script returns directly to one of `SETUP_READY`/`SETUP_RESTART_REQUIRED`/`IDENTITY_CONFLICT`/`NOT_REGISTERED`/`SETUP_FAILED`. |
| `SETUP_READY` | Provisioning complete: identity resolved, MCP reachable, capability profile recorded. Does **not** imply joined — see `SETUP_LIVELOOP` in `SKILL.md`. |
| `NOT_JOINED` | `SETUP_READY` but no active relationship yet. Also the clean terminal state after `EXITED`. |
| `JOINING` | Identity/capability check, participant resolve (idempotent — see below). |
| `JOINING` | Identity/capability check, participant resolve (idempotent — see below). |
| `CATCHING_UP` | `fetch_delta`, participant-centric, not full history (see Catch-up below). |
| `PROCESSING` | Evaluating authority (`get_action_state`) and acting, per `communication/GOVERNANCE.md`. |
| `WAIT_ARMING` | Publishing status, writing the waiter heartbeat, about to start the wait. |
| `WAITING` | The Q4 resilient cooperative wait is running (`cooperative_wait.py`). |
| `EXIT_PENDING` | `EXIT_LIVELOOP` received but an accepted, non-handoffable commitment is still open. |
| `EXITING` | Safe-exit gate passed; finalizing status/cursor before terminal state. |
| `EXITED` | Clean terminal state. Equivalent to `NOT_JOINED` for a future `JOIN_LIVELOOP`. |
| `AGENT_UNATTENDED` | External-only classification (`check_unattended.py`), never self-assigned — see Q4 (master plan 25.8). A relationship was `WAITING` but its heartbeat went stale. |
| `HUMAN_RECOVERY_REQUIRED` | What `AGENT_UNATTENDED` maps to. No native wake exists for this mechanism — stated honestly, not invented. |
| `PAUSED` / `APPROVAL_REQUIRED` | A directive's `approval_state` is `pending` and nothing else is actionable — remain `WAITING`/idle on LiveLoop's own approval mechanism, not a distinct wait primitive. |
| `DEGRADED_TOOL_GATE` (seq464, Stage-1 freeze) | The agent is alive and its relationship is otherwise healthy, but one or more MCP/tool calls the lifecycle needs are being rejected or timing out at the *host runtime's own* safety/permission layer (e.g. a tool-safety classifier returning no verdict), not by LiveLoop itself. Discovered live during seq459: a real, extended outage where `fetch_delta` recovered on one retry but `record_execution_reference`/`reply_message` failed repeatedly for the rest of that session. **Distinguish this explicitly from any other failure**: LiveLoop's own server, `verify_join.py`, and the relationship's actual state were never the problem — the host's gate was. Never silently retried into a fabricated success, and never bypassed (this skill does not, and must not, attempt to route around a host safety mechanism). When recognized, report it honestly (as this document does) rather than reporting `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED`, which would misattribute the cause to the wrong layer. Recovery is retrying the affected call(s) once the host's gate clears — there is no LiveLoop-side action that fixes this. |

## Transitions

```
NOT_JOINED --JOIN_LIVELOOP--> JOINING
JOINING --resolved--> CATCHING_UP
CATCHING_UP --actionable content--> PROCESSING (commitment_state: OPEN)
CATCHING_UP --nothing actionable (SILENT_IDLE)--> WAIT_ARMING
PROCESSING --RESULT + evidence recorded, commitment terminal--> WAIT_ARMING (commitment_state:
    NONE -- seq236: this is the fix. Finishing a commitment returns to WAIT, it does NOT go to
    EXITING. The relationship (axis 1) stays joined for as many further commitments as arrive.)
WAIT_ARMING --heartbeat live--> WAITING
WAITING --EVENT_DETECTED--> CATCHING_UP
WAITING --TIMEOUT (relationship remains joined, no configured budget exhausted)--> WAIT_ARMING
    (re-arm a fresh wait-slice, same relationship-id, cycle+1 -- ordinary lifecycle
    housekeeping per seq236, default slice length 1800s, ≤180s was a qualification-round-only
    bound, not a product default)
WAITING --TIMEOUT (an explicitly configured relationship-level budget is now exhausted)-->
    [session goes idle; resuming requires a new human/timer trigger -- this is an ordinary,
    designed end of a bounded wait window IF the human/architect configured one, not EXITED
    and not AGENT_UNATTENDED]
WAITING --heartbeat goes stale, external check--> AGENT_UNATTENDED --> HUMAN_RECOVERY_REQUIRED
{any state} --EXIT_LIVELOOP (valid exit condition only -- see SKILL.md's 5-item list;
    commitment completion is explicitly NOT one), no open commitment--> EXITING --> EXITED
{any state} --EXIT_LIVELOOP (valid exit condition only), open commitment--> EXIT_PENDING
    --minimum work to reach safe exit--> EXITING --> EXITED
```

## Idempotent JOIN

`JOINING` always starts with `scripts/verify_join.py` (seq365 — this is the machine-verified
successor to a plain `whois(participant)` call; see `SKILL.md`'s `JOIN_LIVELOOP` step 2 for the
full state handling). It is never followed by an unconditional `register_participant` — that
tool is permanently admin-gated (seq315) and calling it from `JOINING` is exactly the
vulnerability class seq315 fixed (a stale workspace previously used this exact path to
self-register into an unrelated identity).
- `JOIN_VERIFIED` → treat as JOIN (first join of *this* session against an
  already-known identity), proceed.
- `SETUP_REQUIRED`/`ENROLLMENT_REQUIRED` → run `SETUP_LIVELOOP` (which itself never calls
  `register_participant`; see `SKILL.md`'s enrollment section), then retry.
- `IDENTITY_CONTEXT_CONFLICT`/`REVOKED`/`SERVER_VERIFICATION_FAILED` → stop,
  `HUMAN_RESOLUTION_REQUIRED` for the first two; a connectivity retry is reasonable for the
  third, a success claim is not.
- `JOIN_VERIFIED`, and live status already `PROCESSING`/`WAITING`/`WAIT_ARMING` → **no-op**:
  publish a status refresh only, do not re-register, do not start a second waiter for the same
  relationship (mirrors the M1 registry lock's own single-owner discipline, reused not
  reinvented).

## Single-waiter discipline (seq464, Stage-1 freeze)

Exactly one active `cooperative_wait.py` process should exist per participant/project at any
time. This was previously only a convention; a real (harmless, but structurally unguarded)
violation was observed live this engagement — two overlapping wait cycles for the same
participant, started because the first one's result wasn't consumed before the second was
launched. `cooperative_wait.py` now enforces this itself (`check_single_waiter()`): its
heartbeat path defaults to one scoped by `--project`/`--participant` (previously a single file
shared across the whole skill installation — a second, independent bug this also fixes), and a
call that finds a recent heartbeat belonging to a *different* `relationship_id` on that same
path returns `SINGLE_WAITER_VIOLATION` instead of proceeding, rather than silently overlapping.
A call re-arming its own relationship (same `relationship_id`) is always allowed through — this
guards against a second, distinct waiter, not the normal `TIMEOUT`→re-arm cycle.

**Pairing requirement with `check_unattended.py`**: that script has no `--project`/`--participant`
awareness of its own (see its own file — it only ever reads whatever `--heartbeat-path` it's
given) and therefore cannot independently compute the same scoped default. A caller pairing the
two scripts for a given relationship must pass the **same explicit `--heartbeat-path`** to both,
computed the same way `cooperative_wait.py` now does by default
(`evidence/cooperative_wait_heartbeat__<project>__<participant>.json`, non-alphanumeric characters
replaced with `_`) — or `check_unattended.py` will read the wrong (or no) file and report a false
`AGENT_UNATTENDED`/`NO_ACTIVE_RELATIONSHIP`.

## Catch-up (the "social thread" analogy from seq210)

`CATCHING_UP` calls `fetch_delta` exactly as `communication/GOVERNANCE.md` already specifies
(delta first, full thread history only when the delta's own summary or judgment requires it) — this
skill adds no new retrieval logic, only the JOIN/re-JOIN framing around when catch-up runs
(on `JOIN_LIVELOOP`, and every time `WAITING` releases via `EVENT_DETECTED`).

## Safe-exit gate (`EXIT_LIVELOOP`) — graceful departure (seq245)

`EXIT_LIVELOOP` means leaving the relationship *responsibly*, not killing the agent — per
seq210 originally, sharpened by seq245 into a full departure contract. Full design rationale:
[`DEPARTURE_AND_ATTENTION_DESIGN.md`](DEPARTURE_AND_ATTENTION_DESIGN.md) sections A1-A8; this
section states the resulting contract.

**Exit boundary (the watermark)**: on accepting a valid exit condition, before any other
departure work, run one *closing* `fetch_delta`. `exit_watermark_seq = max(seq)` across that
delta (or the current cursor if the delta is empty). This — **not** the participant's own
stale cursor value — is the deterministic pre-boundary/post-boundary line, because the closing
fetch surfaces everything already routed but not yet observed (DEPARTURE_AND_ATTENTION_DESIGN.md
A1 explains why the cursor alone would misclassify unobserved queued work).

**Prompt acknowledgement (before disposition work begins)**: `acknowledge_message` the exit
request (standard governance) and immediately `reply_message` the requester confirming exit is
accepted (and whether it's immediate or `EXIT_PENDING`) — never silently start resolution work
with no reply yet sent.

**Admission closure**: after the watermark is set, any message with `seq > exit_watermark_seq`
is post-boundary — `acknowledge_message` it, reply `DEPARTURE_DECLINED` (in progress, redirect
if known), and never open a new `PROCESSING` commitment for it. This is what prevents the
resolution phase from draining indefinitely.

**Pre-boundary disposition**: every open commitment at or before the watermark must reach one
of: completed (`RESULT` + `record_execution_reference`, as normal), `HANDOFF_REQUESTED` then
verified `HANDOFF_ACCEPTED` (via `get_message_recipients` showing the named successor's
`ack_at` is set — sending the handoff message is not itself completion), or a truthful
escalation/failure report. Never silently dropped.

Exit is safe (→ `EXITING`) only when **all** of the *original, unchanged* five
`exit_gate_check.py` inputs hold:
1. No unrecorded result/evidence for anything already acted on (`record_execution_reference`
   called where applicable).
2. **No open commitment** — clarified meaning (seq245): this now explicitly includes "no
   `HANDOFF_REQUESTED` item whose acceptance is unverified." A sent-but-unacknowledged handoff
   keeps this boolean false; the gate script's code is unchanged, only this input's honest
   computation is stricter.
3. Any pending approval/critical handoff is represented (a message/status exists describing
   it, not silently dropped).
4. Cursor is current (`update_cursor` called).
5. The waiter is stopped and its heartbeat cleared — no orphan (reuses Q4's own clean-exit
   discipline, `cooperative_wait.py` already does this on every clean path).

If any check fails: publish `EXIT_PENDING` status (reason = the specific failing check(s) plus,
for an unresolved handoff, who it's pending on) and, while resolving, continue observing only
traffic relevant to that resolution (control/approval/handoff-acceptance/completion evidence)
via the same `cooperative_wait.py` re-arm mechanism already qualified for normal task cycles
(seq236) — no human "Continue" is needed to drive this forward. Do the *minimum* additional
work needed to satisfy the failing check(s), then re-evaluate — never do unrelated/extra work
under the banner of "reaching a safe exit." This skill does **not** invent override authority:
a human closing the session forcibly is always possible regardless of this gate, exactly as it
always has been throughout this project — the gate governs the *agent's own* voluntary exit
path only.

**Final confirmation**: once `SAFE_EXIT` is reached, notify the requester and every associated
party (DEPARTURE_AND_ATTENTION_DESIGN.md A4 — bounded to senders/recipients of threads with a
resolved obligation, plus the requester; never a project-wide broadcast) with an `EXITED`
confirmation via `reply_message`/`send_message`, in addition to the existing self-addressed
durable `LIVELOOP_STATUS` record (which is unchanged — still the queryable lifecycle truth).
