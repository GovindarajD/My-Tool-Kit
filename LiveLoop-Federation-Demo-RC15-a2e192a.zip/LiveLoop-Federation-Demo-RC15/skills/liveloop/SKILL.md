---
name: liveloop
description: Setup/join/exit/status lifecycle for an agent participating in the LiveLoop Communication Module as an ongoing relationship, not a one-shot check-in. Use when explicitly setting up, joining, rejoining, or leaving a LiveLoop project, when another participant needs to see your current status, or when remaining aware/waiting on LiveLoop while a commitment is open. This is the ONE public entry-point skill — its own internal communication/ module runs per-wake governance; there is no separate skill to discover or invoke.
---

# liveloop

**Package version: v10 (seq300)** — self-contained: every deterministic helper this skill uses
lives under `scripts/` inside this folder, with no import/runtime dependency on the LiveLoop
source repository's `dev/` tree. v1 (seq210-seq226) silently depended on
`dev/s1.5c-wake-integration/wake_dispatcher.py`; seq228 fixed that code-level dependency; seq234
gave every script an unambiguous, fail-closed invocation path; seq236 fixed a relationship-
lifecycle defect (task completion no longer ends the relationship — see **Completing a
commitment (returning to WAIT)** below); seq245 made `EXIT_LIVELOOP` a graceful, responsible
departure (exit boundary/watermark, verified handoff acceptance, notified associated parties —
see the rewritten `EXIT_LIVELOOP` section and
[`DEPARTURE_AND_ATTENTION_DESIGN.md`](DEPARTURE_AND_ATTENTION_DESIGN.md)) and added
[`scripts/attention_event.py`](scripts/attention_event.py) for vendor-neutral human-attention
Markdown blocks. **v6 (seq253) fixes a real wiring gap seq245 left behind**: that script was
documented but never actually called *from* `JOIN_LIVELOOP`/`EXIT_LIVELOOP`'s own steps — a
real `WORK_RECEIVED` episode produced no attention block as a result. Every relevant step now
calls it explicitly (see **Human attention projection** below). **v6 (seq259) refined the
rendering itself**, live-visible PASS confirmed first: `AttentionEvent` data is now separated
from its renderers (`render_markdown`, the required portable path; `render_rich`, an optional
terminal prototype that falls back automatically if `rich` isn't installed — never a hard
dependency), a duplication defect is fixed, and three visual severities
(`AMBIENT`/`INFORMATIONAL`/`ATTENTION_REQUIRED`) are formalized (seq260 added an optional
`LiveContext` live-status footer; seq262 refined the card layout from real screenshot
feedback). **v7 (seq270) implements the approved self-review proposal**
(`dev/skills/liveloop/design/UX_REVIEW.md`): a per-event-type icon layered on the existing
severity styling, and — the higher-value fix the review actually found — an explicit rule
against re-pasting a rendered card's text in prose (see **Human attention projection** below).
Raw MCP tool-result JSON remains host-owned and is not, and cannot be, suppressed by this
skill; that finding is stated honestly rather than worked around. **v8 (seq288) closes the UX
work**: the durable `LIVELOOP_STATUS` lifecycle vocabulary (`JOINING`/`CATCHING_UP`/
`PROCESSING`/`WAIT_ARMING`/`WAITING`/`HUMAN_RECOVERY_REQUIRED`) now has attention-card
projection too, reusing the exact same renderer — the durable status message itself stays
unchanged, raw JSON. `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` compliance is tightened
explicitly to cover the resuming agent's own recovery report, not just prose description. **v9
(seq296) makes the return to stable `WAITING` explicit**, from direct human feedback that
`WAIT` was often inferable but not visually unmistakable: at each *meaningful* entry into
listening (first `WAITING` after `JOIN_LIVELOOP`, after a commitment's `RESULT`, after
recovery) exactly one `WAITING` card renders once the waiter is actually armed — ordinary
re-arms after a plain `TIMEOUT` stay exactly as silent as before (see **Entering WAITING**
below). **v10 (seq300, final refinement — freeze this area absent a functional defect)**: card
density now follows severity. `INFORMATIONAL` events (the large majority) collapse to one
compact line (`{icon} LiveLoop · {LABEL} — {subject}`, no `LiveContext` footer); the diagnostic
detail that footer carried remains in durable `LIVELOOP_STATUS` JSON and MCP evidence, never
deleted, just not repeated in the routine card. `ATTENTION_REQUIRED` events are completely
unchanged — full multi-line card, since that is where the human said the detail is actually
needed. **v11 (seq570, F035) closes a real functional defect found this engagement**: `WAIT_LIVELOOP`
was never actually a defined term in this skill, and was twice misread as a command to pause
already-authorized execution rather than what it always meant — keep the comms-listening loop
armed. See the new **WAIT_LIVELOOP vs HUMAN_HOLD — vocabulary contract** section below for the
formal definition and the structural (not just documentary) separation from `HUMAN_HOLD`, the
one vocabulary that does mean an actual execution pause. See `DISTRIBUTION.md` for
infrastructure prerequisites, and the path-resolution rule below for how to invoke every script
this skill ships.

**Path resolution — mandatory, fail-closed, applies everywhere below**: every script this
skill references (`scripts/setup_liveloop.py`, `scripts/verify_join.py`,
`scripts/check_qualification_mode.py`, `scripts/qualify_and_wait.py`,
`scripts/cooperative_wait.py`, `scripts/check_unattended.py`, `scripts/exit_gate_check.py`,
`scripts/status_payload.py`, `scripts/mcp_client.py`, `scripts/attention_event.py`) means
exactly `<the directory containing THIS SKILL.md file>/scripts/<name>.py`,
resolved from wherever this skill was actually loaded/discovered in the current session —
never from memory, training data, a filesystem/glob search for a same-named file, and never a
path containing `LiveLoop/dev/`, `dev/s1.5c-wake-integration`, or any other location outside
this folder. Invoke it by that resolved absolute/relative path directly (do not `cd` elsewhere
first). If the exact expected path does not exist, **stop and report
`PACKAGED_HELPER_NOT_FOUND`** rather than substituting any other file with the same name found
anywhere else.

Single entry point for `SETUP_LIVELOOP`, `JOIN_LIVELOOP`, `EXIT_LIVELOOP`, `LIVELOOP_STATUS`,
`LIVELOOP_CATCHUP`. Portable across harnesses by declaring capabilities honestly rather than
assuming parity — see [CAPABILITY_HANDSHAKE.md](CAPABILITY_HANDSHAKE.md).

**`JOIN_LIVELOOP` is idempotent JOIN/REJOIN/RESUME — there is no separate `CONTINUE`
command** (seq216 amendment, deliberate, to keep the human command vocabulary small):
- From `EXITED`/`NOT_JOINED`: re-enter using the *same* registration/cursor from
  `SETUP_LIVELOOP`'s stable identity record and catch up from there — never a fresh
  registration, never a full-history replay.
- From `WAITING`/`PROCESSING`: a repeated `JOIN_LIVELOOP` is a status refresh, not a
  duplicate join (see *Idempotent JOIN* in `STATE_MODEL.md`).
- From `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED`: `JOIN_LIVELOOP` may only recover through
  a supported, already-qualified path (a human resuming the session directly, or a
  harness-qualified Control Bridge re-create) — it must never claim a native wake that
  doesn't exist just to make the command appear to have recovered something.

**Layering** (seq210's original structure; absorbed internally per seq226 so nothing is
duplicated and there is exactly one public skill):
1. **This file — skill semantics/policy** (portable, harness-agnostic).
2. **LiveLoop MCP adapter** — the `mcp__ll-mcp__*` tools themselves, governed by this skill's
   own internal [communication/GOVERNANCE.md](communication/GOVERNANCE.md) module (absorbed
   from the former standalone `local-communication` skill, seq226/REQ-44 — not a separate
   skill to discover or invoke).
3. **Wait/lifecycle adapter** — [`scripts/cooperative_wait.py`](scripts/cooperative_wait.py)/
   [`scripts/check_unattended.py`](scripts/check_unattended.py) (Q4, qualified for
   Claude Code today; other harnesses degrade per the capability handshake). As of seq228
   these are packaged inside the skill itself, using [`scripts/mcp_client.py`](scripts/mcp_client.py)
   (an internal MCP stdio client with no dependency on the LiveLoop source repository) rather
   than the repo-development `dev/s1.5c-wake-integration/wake_dispatcher.py` — see
   `DISTRIBUTION.md` for exactly what still must exist outside the skill folder.
4. **Small deterministic scripts** — [`scripts/exit_gate_check.py`](scripts/exit_gate_check.py),
   [`scripts/status_payload.py`](scripts/status_payload.py) — pure logic only, no MCP calls of
   their own; [`scripts/setup_liveloop.py`](scripts/setup_liveloop.py) and
   [`scripts/mcp_client.py`](scripts/mcp_client.py) make read-only connectivity/identity checks
   and (seq228) bounded, discovery-driven `.mcp.json` provisioning — not governance.
   [`scripts/verify_join.py`](scripts/verify_join.py) (seq365) is the mandatory, sole source of
   a `JOIN_LIVELOOP` success claim — see below.

## SETUP_LIVELOOP

One-time-per-harness/workspace provisioning, distinct from `JOIN_LIVELOOP` — see seq212's
amendment. Run `scripts/setup_liveloop.py` (discover-before-create: checks the local
`.liveloop-setup.json` stable-identity record first, then live `whois`; never blindly
registers). Outcomes: `SETUP_READY` (proceed to `JOIN_LIVELOOP`), `SETUP_RESTART_REQUIRED`
(the workspace's `.mcp.json` is missing the `ll-mcp` entry — report this, do not edit a live
session's config in place, since it wouldn't take effect without a restart anyway),
`IDENTITY_CONFLICT` (local record and live `whois` disagree — stop, `HUMAN_RESOLUTION_REQUIRED`,
never silently pick one), `SETUP_FAILED` (genuine connectivity error), `NOT_CONFIGURED` (seq306
— see below). `SETUP_LIVELOOP` never joins a relationship by itself; `JOIN_LIVELOOP` may invoke
it first only when setup is missing.

**Enrollment is required for a first-time identity (seq315/seq319, P0 security fix)**: a real
incident showed that letting an agent call `register_participant` on itself — the pre-seq315
behavior for a `NOT_REGISTERED` outcome — let a stale workspace silently bind to an unrelated
existing identity just by naming it. `register_participant` is now admin-gated and
`setup_liveloop.py` never calls it. If no existing participant is found and
`.liveloop-config.json` carries no `enrollment_token`, the outcome is **`ENROLLMENT_REQUIRED`**
— stop and wait for an admin to issue an invite (via the dashboard's *Invite Agent* flow or
`create_enrollment`) and deliver its one-time token into that file. If a token *is* present,
`setup_liveloop.py` claims it automatically and reports `SETUP_READY`/`CLAIMED` on success, or
one of `ENROLLMENT_EXPIRED`/`ENROLLMENT_REPLAYED`/`ENROLLMENT_MISMATCH` naming exactly what went
wrong — never silently retried or resolved in the caller's favor. Full design/threat model:
`dev/contracts/AGENT_ENROLLMENT_DESIGN.md` in the LiveLoop source repository (outside this
skill's own distributable boundary — see `DISTRIBUTION.md` — so not necessarily present in a
workspace that received only this skill folder; this skill's own copy of what a caller needs is
the decision table below). Decision table: [PROVISIONING.md](PROVISIONING.md).

**Zero-question setup (seq306)**: `--participant`/`--project`/`--harness` are no longer
CLI-required. If a workspace has a declarative `.liveloop-config.json` at its root (schema
`liveloop-config-v1` — distinct from `.liveloop-setup.json`'s machine-generated resolved
state; full schema, precedence rule, and the decision table for which cases still legitimately
ask a question in [PROVISIONING.md](PROVISIONING.md)), `setup_liveloop.py` reads any of those
three fields not given via CLI arg from that file. A field missing from both sources reports
`NOT_CONFIGURED` naming exactly which — this script never infers identity from the workspace
folder name or any other heuristic. This is unrelated to which skill-packaging location loaded
the script (`.claude/skills/liveloop/` or `.github/skills/liveloop/`): both the config file and
the setup file live at the workspace root, so the same script resolves identically either way
(qualified directly — see `PROVISIONING.md`'s *Vendor neutrality* section).

Full state machine: [STATE_MODEL.md](STATE_MODEL.md). Status schema:
[STATUS_SCHEMA.md](STATUS_SCHEMA.md). A new harness type must pass
[HARNESS_JOIN_QUALIFICATION.md](HARNESS_JOIN_QUALIFICATION.md)'s drill, with evidence, before it
is treated as qualified to operate a real identity on a real project — separate from, and in
addition to, the capability handshake above.

## JOIN_LIVELOOP

**0. Qualification-mode shortcut, check this first — a plain file check, not a tool call**: if
`.liveloop-qualification-mode.json` exists in the workspace root, **skip steps 1–6 below
entirely** and instead run `scripts/qualify_and_wait.py` **once, as this turn's only action**,
with `--project "<project_key>"` naming the project that marker file declares (seq386 — this
exists because, even with the framing note below, a harness's turn kept ending right after
step 2's separate verification call, before ever reaching step 6 where the equivalent orchestrator
was previously only invoked from deep inside the procedure; having a qualification-mode
workspace go straight to one call, with no earlier prose step to stop at, removes that failure
mode structurally rather than by instruction alone). Report its JSON result verbatim — that
single call already performs verification, the qualification-mode gate, the experimental status
publish, and the bounded wait internally. If `.liveloop-qualification-mode.json` does not exist,
this is an ordinary join — proceed with steps 1–6 below exactly as before.

**This is one continuous procedure across all 6 steps below, performed in a single turn without
stopping in between and without waiting for further human input between steps** (seq383 —
found live: a harness stopped after step 2's verification succeeded, treating that
verification alone as if it fulfilled the whole `JOIN_LIVELOOP` request, and never reached
`LIVELOOP_CATCHUP` or entering a wait). **No individual step's completion — including step 2's
`JOIN_VERIFIED` result — marks `JOIN_LIVELOOP` as done.** The procedure is only actually
finished at step 5's commitment-handling path, or step 6's `WAITING`/`JOINED_ACTIVE`
publication, or an explicit stop condition named in steps 1–2. Phrases below like "include this
block in your reply" mean *fold it into the one reply this whole turn eventually produces* —
they are not, individually, an instruction to stop and answer now.

1. Capability handshake (once per session): confirm `communication` is reachable for this
   harness (per `CAPABILITY_HANDSHAKE.md`); if not, stop and report — do not attempt a
   partial join.
2. **Machine-verified resolve (seq365, mandatory — replaces the old "call `whois` yourself"
   step)**: run `scripts/verify_join.py --workspace-dir "<workspace_root>" --project
   "<project_key>"` (path-resolution rule above applies). This is the **only** thing that may
   ever justify claiming `Joined LiveLoop` — its raw JSON output is the single source of truth,
   never a paraphrase, and never a substitute reasoned from `.liveloop-setup.json` alone, a
   local role/task file (`CLAUDE.md`, `role.json`, or anything else this skill does not itself
   own), or any other local assumption. **If this script was not actually executed, a `JOINED`
   claim is forbidden — full stop.**
   - `JOIN_VERIFIED` (state) → proceed. Its JSON carries `project_id`/`participant_id`/
     `status`/`cursor_last_seen_seq`/`verified_at`/`evidence_digest` — include this block
     verbatim in your reply, exactly like an `AttentionEvent` card (never re-typed in prose).
   - `SETUP_REQUIRED` → run `SETUP_LIVELOOP` first (see above), then retry this step. Never
     invent a `register_participant` call — that tool is permanently admin-gated (seq315) and
     calling it from `JOIN_LIVELOOP` is exactly the pre-seq315 vulnerability this replaced.
   - `ENROLLMENT_REQUIRED` → stop; an admin must issue/deliver an invite. Never proceed as if
     joined.
   - `IDENTITY_CONTEXT_CONFLICT` → stop, `HUMAN_RESOLUTION_REQUIRED`. This means the workspace's
     `.liveloop-config.json`, its cached `.liveloop-setup.json`, and the live server disagree
     about who/what project is being joined — the exact shape of the seq363 incident. Never
     silently pick a side; report the conflict verbatim and wait for a human.
   - `REVOKED` → stop. A revoked identity can never be reported as joined, regardless of what
     any local file says.
   - `SERVER_VERIFICATION_FAILED` → stop, genuine connectivity error; retry is reasonable, a
     success claim is not.

   **`JOIN_VERIFIED` continues immediately to step 3 below, same turn — it is a passed
   checkpoint, not a finished task.**
3. Publish status `JOINING` (`scripts/status_payload.py` → `send_message`, `to: [self]`,
   `subject: "LIVELOOP_STATUS"`, `directive: INFORMATION_ONLY`). **On the first successful
   `JOIN_LIVELOOP` of a relationship** (not a repeated status-refresh join per the idempotent
   rule above), also run `scripts/attention_event.py --event JOINED` and include its block in
   your reply (seq253 — this call is mandatory here, not merely available; see the *Human
   attention projection* section for why this line exists).
4. Run `LIVELOOP_CATCHUP` (below).
5. If catch-up found actionable content: run `scripts/attention_event.py --event WORK_RECEIVED`
   (include its block in your reply) **before** entering the internal `communication/GOVERNANCE.md`
   module's normal per-wake workflow (intake → authority check → act), publishing status
   `PROCESSING` first. If the authority check finds an `approval_required` directive still
   `pending`, also run `--event APPROVAL_REQUIRED` at that point. **When that work concludes,
   run `scripts/attention_event.py --event RESULT` (include its block), then do not stop or
   `EXIT_LIVELOOP`** — go to *Completing a commitment (returning to WAIT)* below. Finishing a
   task is a **commitment**-level event, not a **relationship**-level one (seq236 — see the
   distinction spelled out at the top of `STATE_MODEL.md`).
6. Otherwise (`SILENT_IDLE`): if `foreground_wait` is supported for this harness, publish
   `WAIT_ARMING` then start `cooperative_wait.py`, per the *Entering WAITING* section below.
   If not supported, publish `JOINED_ACTIVE` and stop — the degraded case from
   `CAPABILITY_HANDSHAKE.md`, not routed around. (A disposable-fixture qualification attempt
   never reaches this step by this path at all — see step 0 above, which diverts to
   `qualify_and_wait.py` before step 1 even runs, specifically because reaching this point via
   steps 1–5 first was the failure mode seq386 fixed.)

## LIVELOOP_CATCHUP

Exactly the internal [communication/sub-skills/communication-intake.md](communication/sub-skills/communication-intake.md)
step (`fetch_delta`, delta first, full thread history only if genuinely needed) — this skill
adds no new retrieval logic, only the framing of *when* it runs: on `JOIN_LIVELOOP`, and every
time `WAITING` releases via `EVENT_DETECTED`.

## CHECK_LIVELOOP (seq464, Stage-1 freeze) — human-triggered doorbell for harnesses without `foreground_wait`

**Purpose**: a lightweight, repeatable command for harnesses that cannot run `cooperative_wait.py`
(no bounded blocking wait supported — see `CAPABILITY_HANDSHAKE.md`; GitHub Copilot's CLI-based
`session_resume` path is the current example, per the VS Code Agent Host investigation this
engagement ran). Where Claude Code's `foreground_wait` support means the relationship can sit in
`WAITING` and be released by a real `EVENT_DETECTED`, a harness without that support has no
automatic doorbell at all — a human (or an external scheduler) must periodically say
"`CHECK_LIVELOOP`" instead. This formalizes that as a first-class, documented command rather than
an ad hoc "Continue your role" with no defined contract.

**`CHECK_LIVELOOP` MUST carry zero execution authority by itself.** The phrase alone never
authorizes any action — it only triggers the agent to go look. This is the same non-negotiable
rule `JOIN_LIVELOOP`'s own `verify_join.py`/`get_action_state` discipline already enforces
everywhere else in this skill, restated explicitly here because `CHECK_LIVELOOP` is the one entry
point most likely to be typed casually by a human who might otherwise expect it to also mean
"and do whatever's pending."

**Preconditions**: the relationship must already be joined (`JOIN_LIVELOOP` has run at least once
this session/workspace, per its own idempotent-JOIN rule) — `CHECK_LIVELOOP` is not a substitute
for `JOIN_LIVELOOP` and does not itself perform `verify_join.py`. If called while `NOT_JOINED`,
the correct response is to run `JOIN_LIVELOOP` first (which will reach `LIVELOOP_CATCHUP` as its
own step 4 anyway), not to invent a partial catch-up outside that procedure.

**Procedure** (a single, complete turn, same as `JOIN_LIVELOOP` steps 4–6):
1. Run `LIVELOOP_CATCHUP` (`fetch_delta`).
2. If nothing actionable: `SILENT_IDLE` — no reply, no status change beyond an ordinary re-arm
   note if this harness tracks one; explicitly do not invent a "checked, nothing found" message
   (matches the existing `SILENT_IDLE` rule for `EVENT_DETECTED` elsewhere in this file).
3. If actionable content exists: for **each** directive found, run `get_action_state` (never
   infer `action_permitted` from message content or phrasing) and choose exactly one of
   **ACT** (permitted, do the work, `record_execution_reference` + `RESULT` reply, per
   `communication/GOVERNANCE.md`), **WAIT** (not yet permitted/effective — leave it, report
   nothing wrong), **ESCALATE** (denied/conflicting/`HUMAN_RESOLUTION_REQUIRED` per the same
   rules `JOIN_LIVELOOP` step 2 already uses for identity conflicts), or **RESPOND**
   (`INFORMATION_ONLY`/handshake-shaped content that only needs an acknowledgement, not a
   commitment — mirrors the existing "irrelevant or empty event is not a commitment" rule).
4. Publish/refresh `LIVELOOP_STATUS` reflecting whatever was actually found and done — the
   durable JSON record stays the single source of truth regardless of which entry point
   (`WAITING` release or `CHECK_LIVELOOP`) produced this turn.
5. End the turn. There is no implicit re-arm to wait for — that's precisely the capability this
   harness doesn't have. The next `CHECK_LIVELOOP` is whenever the human/scheduler next issues it.

**Relationship to `JOIN_LIVELOOP`**: `JOIN_LIVELOOP` remains the only command that establishes or
resumes relationship membership (axis 1 in `STATE_MODEL.md`) and the only one that runs
`verify_join.py`. `CHECK_LIVELOOP` operates entirely *within* an already-joined relationship — it
is the harness-appropriate substitute for what `EVENT_DETECTED` does automatically for a harness
with `foreground_wait`, nothing more.

**Do not claim `AUTO_WAKE` support for a harness whose only mechanism is `CHECK_LIVELOOP`.**
Per `CAPABILITY_HANDSHAKE.md`'s vocabulary, a harness on this path is honestly `HUMAN_CHECK` —
external durable session-resume (where qualified, e.g. GitHub Copilot's `session_resume`) is a
separate, additional capability that MAY also apply and should be reported on its own terms, not
conflated with `CHECK_LIVELOOP` itself being a wake mechanism.

## Entering WAITING (harness supports `foreground_wait`)

**seq296 — meaningful entry vs. ordinary re-arm**: this procedure is entered from two different
contexts, and they render differently. A **meaningful entry** is the first `WAITING` after
`JOIN_LIVELOOP`, after a commitment's `RESULT` (*Completing a commitment* below), or after a
recovery (`AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` → `JOIN_LIVELOOP`) — these are the
points where a human could otherwise be left guessing whether the agent actually returned to
listening. An **ordinary re-arm** is step 4 below (after a plain `TIMEOUT`, same relationship
continuing) — this stays exactly as ambient/silent as it always has been; nothing in this
seq296 change adds a card to routine re-arms.

1. Write the status payload (`lifecycle_state: WAIT_ARMING`, `commitment_state: NONE`).
   `WAIT_ARMING` itself stays transient/no-card — it is not yet the confirmation point, since
   the waiter has not actually started running.
2. Run the waiter (`scripts/cooperative_wait.py`, resolved per the path-resolution rule above
   — e.g. `python "<skill_dir>/scripts/cooperative_wait.py" --workspace-dir "<workspace_root>" ...`,
   never `cd`-ing into any other directory first) as a single bounded, non-backgrounded
   foreground call, framed as a direct, present-tense, explicitly bounded action for THIS
   slice — not an open-ended self-announced loop. **On a meaningful entry only**: once this
   call has actually started (the waiter is armed and listening), run
   `scripts/attention_event.py --event WAITING` (include its block) — this is the explicit,
   unmistakable human-visible confirmation that the agent is listening for the next event, not
   merely that the prior work ended. **seq300**: `WAITING` is `INFORMATIONAL`, so this renders
   as one compact line (`◌ LiveLoop · WAITING — Listening for next event` by default, or your
   own short `--detail` in place of that default subject) — `--link`/`--state`/other
   `LiveContext` flags may still be passed for call-site uniformity but are not rendered in this
   compact form; that diagnostic detail lives in the durable `LIVELOOP_STATUS` publish (step 1)
   instead, not fabricated or duplicated here. Do not restate the same status in prose
   afterward (the existing no-re-paste rule, unchanged) unless further explanation is genuinely
   needed.
   **Wait-slice length (seq236)**: the product default is `--timeout-seconds 1800` (30
   minutes — this is what the script now defaults to; do not pass a shorter value unless you
   have an actual reason to). The `≤180s` figure used in earlier qualification rounds (Q4,
   master plan 25.5-25.8) was a bound chosen *for that testing session specifically* (to keep
   classifier-sensitive framing risk low during active experimentation) — it was never the
   product default and must not be treated as one.
   **Relationship persistence (seq236)**: a `TIMEOUT` on one slice does **not** end the
   relationship — see step 4. There is no fixed "≤3 cycles" product cap either; a joined
   relationship re-arms indefinitely until an actual exit condition (listed under
   `EXIT_LIVELOOP` below) occurs. If a human or architect wants this specific relationship
   bounded more tightly (a cycle count, a total elapsed-time budget), that is an explicit
   instruction they give when initiating it (matches exit condition 5, "explicitly configured
   self-exit policy") — never a number this skill invents or assumes on its own.
3. On `EVENT_DETECTED`: publish status `CATCHING_UP`, go to `LIVELOOP_CATCHUP`.
4. On plain `TIMEOUT` (no configured relationship budget exhausted): re-arm immediately
   (`WAIT_ARMING` → `WAITING` again, same `--relationship-id`, `--cycle` incremented) — this is
   ordinary lifecycle housekeeping, not a semantic event, and must not publish any status other
   than the `WAIT_ARMING`/`WAITING` re-arm itself (no stale `PROCESSING`, no spurious message,
   and — seq296 — **no attention card either**; this is explicitly the "ordinary re-arm" case
   step 2 above distinguishes from a meaningful entry).
5. On `TIMEOUT` with an explicitly configured relationship budget now exhausted, or
   `FATAL_WAITER_LOST`: publish the corresponding status and stop — resuming needs a new
   external trigger (a human message, or a harness-qualified re-create path). This is a
   designed, ordinary ending when it happens, not a failure to smooth over.
6. `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` are **never self-assigned** — they are only
   ever produced by a *separate* invocation of `check_unattended.py` reading a stale
   heartbeat, per Q4's own design (a dead waiter cannot report its own death). This honest
   limitation is unchanged by seq236: if the Claude turn/process itself dies before a re-arm
   runs, cooperative wait cannot create a new turn on its own — there is still no native wake.

## WAIT_LIVELOOP vs HUMAN_HOLD — vocabulary contract (v11, seq570, F035)

**The incident this closes**: this engagement, this session, a human's `WAIT_LIVELOOP`
instruction was twice misread by the coding agent as "pause/hold already-authorized work,"
stalling real execution that should have continued. `WAIT_LIVELOOP` was never actually defined
anywhere in this skill before this section — the agent guessed a meaning for an undefined
phrase, and guessed wrong. The fix is to define it explicitly, and to separate it structurally
from the one vocabulary that *does* mean "pause."

**`WAIT_LIVELOOP` is hereby a defined, recognized human instruction**, a synonym for "run (or
re-enter) *Entering WAITING* above" — i.e., ensure the comms-listening loop
(`cooperative_wait.py`) is armed and running. It is a **communication-channel** instruction
only. It carries **zero implication for the execution-authority channel**:

- It does **not** mean pause, hold, defer, decline, or wait-before-acting on any already-open
  commitment or `action_permitted:true` directive. If work is currently authorized and open,
  `WAIT_LIVELOOP` does not change that — finish and report it per *Completing a commitment*
  below, exactly as if `WAIT_LIVELOOP` had not been said.
- It does **not** end or interrupt a relationship — it is not a variant spelling of
  `EXIT_LIVELOOP`.
- Every other listening-channel vocabulary item means exactly the same communication-only thing
  and must never be read as an execution pause either: `WAITING`, `WAIT_ARMING`,
  `CHECK_LIVELOOP`, and `PresenceState::LISTENING` (the P3 presence value an instance
  self-reports while idle/armed).

**`HUMAN_HOLD` is the one and only vocabulary that means an actual execution pause**, and it is
never inferred from a listening-channel phrase — it only exists as one of two explicit,
structurally distinct mechanisms, each requiring a deliberate act, never elapsed time or a
guess:

1. A participant instance explicitly self-reports `PresenceState::HUMAN_HOLD` via
   `report_presence` (`liveloop-core::presence::PresenceState`, `liveloop-storage::presence_queries`)
   — this is advisory telemetry, never itself an authority gate, but names the instance's own
   state honestly.
2. An actual directive carries `HOLD` (`liveloop-core::directive::Directive::Hold`) or a pending
   `APPROVAL_REQUIRED`/`approval_state: pending` from `get_action_state` — this *is* the
   authority gate; `action_permitted` is `false` until an explicit `PROCEED`/approval changes it.

**Structural enforcement, not just documentation** (so this cannot silently regress): `PresenceState`
is a plain Rust enum with `Listening` and `HumanHold` as two of seven variants with no
conversion path between them — nothing in `effective_state`/`effective_state_for_reader` can
turn a `Listening` report into a `HumanHold` effective state, or vice versa; the only way a row's
effective state becomes `HumanHold` is an explicit `report_presence` call that said so. See
`liveloop-core/src/presence.rs::tests::only_human_hold_has_no_ttl` and the hardening tests added
this pass for the one-directional, explicit-transition-only property. `WAYS_OF_WORKING.md`'s
"WAIT_LIVELOOP vs HUMAN_HOLD" section (added alongside this one) is the canonical narrative
record of the incident and this correction, so future agents reading either document land on
the same contract.

## Completing a commitment (returning to WAIT)

**seq236, the core fix**: finishing the work from one `PROCESSING` episode
(`record_execution_reference` + a `RESULT`/reply message sent, per `communication/GOVERNANCE.md`)
ends that **commitment**, not the **relationship**. Do this, then go straight back to
*Entering WAITING* above (step 1) — do **not** run `EXIT_LIVELOOP`:

1. Publish status with `commitment_state: NONE` and `lifecycle_state: WAIT_ARMING` (reusing
   the *same* `waiter-relationship-id` this relationship has already been using, if one
   exists — a fresh commitment does not start a fresh relationship).
2. Re-arm `cooperative_wait.py` (*Entering WAITING* step 2) to listen for the next event.
3. Repeat for as many commitments as arrive while the relationship remains joined — two, ten,
   or zero. `JOIN_LIVELOOP` establishes the relationship once; task/result cycles happen
   *inside* it without any repeated `JOIN_LIVELOOP`/"Continue your role" from the human, for as
   long as the same foreground turn/session can keep running bounded wait-slices.

An **irrelevant or empty event** (an `EVENT_DETECTED` whose delta turns out to carry nothing
actually actionable — routine status noise, a message not meaningfully addressed to you) is
**not** a commitment: do not send a semantic reply, do not publish `PROCESSING`; go straight
back to `WAIT_ARMING`/`WAITING` (matching the SILENT_IDLE rule already established for wake
framing).

## EXIT_LIVELOOP

`EXIT_LIVELOOP` is a **relationship-level steering command** — call it only for one of these,
never because a task/commitment happened to finish (seq236, the defect this fixes; a finished
commitment goes to *Completing a commitment* above instead):

1. Explicit human steering (a "leave/exit LiveLoop" instruction).
2. An authorized LiveLoop relationship/control `EXIT` directive from an authority who may
   issue one (checked via `get_action_state` like any other directive — never inferred).
3. A relationship-level deadline/budget the human/architect explicitly configured for this
   relationship, now expired (see *Entering WAITING* step 2 — never a number this skill
   invents on its own).
4. An unrecoverable lifecycle/infrastructure failure — publish the truthful recovery state
   (`AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` via `check_unattended.py`, per its own rule
   that this is never self-assigned) rather than fabricating a clean `EXITED`.
5. An explicitly configured self-exit policy, if one exists and is within the calling agent's
   authority for this relationship.

Steps once a valid exit condition applies — the full graceful-departure contract (seq245; see
[`DEPARTURE_AND_ATTENTION_DESIGN.md`](DEPARTURE_AND_ATTENTION_DESIGN.md) for the design
rationale, `STATE_MODEL.md`'s Safe-exit gate section for the precise contract this sequences):

0. **Prompt acknowledgement**: `acknowledge_message` the request, then immediately
   `reply_message` the requester confirming exit is accepted (state whether it's immediate or
   pending) — before any disposition work begins. Run
   `scripts/attention_event.py --event EXIT_ACCEPTED` (include its block) at this step.
1. **Set the exit boundary**: run one closing `fetch_delta`; `exit_watermark_seq = max(seq)`
   across it (or the current cursor if empty). Do this *before* gathering gate inputs.
2. Gather the five gate inputs from the agent's own actual state — `no_open_commitment` now
   means what `STATE_MODEL.md` clarifies: an unverified `HANDOFF_REQUESTED` still counts as
   open.
3. Run `scripts/exit_gate_check.py` with those five booleans (script itself unchanged).
4. `SAFE_EXIT` → stop the waiter if one is running (clean exit, heartbeat clears itself),
   `update_cursor`, publish status `EXITED`, run `scripts/attention_event.py --event EXITED`
   (include its block), then `reply_message`/`send_message` the requester and every associated
   party (`DEPARTURE_AND_ATTENTION_DESIGN.md` A4) an `EXITED` confirmation — not just the
   existing self-addressed `LIVELOOP_STATUS` record, which stays as-is.
5. `EXIT_PENDING` → publish status `EXIT_PENDING` with the `failing_checks` as `reason`, and
   run `scripts/attention_event.py --event EXIT_PENDING` (include its block). For each open
   pre-boundary (`seq ≤ exit_watermark_seq`) commitment: complete it normally, or send
   `HANDOFF_REQUESTED` to a specific successor (run `--event HANDOFF_REQUESTED` at that point)
   and wait for verified `HANDOFF_ACCEPTED` (`get_message_recipients` showing their `ack_at`
   set — not just "message sent"; run `--event HANDOFF_ACCEPTED` once verified), or truthfully
   escalate/report failure. While resolving, re-arm `cooperative_wait.py` as usual (no human
   "Continue" needed) but treat any message with `seq > exit_watermark_seq` as post-boundary:
   `acknowledge_message` it, reply `DEPARTURE_DECLINED`, never open it as a new commitment.
   Never abandon accepted work silently, never expand scope under the banner of "reaching a
   safe exit." Re-run the gate once dispositions land.

## LIVELOOP_STATUS

Publish (own current status via `scripts/status_payload.py` → `send_message`) or query
(`query_communication`, filter `sender: <participant>, subject: "LIVELOOP_STATUS"`, most
recent by `seq`) — see `STATUS_SCHEMA.md` for the full schema and querying notes.

## Human attention projection (seq245, wiring fixed seq253)

For high-signal events only (`JOINED`, `WORK_RECEIVED`, `APPROVAL_REQUIRED`, `RESULT`,
`HANDOFF_REQUESTED`, `HANDOFF_ACCEPTED`, `EXIT_ACCEPTED`, `EXIT_PENDING`, `EXITED`,
`AGENT_UNATTENDED`), run `scripts/attention_event.py` **exactly once per event** — its own
printed output (the tool call's visible result) *is* the human-facing card. Never call it for
ambient mechanics (poll, heartbeat, cursor update, `SILENT_IDLE`, a plain re-arm) — the script
has no event type for those, by design, so there's nothing to accidentally render.

**seq270 finding, fixed here**: earlier practice had this agent *also* re-typing/re-pasting the
same card text a second time into its own prose reply after the tool call already printed it —
real, observed duplication (`dev/skills/liveloop/design/UX_REVIEW.md` section 1), not a
hypothetical concern. **Do not re-paste a card's text.** The tool call's own printed block is
the complete, sufficient human-facing signal; refer to it with a short lead sentence if useful
("current status:" or similar) but never restate its content. This applies to every event type
above — one call, one rendering, no manual duplication anywhere in the reply.

**seq253 finding, fixed here**: v5 (seq245) documented this script but never actually
cross-referenced a call to it *from* the procedural steps that produce these events — a real
missing-wiring defect (confirmed live: a real `WORK_RECEIVED` episode produced no attention
block, because `JOIN_LIVELOOP`/`EXIT_LIVELOOP`'s own steps never said to call it). Fixed:
`JOIN_LIVELOOP` step 3 (`JOINED`), step 5 (`WORK_RECEIVED`, `APPROVAL_REQUIRED`, `RESULT`), and
every `EXIT_LIVELOOP` step (`EXIT_ACCEPTED`, `EXIT_PENDING`, `HANDOFF_REQUESTED`,
`HANDOFF_ACCEPTED`, `EXITED`) now explicitly call it as a mandatory part of that step, not an
optional afterthought. `AGENT_UNATTENDED`/`HUMAN_RECOVERY_REQUIRED` are the events this agent's
own *same* turn never self-assigns (per the never-self-assigned rule) — it is
`check_unattended.py`'s *caller* who runs `--event AGENT_UNATTENDED`/`--event
HUMAN_RECOVERY_REQUIRED` if that check reports it. **seq288 compliance tightening**: this
includes the resuming agent's own recovery turn — if you called `check_unattended.py` (or were
told its result) as part of a `JOIN_LIVELOOP` recovery and it reported `AGENT_UNATTENDED`, you
are that caller; render the card as part of reporting the recovery, not only in prose. (A real
instance of describing this only in prose, never actually calling the script, was found and
corrected in this same engagement — see `dev/LIVELOOP_STRENGTHENING_MASTER_PLAN.md` section
25.23.)

**seq288 (UX closure): status projection for durable `LIVELOOP_STATUS` lifecycle states.** The
event taxonomy above also includes `JOINING`, `CATCHING_UP`, `PROCESSING`, `WAIT_ARMING`,
`WAITING`, and `HUMAN_RECOVERY_REQUIRED` — the durable-status vocabulary
(`STATUS_SCHEMA.md`) now has attention-card representation too, using the exact same
`AttentionEvent`/`LiveContext`/renderer machinery, not a second card system. The **durable
`LIVELOOP_STATUS` message itself is unchanged** — still raw JSON via `status_payload.py`, still
the audit/machine truth; this projection is an *additional*, optional human-facing rendering of
what that status means, never a replacement for it and never itself treated as authoritative.
As with every other event type, the calling agent decides *when* a status transition is
human-relevant enough to project — an ordinary `WAIT_ARMING`/`WAITING` re-arm after a plain
`TIMEOUT` stays silent (per *Entering WAITING* step 4's existing "no stale/spurious status"
rule, unchanged); a first entry into `WAITING` after `JOIN_LIVELOOP`, or a `PROCESSING`/
`CATCHING_UP` transition worth a human's attention, is a reasonable case to project. No new
heuristic is invented here — this is the same relevance judgment `SKILL.md` already asks for
everywhere else, now simply with a card available for these states too.

**OPTIONAL/DEFERRED, explicitly (seq255 scope correction)**: the Markdown-block mechanism above
(B1) is the actual, portable, required attention path — it is what every event listed above
means. The VS Code Control Bridge's passive status-bar projection (`--evidence-path`, read by
`dev/vscode-control-bridge/extension.js`, section B2 of
[`DEPARTURE_AND_ATTENTION_DESIGN.md`](DEPARTURE_AND_ATTENTION_DESIGN.md)) is **optional,
deferred, VS-Code-specific tooling — not required for `SETUP_LIVELOOP`/`JOIN_LIVELOOP`/wake/
work/`WAIT`/`EXIT_LIVELOOP` in any way**, lives entirely outside this skill folder, and this
skill has no dependency on it, on VS Code, or on the Control Bridge being installed, running,
or even present. Never assume it or build/install/qualify it as part of operating this skill.
