# Distributable boundary (seq228, REQ-44)

What "only the `liveloop` skill" actually means, made explicit after the
seq228 clean-workspace acceptance test found the v1 package silently assumed
the LiveLoop source repository was present.

## What must exist OUTSIDE this folder (legitimate prerequisites)

1. **A supported agent harness with Python 3 on PATH.** The skill's
   deterministic helpers (`scripts/*.py`) are invoked as ordinary subprocess
   calls by the agent; no particular Python packages beyond the standard
   library are required.
2. **An installed, running LiveLoop runtime (`ll` / `ll.exe`) reachable from
   this machine, with a data directory.** This is infrastructure the skill
   consumes, not something it provisions from nothing (see "Out of scope"
   below) — the skill discovers *how to launch* an already-installed
   runtime, it does not install the runtime itself.
3. **The harness's own skill-discovery mechanism** pointed at a COMPLETE copy of this folder
   (for Claude Code: `.claude/skills/liveloop/` must be a full, self-contained mirror of
   `dev/skills/liveloop/` — SKILL.md, STATE_MODEL.md, CAPABILITY_HANDSHAKE.md, STATUS_SCHEMA.md,
   PROVISIONING.md, `communication/`, and `scripts/` all present under `.claude/skills/liveloop/`
   itself, not a
   pointer file that only references those paths under `dev/`).

**seq231 finding, fixed here**: `.claude/skills/liveloop/` previously held only a one-file
"thin pointer" `SKILL.md` that told the reader to go read `dev/skills/liveloop/SKILL.md` and
friends. That is a real distribution defect: Claude Code's actual skill-discovery boundary
*is* `.claude/skills/liveloop/`, so if only that folder is copied to a fresh workspace (which
is exactly what "give a fresh agent only the liveloop skill" means), the referenced `dev/`
paths — including every script this skill needs to run — do not exist there. This is very
likely what caused a fresh agent to describe finding helper scripts "through PYTHONPATH in the
LiveLoop repo": not a real code dependency (the scripts themselves have zero import on
`dev/s1.5c-wake-integration`, verified under an adversarial poisoned `PYTHONPATH` — see master
plan section 25.13), but a plausible, reasonable reaction to a genuinely incomplete
`.claude/skills/liveloop/` folder. `dev/skills/liveloop/` remains the source of truth (kept
there for portability to non-Claude-Code harnesses and for git history); `.claude/skills/liveloop/`
is now a full mirror copy of it, not a pointer, and must be re-synced (`cp -r` the whole
`dev/skills/liveloop/` tree over it) whenever the source changes.

Nothing else. In particular, **no part of this repository's `dev/` tree
(other than this `dev/skills/liveloop/` folder itself) needs to be present**
in the target workspace for the skill to bootstrap, join, process, wait, and
exit. `dev/s1.5c-wake-integration/` (`wake_dispatcher.py`, the VS Code
Control Bridge integration, and their own copies of `cooperative_wait.py`/
`check_unattended.py`) is repo-development tooling for a *different*,
separate autonomous-wake mechanism (headless CREATE/RESUME sessions — see
master plan section 25) and was never meant to be a runtime dependency of
this skill; seq228 fixed the accidental coupling that had crept in.

## What the skill DOES provision itself (seq228)

- **Runtime discovery**: `scripts/mcp_client.py:resolve_runtime()` looks, in
  this bounded order, for how to launch the `ll-mcp` server: (1) an
  already-configured `ll-mcp` entry in this workspace's `.mcp.json`, (2) this
  workspace's own `.liveloop-setup.json` from a prior successful setup run,
  (3) the `LL_BIN`/`LL_DATA_DIR` environment variables, (4) explicit
  `--ll-bin`/`--ll-data-dir` arguments. It never scans the filesystem beyond
  these four named locations.
- **`.mcp.json` provisioning**: if a runtime is discoverable but `.mcp.json`
  doesn't yet have an `ll-mcp` entry, `setup_liveloop.py` writes one itself
  (merging into any existing file, preserving unrelated `mcpServers` entries,
  never duplicating `ll-mcp`) and reports `SETUP_RESTART_REQUIRED` — a
  legitimate human/harness gate, since a live session's config never takes
  effect without a reload, not something this skill works around.
- **Identity discovery/registration**: discover-before-create via `whois`;
  the agent registers itself via its own `register_participant` MCP tool
  call if genuinely absent (kept out of the script deliberately, per
  `communication/GOVERNANCE.md`'s "organization is yours" / "the server
  enforces nothing here" spirit — registration is the agent's own action,
  not a scripted side effect).

## Out of scope (explicitly, so a future "YES" is never assumed to cover this)

**Installing the LiveLoop runtime itself** (building/downloading `ll.exe`,
initializing its data directory from nothing) is installer/runtime-
provisioner scope, not skill scope. `SINGLE_SKILL_FRESH_AGENT_READY = YES`
means "given the runtime already installed and reachable somehow, this
skill's own folder is sufficient" — it does not mean the skill can conjure a
LiveLoop server where none exists. If that capability is wanted later, it is
a new, separate piece of scope (an installer), not an extension of the
skill's current discovery logic, and should be requested/tracked as such.

**Human-readable MCP output** remains deferred (25.10) — unaffected by this
consolidation, not reopened here.
