# Human-readable MCP output — design, DEFERRED (seq216 amendment, REQ-44)

## Finding

`live-loop/crates/liveloop-mcp/src/server.rs`'s shared `ok_json` helper already constructs
`CallToolResult::success(vec![ContentBlock::text(...)])` — the `Vec<ContentBlock>` is already
plural. Adding a second, human-readable `ContentBlock::text` alongside the existing raw-JSON
one is a small, additive, low-code-risk change to one shared function used by all ~25 tool
handlers — not an invasive redesign of the MCP API surface.

## Why deferred anyway

The code change is small; the **blast radius of shipping it right now is not**. It requires:
1. Rebuilding the release binary (`cargo build --release --bin ll`).
2. Restarting *every* currently-running `ll.exe` process to pick it up — which right now
   includes the dashboard/Gitea/tunnel-client just restarted this session (24.x precedent:
   these require careful, deliberate restart coordination, never a blind kill), **and** the
   *other, currently live* `coding-agent-phase1a` session's Control-Bridge-managed `ll.exe mcp`
   subprocess (section 25.2's identity-collision finding — that session is actively polling
   right now), **and** Govi's own interactive session's MCP connection.

Doing this mid-Stage2-prep, without explicit coordination with whoever/whatever is relying on
the current binary, is exactly the kind of disruption this whole engagement has treated with
deliberate caution (P0's audit explicitly named "frozen contracts/crates untouched" as a
tracked invariant). Per seq216's own explicit permission ("mark DEFERRED if invasive"), this
is deferred on **coordination/blast-radius** grounds, not code difficulty.

## Design, ready to implement when appropriate

```rust
fn ok_json_with_summary(value: serde_json::Value, summary: Option<String>) -> Result<CallToolResult, McpError> {
    let mut blocks = vec![ContentBlock::text(value.to_string())];
    if let Some(s) = summary {
        blocks.push(ContentBlock::text(s));
    }
    Ok(CallToolResult::success(blocks))
}
```

Applied first to the high-value, human-observed operations named in seq216:
`fetch_delta` (`"LiveLoop Delta\nParticipant: {p}\nLast seen: seq {n}\nNew messages: {k}\nStatus: {Up to date | k new}"`),
`query_communication` (seq/sender/subject/directive summary line per result), and
`LIVELOOP_STATUS`-shaped messages if a dedicated status-read tool is ever added. The
structured JSON block remains first and canonical — no agent-facing behavior changes; this
is purely an additive rendering aid for human-observed UIs that show tool content verbatim.
No secrets/internal-only fields are added to the summary text (same fields already in the
JSON, just reformatted).

**Not implemented this round.** Revisit once no other live session depends on the current
binary, or as part of a deliberately scheduled/coordinated release-refresh window.
