# S1.5D — Durable Liveness & Recovery Protocol (seq292, REQ-44)

**Status: DESIGN — AWAITING ARCHITECT REVIEW.** No production runtime/server/MCP change, no
new server entity, no reassignment automation implemented from this document. Baseline: the
seq283/286 AS-IS analysis (master plan section 25.23) and seq288's UX closure (25.24) — not
reopened here except where noted.

## A. Durable liveness / staleness

### A1. Vocabulary — reused, not invented

`STATUS_SCHEMA.md`'s existing `lifecycle_state` enum already covers the requested vocabulary
almost exactly, confirmed by direct comparison:

| Requested | Existing `lifecycle_state` value |
|---|---|
| ACTIVE/WAITING | `WAITING` |
| PROCESSING | `PROCESSING` |
| STALE/UNATTENDED | `AGENT_UNATTENDED` |
| RECOVERING | `JOINING` (re-entry after recovery) |
| EXITED/PAUSED | `EXITED` |

No new vocabulary is proposed. This alone satisfies most of item 1's "minimum signal using
existing primitives."

### A2. The one real gap: external observability

Today's `AGENT_UNATTENDED` classification (`check_unattended.py`) reads a **local heartbeat
file** only. It is accurate but invisible to anyone without filesystem access to that exact
machine/workspace — exactly what happened in this session's own real D1 event (25.23): the
architect only learned about it because a human happened to resume the session and this agent
self-reported afterward.

### A3. Minimum durable signal — extend `LIVELOOP_STATUS`, not a new entity

Add one optional field to the existing status JSON payload (`status_payload.py`,
`STATUS_SCHEMA.md`), the same additive pattern `exit_watermark_seq` already used in seq245
(backward compatible, no schema migration):

```json
{ "...(existing fields, unchanged)...": "...", "local_heartbeat_at": "2026-09-26T17:18:53Z" }
```

`local_heartbeat_at` = the timestamp of the agent's own last confirmed-live local moment
(practically: the same moment `cooperative_wait.py`'s local heartbeat file was last written,
duplicated into the *next* `LIVELOOP_STATUS` publish that already happens on every
`WAIT_ARMING` transition — including ordinary re-arm cycles). **Zero new message volume**:
this piggybacks on publishes that already occur (this very session published a `WAIT_ARMING`
status on every re-arm cycle throughout); it adds one field to an existing message, it does not
add new messages. This directly answers item 4's message-volume concern — the tradeoff is not
"more messages," it is "the messages we already send now carry one more honest fact."

### A4. Deterministic stale evaluation

- **Who computes it**: any participant, using only `query_communication` (already durable,
  already queryable by anyone — no new permission surface).
- **Authoritative evidence**: the most recent `LIVELOOP_STATUS` message's own
  `local_heartbeat_at` (or, absent that field on an older message, `last_transition_at` as a
  weaker fallback — already documented in `STATUS_SCHEMA.md` as "a weak signal").
- **TTL/clock assumptions**: TTL should be derived from `cooperative_wait.py`'s own already-
  qualified resilience constants (`MAX_CONSECUTIVE_POLL_ERRORS`, poll interval), not an
  arbitrarily new number — e.g. `TTL = poll_interval_seconds * (MAX_CONSECUTIVE_POLL_ERRORS + 2)`,
  giving genuine transient hiccups (already handled internally by the wait loop) room before an
  *external* observer would also conclude staleness. Cadence/TTL are explicitly **policy,
  passed as parameters**, never hard-coded architecture (item 4's explicit requirement).
- **Restart behavior**: `JOIN_LIVELOOP` recovery already publishes a fresh `JOINING` status
  (unchanged) — this naturally supersedes any prior stale-looking record for future observers,
  with no special-case logic needed.
- **False-positive handling**: see C's D1/D4 discussion — a generous, poll-interval-derived TTL
  plus the explicit next rule bounds the damage of a false positive to "an advisory label," not
  a consequence.
- **What STALE does NOT authorize** (item 6, load-bearing): a `STALE`/`AGENT_UNATTENDED`
  classification is **advisory only**. It never itself grants execution, reassignment, or any
  other authority — exactly like every other status field in this system (`STATUS_SCHEMA.md`
  already states this principle for the existing local-only check; this design does not weaken
  it, only extends who can compute the same advisory classification).

## B. Recovery / reassignment protocol

### B1. States (formalizing D4, reusing existing primitives only)

```
OPEN directive (no execution_reference yet)
  --external observer concludes STALE (A4)-->
RECOVERY_CANDIDATE (advisory only, grants nothing)
  --human/architect decision (never automatic, item 10)-->
  one of:
    (a) --original agent resumes normally--> executes, record_execution_reference
        against the ORIGINAL directive_id, lineage untouched, DONE
    (b) --architect issues a new directive to an authorized successor,
         supersedes_directive_id = original directive_id--> RECOVERY_ASSIGNED
      --successor acknowledge_message (ack_at set, same pattern as seq245 handoff)--> ACCEPTED
      --successor executes, record_execution_reference against the reassignment
         directive_id, replying with an explicit textual reference to the
         original directive_id for human-readable lineage--> DONE
```

### B2. Fencing — reuse `supersedes_directive_id`, not a new lock

`CONTRACT_V1.md`'s existing supersession mechanism (already load-bearing throughout this whole
engagement's own governance discipline — "supersession beats recency,"
`communication/GOVERNANCE.md`'s own ground rules) is exactly the right existing tool for
fencing, per item 9's explicit preference for reusing it over a new lock service:

- The reassignment directive is issued with `supersedes_directive_id = <original directive_id>`.
- `get_action_state(original_directive_id)` then resolves `superseded: true`, and
  `effective_directive` points at the reassignment.
- **The existing, already-qualified authority-check discipline is the fence**: any agent
  (original or successor) must call `get_action_state` before acting — already a standing rule
  (`communication/GOVERNANCE.md`: "never infer authority from prose... `get_action_state` is
  the only way to establish permission"). An original agent that wakes after reassignment and
  correctly follows this existing rule will see `superseded: true` and must stand down rather
  than also execute — split-brain prevented by an existing check, not new code.
- **Late-original-return handling**: the original agent may optionally send an informational
  note ("returned, see this was reassigned to X, standing down") — a courtesy, not required by
  the protocol.
- **Audit reconstruction** (item 17): `get_audit_chain` (already an existing tool,
  `communication/GOVERNANCE.md`'s own tool table) reconstructs the full
  message → directive → approval → acknowledgement → execution-reference → result chain across
  both the original and reassignment directives via the `supersedes_directive_id` link — no new
  capability needed.

### B3. Security/audit notes (item 17)

- **Forged heartbeat/status**: structurally prevented already — `sender_id` on every message
  (including `LIVELOOP_STATUS` publishes) is set server-side from the authenticated calling
  identity, never client-supplied; a participant cannot forge another's status.
- **Stale replay**: prevented by the existing most-recent-by-`seq` convention
  (`STATUS_SCHEMA.md`), unchanged.
- **Authority lineage**: the `supersedes_directive_id` chain, reconstructed via the existing
  `get_audit_chain`.
- **Successor acceptance**: `ack_at`, the same verified-not-assumed pattern seq245 already
  proved live (25.16).

## C. Failure experiment package (design/fixture plans only — none executed this round)

**D1 — idle process death while `WAITING`** (what genuinely happened this session, 25.23):
*Preconditions*: agent `JOINED`, publishing `WAIT_ARMING`/`WAITING` status with
`local_heartbeat_at` each cycle. *Injected failure*: kill the process. *Expected durable
record*: last `LIVELOOP_STATUS` message, `local_heartbeat_at` now older than TTL. *Expected
human projection*: an **external observer** (not the dead agent) runs the new remote-liveness
check, gets `STALE`, and — per seq288's now-wired taxonomy — renders
`attention_event.py --event HUMAN_RECOVERY_REQUIRED` themselves (never self-assigned by the
dead session, unchanged rule). *Success criterion*: the observer reaches this conclusion using
**only durable, remote-queryable data** — the actual new capability this design adds over
today's local-only `check_unattended.py`. *Cleanup*: existing, already-qualified
`JOIN_LIVELOOP` recovery path, unchanged.

**D2 — death during open work**: same durable evidence as D1, plus the `ActionDirective` stays
honestly `pending` (`get_action_state`) — nothing silently resolves it. *Success criterion*:
recovery (B1/B2) never results in **two** simultaneously-effective directives for the same
work — verified via `get_action_state` always resolving to exactly one `effective_directive`
regardless of how many agents check it, by construction of the supersession mechanism itself.

**D3 — offline queued work**: **regression only, no new mechanism**. Already fully proven,
repeatedly, this very session (every recovery this session found zero messages lost) —
inherited `PASS`, nothing to design.

**D4 — unrecoverable original, authorized successor takeover**: *Preconditions*: D1/D2 `STALE`
confirmed, human/architect decides to reassign. *Injected*: architect issues the B1(b)
reassignment directive. *Expected*: successor's `get_action_state` on the original shows
`superseded: true`; successor accepts (`ack_at`) and executes; **the split-brain case** — if
the original then also wakes and checks `get_action_state`, it too sees `superseded: true` and
must stand down (item 13's required split-brain case). **The false-positive/slow-agent case**
(item 13's other required case): the original was never actually dead, just slow (network lag,
a long task) — if it finishes and attempts to submit `RESULT`/`record_execution_reference`
*after* reassignment already happened, its own pre-submission `get_action_state` check (already
standing practice) shows `superseded: true`, and per the existing "never infer authority from
prose" discipline it must **not** submit — its real work is discarded. **Named honestly as an
accepted tradeoff of human-authorized reassignment**, not hidden: reassignment is a genuine
judgment call the architect/human makes with incomplete information, and this design does not
pretend to eliminate that risk, only to make its consequences deterministic and auditable
rather than silently ambiguous.

## D. Architecture / implementation boundary

### D1. The invariant, precisely (reusing seq283/286's own finding, not re-deriving it)

```
agent process/session (ephemeral)
  owns  ->  local relationship correlation (relationship_id -- LOCAL ONLY, regenerated on
            every resume, zero server meaning -- confirmed 25.23, unchanged by this design)
  operates as -> participant identity (durable ULID, survives process death)
       has -> work commitment (ActionDirective, durable, resolved via execution_reference
              or superseded -- survives process death, unaffected by which process/session
              or even which relationship_id observes/acts on it)
```

No layer of this is proposed to change. `local_heartbeat_at` (A3) is a durable **observation
about** the local process, published by whichever process/session happens to be alive at
publish time — it is not itself the process, and does not blur this boundary.

### D2. Reuse inventory (extends 25.23's classification with A/B's concrete design)

| Primitive | Classification | Evidence |
|---|---|---|
| Participant identity, cursor/delta, `ActionDirective`/`get_action_state`, execution refs, acknowledgements | `REUSE_AS_IS` | Confirmed 25.23, unchanged |
| Supersession (`supersedes_directive_id`) | `REUSE_AS_IS` **as the fencing mechanism** | Already load-bearing throughout this engagement; B2 above is its first explicit use for liveness-driven reassignment specifically |
| `get_audit_chain` | `REUSE_AS_IS` **as the audit-reconstruction mechanism** | Already listed in `communication/GOVERNANCE.md`'s tool table, unused for this purpose until now |
| `LIVELOOP_STATUS` payload schema | `EXTEND` | One optional field (`local_heartbeat_at`), same additive pattern as `exit_watermark_seq` (seq245) |
| Remote/durable staleness evaluation | `NEW` (small) | No existing script reads `LIVELOOP_STATUS` for this purpose today — `check_unattended.py` is local-file-only |
| D4 reassignment protocol | `NEW` (documentation only) | No code — a convention using 100% existing primitives (B1/B2) |

### D3. Recommended smallest S1.5D-P1 slice

1. `EXTEND`: add `local_heartbeat_at` to `status_payload.py`'s optional fields (same pattern as
   `exit_watermark_seq`), populated from the local heartbeat file's own timestamp when one
   exists.
2. `NEW`, small: `scripts/check_remote_liveness.py` — pure logic + one `query_communication`
   call, analogous to `check_unattended.py` but reading durable status instead of a local file,
   usable by any participant without filesystem access to the original agent's machine.
3. `NEW`, documentation only: the B1/B2 reassignment protocol added to
   `communication/GOVERNANCE.md` (or a dedicated section here) — no code.

**P2 (deferred, not proposed for this slice)**: attention-card wiring specifically for
"remote-observer-detected STALE" flows beyond what seq288 already provides; configurable
TTL/cadence policy surfaced as a first-class setting rather than a script parameter; any
tooling around the false-positive/slow-agent tradeoff beyond naming it honestly.

### D4. Explicit non-goals (restated per item 16, unchanged from 25.23's own recommendation)

No new server-side "Relationship" entity. No automatic/unauthorized reassignment — every
reassignment in B1(b) is a human/architect decision, never timeout-triggered automation. No
Claude-specific restart architecture. No new generic workflow engine. No MCP contract change.

## Unresolved risks/questions for architect review

1. **TTL default value**: A4 proposes deriving it from `cooperative_wait.py`'s existing
   constants rather than a fresh number — is that derivation formula acceptable, or should TTL
   be a fully independent, separately-configured policy value?
2. **`local_heartbeat_at` during non-`WAITING` states**: should `PROCESSING`/`CATCHING_UP`
   status publishes also carry a heartbeat timestamp, or is `WAITING`-only sufficient (since
   that's the state where "is anyone still there" is actually ambiguous — `PROCESSING` implies
   recent activity by definition)? This document assumes `WAITING`-only; flagging the
   alternative for review.
3. **Successor selection**: this design assumes a human/architect names the successor
   explicitly (B1(b)) — should there be any documented convention for how a successor is
   chosen (e.g., pre-registered backup participants), or is ad hoc human selection acceptable
   indefinitely?

## Recommended P1 acceptance gate

D1 and D4's false-positive/split-brain cases (C above) qualified against a disposable fixture
project (same pattern as every prior round — never `LiveLoopTry`), with real `query_communication`
calls proving an external observer reaches the correct `STALE`/`superseded` conclusion using
only durable data, before any of this is wired into `SKILL.md`'s actual operating procedure.
