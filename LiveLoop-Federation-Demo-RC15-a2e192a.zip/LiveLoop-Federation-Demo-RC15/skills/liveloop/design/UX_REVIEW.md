# LiveLoop conversation UX — self-review + design proposal (seq266, REQ-44)

**Status: PROPOSAL — AWAITING APPROVAL.** Nothing here is wired into production. The samples
in `ux_prototype.py` (this same directory) are standalone, imported read-only from
`scripts/attention_event.py`'s existing data model — no changes to `scripts/attention_event.py`,
`SKILL.md`, or any production path were made to produce them.

## 1. Self-observation (real evidence from this session's own joined relationship)

Reviewing every output surface this relationship actually produced (transcript + repo
evidence, no private host internals):

| Surface | Produced by | What appears in the transcript |
|---|---|---|
| MCP tool call/response | `fetch_delta`, `send_message`, `reply_message`, `acknowledge_message`, `get_action_state`, `record_execution_reference`, `update_cursor`, `get_message_recipients` | Full raw JSON — ids (ULIDs), timestamps, nested directive/approval objects, echoed message bodies |
| Status publication | `status_payload.py` (Bash) then `send_message` (MCP) | The **same JSON payload rendered twice**: once as the script's stdout, once as the tool call's `body_md` argument, then a **third time** in the tool's own response echoing the sent message back |
| Attention card | `attention_event.py` (Bash) | The card's Markdown block as the script's stdout — historically then **often re-pasted a second time** in this agent's own prose reply |
| Wait/re-arm | `cooperative_wait.py` (Bash, backgrounded) | `{"state": "TIMEOUT"/"EVENT_DETECTED", ...}` JSON, once per wait-slice |
| Prose | This agent's own reply text | Explanation, reasoning, RESULT summaries |

## 2. Classification

- **HUMAN_SIGNAL** — the attention card content itself (icon + heading + detail + Link/Work/State).
- **HUMAN_CONTEXT** — this agent's own prose: explanations, RESULT summaries, design rationale.
- **MACHINE_EVIDENCE** — raw MCP tool call inputs/outputs; script stdout shown as a distinct
  tool-call block; git/test command output; file reads.
- **AMBIENT_MECHANICS** — the plain-`TIMEOUT` re-arm cycle's own `update_cursor`/`status_payload.py`/
  `send_message`/`cooperative_wait.py` calls. No attention card is emitted for these (`attention_event.py`
  has no `--event` choice for them, by construction, unchanged) — but the surrounding MACHINE_EVIDENCE
  from those calls is still rendered by the host every cycle.
- **ATTENTION_REQUIRED** — the subset of HUMAN_SIGNAL with severity `ATTENTION_REQUIRED`
  (`APPROVAL_REQUIRED`/`EXIT_PENDING`/`AGENT_UNATTENDED`).

**Duplication found** (real, not hypothetical — observed directly in this session's own
transcript): status payloads render 3x per transition (script stdout, tool-call input, tool-call
response); attention cards had been rendering 2x (script stdout + this agent re-pasting the same
text in prose).

## 3. What we CAN and CANNOT improve

**CANNOT** (host-owned, stated honestly per instruction, not worked around):
- Suppress or hide raw MCP tool-call JSON rendering in the Claude Code transcript — that is the
  harness's own tool-result UI, outside any skill instruction's or Python script's control.
  Nothing in `SKILL.md` or `attention_event.py` can make that JSON not render.
- Apply real font/background color in the required Markdown path — Claude's chat Markdown
  rendering has no color syntax (no CSS, no HTML color spans confirmed safe/supported); "semantic
  color" is achievable only in the *optional* Rich terminal renderer via ANSI escapes, which
  already exists and already stays optional. Claiming Markdown-level color would be fabricating a
  capability that doesn't exist — not done here.
- Guarantee a light/white card background — that is the host's own theme, not something Markdown
  text can set. The proposal below is theme-neutral by construction (relies only on standard
  Markdown emphasis/blockquote/inline-code, which every renderer already maps sensibly to both
  light and dark themes).
- Reduce the required tool evidence itself — `fetch_delta`/`get_action_state`/`acknowledge_message`
  etc. must keep running and keep returning what they return; this is real evidence the governance
  model depends on, not decoration to be trimmed.

**CAN** (all achievable without touching MCP truth/evidence — pure presentation-layer, at the
agent's own instruction/behavior level, not the server's):
1. **Stop re-pasting the card.** The single biggest, cheapest win: once `attention_event.py`'s
   block is printed via its own tool call, the agent's own prose should not retype the same block
   a second time — introduce it with one short lead sentence instead ("Here's the current
   status:" + the block already shown), never duplicate the content itself.
2. **Consistent placement.** Run the attention-event call as the first action-visible step for a
   high-signal turn, so its block is the first thing associated with that turn rather than buried
   after several MCP calls.
3. **Per-event-type icons** (a new axis alongside the existing severity/blockquote styling) —
   proposed below — so a human scanning a long transcript can distinguish "a task arrived" from
   "a result landed" from "something needs my attention" by shape alone, not just by reading text.
4. **Accept, don't fight, the machine evidence.** Rather than pretending it can be hidden, design
   the card to be visually distinct *against* that background — bold heading, a leading icon,
   blockquote-and-icon escalation for `ATTENTION_REQUIRED` — so it reads clearly even interleaved
   with raw JSON.

## 4. Proposed design system

**Icons per event type** (new — layered on top of the existing severity mapping, which is
unchanged: `INFORMATIONAL` vs `ATTENTION_REQUIRED` still controls blockquote-wrapping):

| Event | Icon | Rationale |
|---|---|---|
| `JOINED` | ◉ | activity/connection established |
| `WORK_RECEIVED` | ◉ | activity received |
| `RESULT` | ✓ | success/completion |
| `APPROVAL_REQUIRED` | ⚠ | attention |
| `HANDOFF_REQUESTED` | ⇄ | transfer in progress |
| `HANDOFF_ACCEPTED` | ⇄ | transfer in progress (label text distinguishes requested vs accepted) |
| `EXIT_ACCEPTED` | ◉ | departure begun, still informational |
| `EXIT_PENDING` | ⚠ | attention |
| `EXITED` | ✓ | success/completion |
| `AGENT_UNATTENDED` | ⚠ | attention (kept aligned with the existing severity icon rather than adding a fourth glyph, to avoid over-fragmenting a small icon set) |

All plain Unicode glyphs already used successfully in production (seq262) — no new font/emoji
dependency, no variation selectors that render inconsistently across hosts.

**Layout**: unchanged from the seq262 production layout (heading stands alone, italic detail,
Link/Work/State footer) — this proposal is additive (per-event icons, the no-re-paste
convention) not a layout redesign, since the layout itself was already human-approved live.

## 5. Rendering architecture

Unchanged separation: `AttentionEvent`/`LiveContext` (plain data) → `render_markdown()`
(required, portable) / `render_rich()` (optional terminal prototype, ANSI-capable, still
falls back automatically). The per-event icon map is a new lookup table
(`EVENT_TYPE_ICONS` in the prototype) consulted *in addition to* the existing severity-based
`HEADER_ICONS`/blockquote logic — a pure additive layer, not a replacement.

## 6. Event-to-card mapping — the 8 requested representative samples

See `ux_prototype.py` for the actual rendered text (run it directly:
`python ux_prototype.py`) and the raw-JSON-coexistence sample (item 7 below). Samples cover:
`JOINED`/`WAITING`, `WORK_RECEIVED`/`PROCESSING`, `RESULT`/`SUCCESS`, `APPROVAL_REQUIRED`,
`HANDOFF_REQUESTED`, `EXIT_PENDING`, `EXITED`, `AGENT_UNATTENDED`/`RECOVERY`.

## 7. Raw MCP JSON + human projection coexistence

Since raw tool-result JSON cannot be hidden (section 3), the proposal is **sequencing +
introduction**, not suppression: the attention card renders first (or immediately adjacent to)
the MCP call it summarizes, with one short lead sentence, so a scanning human has an anchor
before the JSON — not a claim that the JSON disappears. See `ux_prototype.py`'s
`coexistence_sample()` for a literal example of this pairing.

## 8. Exact production changes recommended (pending approval)

1. Add `EVENT_TYPE_ICONS` to `scripts/attention_event.py`, consulted in `render_markdown()`/
   `render_rich()` in place of the current severity-only `HEADER_ICONS` lookup (severity still
   controls blockquote-wrapping; the icon now also varies by event type within a severity tier).
2. Add one line to `SKILL.md`'s "Human attention projection" section: after printing an
   attention-event block via the tool call, do not re-paste the same block's text in this
   agent's own prose — introduce it with a short lead sentence instead.
3. No change to `LiveContext`, the severity taxonomy, the Rich renderer's optionality, or any
   MCP-facing behavior.

These are small, additive, and match this experiment's own finding: the highest-value fix is
behavioral (stop self-duplicating) more than visual (new icons are a smaller, secondary win).

## 9. Self-critique from rendering the 8 samples (one iteration, per instruction)

Reviewed all 8 rendered samples directly (see `ux_prototype.py`'s output). One open question,
flagged rather than silently changed: `AGENT_UNATTENDED`'s `Link` row shows only
`` `WAITING` · coding-agent-phase1a `` — no counterpart, because an unattended agent genuinely
has none relevant to that event. It reads slightly oddly (a "Link" line naming only yourself),
but it's honest rather than fabricated (never inventing a counterpart to fill the row). Options
for a future round: omit the self-only suffix when there's no counterpart at all, or accept it
as correctly representing "no external party is involved in this event." Left as an open
question for approval rather than a unilateral change, since it's a real design choice, not an
obvious bug.
