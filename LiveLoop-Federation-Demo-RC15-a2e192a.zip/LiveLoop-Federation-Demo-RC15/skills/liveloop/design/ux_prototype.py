"""LiveLoop conversation UX -- design prototype ONLY (seq266, REQ-44).

NOT production code. Imports the existing, unmodified AttentionEvent/LiveContext/
render_markdown from ../scripts/attention_event.py read-only, and layers one new,
purely additive idea on top (a per-event-type icon map) without touching that
module. See UX_REVIEW.md in this same directory for the full design note this
prototype supports.

Run directly to render all 8 representative samples + the raw-JSON-coexistence
example:
    python ux_prototype.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
import attention_event as prod  # noqa: E402 -- the real, unmodified production module

# Proposed new axis (section 4 of UX_REVIEW.md): one icon per EVENT TYPE, layered
# on top of (not replacing) the existing severity-based blockquote/header-icon
# logic in production. This dict lives only here -- production's HEADER_ICONS
# stays severity-keyed and unmodified unless/until this proposal is approved.
EVENT_TYPE_ICONS = {
    "JOINED": "◉",
    "WORK_RECEIVED": "◉",
    "RESULT": "✓",
    "APPROVAL_REQUIRED": "⚠",
    "HANDOFF_REQUESTED": "⇄",
    "HANDOFF_ACCEPTED": "⇄",
    "EXIT_ACCEPTED": "◉",
    "EXIT_PENDING": "⚠",
    "EXITED": "✓",
    "AGENT_UNATTENDED": "⚠",
}


def render_prototype(evt, context=None):
    """Exactly prod.render_markdown()'s logic, with one line changed: the
    header icon comes from EVENT_TYPE_ICONS (per event type) instead of
    prod.HEADER_ICONS (per severity tier only). Everything else -- layout,
    truncation, alias stripping, blockquote wrapping by severity -- is
    reused unmodified from production, not reimplemented, so this prototype
    can never silently drift from what's actually shipped."""
    icon = EVENT_TYPE_ICONS[evt.event]
    lines = [f"**{icon} LiveLoop · {evt.label.upper()}**"]
    if evt.detail:
        lines.append(f"*{prod._truncate(evt.detail, 100)}*")

    have_context = bool(context) and not context.is_empty()
    if have_context:
        self_alias = prod._display_alias(evt.participant)
        rows = context.rows(self_alias=self_alias, code=lambda s: f"`{s}`")
        if rows:
            lines.append("---")
            for label, value in rows:
                lines.append(f"**{label}** {value}")
    else:
        identity_parts = [evt.participant, evt.project]
        if evt.seq is not None:
            identity_parts.append(f"seq{evt.seq}")
        lines.append(" · ".join(identity_parts))

    if evt.severity == prod.ATTENTION_REQUIRED:
        return "\n".join(f"> {l}" for l in lines)
    return "\n".join(lines)


def eight_representative_samples():
    """The exact 8 event/state pairs seq266 asked for."""
    samples = []

    evt = prod.AttentionEvent(event="JOINED", participant="coding-agent-phase1a", project="liveloop")
    ctx = prod.LiveContext(link="JOINED", counterpart="liveloop-architect-01", state="WAITING", cursor_seq=1)
    samples.append(("JOINED / WAITING", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="WORK_RECEIVED", participant="coding-agent-phase1a", project="liveloop",
                               detail="Self-review UX experiment")
    ctx = prod.LiveContext(link="JOINED", counterpart="liveloop-architect-01", top_object_type="TASK",
                            top_object_ref="seq266", commitment_state="OPEN", state="PROCESSING", cursor_seq=266)
    samples.append(("WORK_RECEIVED / PROCESSING", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="RESULT", participant="coding-agent-phase1a", project="liveloop",
                               detail="UX proposal delivered, awaiting approval")
    ctx = prod.LiveContext(link="JOINED", counterpart="liveloop-architect-01", top_object_type="RESULT",
                            top_object_ref="seq266", commitment_state="NONE", state="PROCESSING", cursor_seq=267)
    samples.append(("RESULT / SUCCESS", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="APPROVAL_REQUIRED", participant="coding-agent-phase1a", project="liveloop",
                               detail="Directive requires approval before acting")
    ctx = prod.LiveContext(link="JOINED", counterpart="liveloop-architect-01", top_object_type="APPROVAL",
                            top_object_ref="seq268", commitment_state="OPEN", state="PROCESSING", cursor_seq=268)
    samples.append(("APPROVAL_REQUIRED", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="HANDOFF_REQUESTED", participant="coding-agent-phase1a", project="liveloop",
                               detail="Requesting seq245-successor take over Task A")
    ctx = prod.LiveContext(link="EXIT_PENDING", counterpart="seq245-successor", top_object_type="HANDOFF",
                            top_object_ref="Task A", commitment_state="OPEN", state="PROCESSING", cursor_seq=8)
    samples.append(("HANDOFF_REQUESTED", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="EXIT_PENDING", participant="coding-agent-phase1a", project="liveloop",
                               detail="Awaiting successor acceptance")
    ctx = prod.LiveContext(link="EXIT_PENDING", counterpart="seq245-successor", top_object_type="HANDOFF",
                            top_object_ref="Task A", commitment_state="OPEN", state="PROCESSING", cursor_seq=8)
    samples.append(("EXIT_PENDING", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="EXITED", participant="coding-agent-phase1a", project="liveloop",
                               detail="Departure complete, handoff verified")
    ctx = prod.LiveContext(link="EXITED", counterpart="seq245-successor", top_object_type="EXIT",
                            top_object_ref="Task A", commitment_state="NONE", state="EXITED", cursor_seq=11)
    samples.append(("EXITED", render_prototype(evt, ctx)))

    evt = prod.AttentionEvent(event="AGENT_UNATTENDED", participant="coding-agent-phase1a", project="liveloop",
                               detail="Heartbeat stale 90s -- operator must resume the session")
    ctx = prod.LiveContext(link="WAITING", state="WAITING", cursor_seq=252, waiter_cycle=3)
    samples.append(("AGENT_UNATTENDED / RECOVERY", render_prototype(evt, ctx)))

    return samples


def coexistence_sample():
    """Section 7 of UX_REVIEW.md: a literal example of how the human
    projection and unsuppressible raw MCP JSON sit next to each other --
    NOT a claim that the JSON goes away, a demonstration of the proposed
    sequencing convention (card first, one lead sentence, then the call)."""
    evt = prod.AttentionEvent(event="RESULT", participant="coding-agent-phase1a", project="liveloop",
                               detail="Cursor advanced past seq267")
    card = render_prototype(evt)
    raw_json_example = (
        '{"last_seen_seq": 267, "participant_id": "01M2X8HAAFXYPYVHVK4V7N8MMD", '
        '"updated_at": "2026-09-26T11:05:17.020395300Z"}'
    )
    return (
        "Proposed sequencing (this agent's own reply text, not a new tool):\n\n"
        f"{card}\n\n"
        "*(the `update_cursor` call this summarizes returns, unsuppressed, exactly as it "
        f"always has:)*\n```json\n{raw_json_example}\n```"
    )


if __name__ == "__main__":
    for title, block in eight_representative_samples():
        print(f"=== {title} ===")
        print(block)
        print()
    print("=== Raw-JSON coexistence sample ===")
    print(coexistence_sample())
