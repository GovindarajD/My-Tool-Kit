---
name: organizing
description: Shared workspace/project organization discipline for both the Architect and Coder roles -- where new material belongs (canonical/working/historical/promoted), session rhythm (Orient-Reconcile-Organize-Recommend-Commit-Execute-Close), project-home status-document hygiene, and lightweight configuration management. Use when deciding where to file something, how to pace a session, or how to keep a status/roadmap document current without inventing new process.
---

# organizing

**v1 (seq676, Wave 5/F046)** — Shared Organizing Skill. Distilled from lived practice, not
designed speculatively: every rule below is a restatement of a principle or pattern already
demonstrated in `plan/WAYS_OF_WORKING.md` (the architect-owned living operational contract for
this engagement) and in the actual document set it produced (`plan/CURRENT_STATUS.md`,
`plan/LIVELOOP_MASTER_FEATURE_REGISTER.md`, `plan/LIVELOOP_IMPLEMENTATION_ROADMAP.md`,
`plan/LIVELOOP_DOCUMENT_INDEX.md`). This is v1: expected to be refined by later dogfood usage
(ATP and others), not a draft — see **Versioning** below.

**Who uses this**: both the Architect and the Coder role. Organization is a shared discipline,
not something only one side owns — a Coder who dumps evidence in the wrong place or an
Architect who lets two canonical docs drift apart both create the same kind of cost. This skill
has no role-gated sections; [[architect]] and [[coder]] each layer their own role-specific
discipline on top of this shared one.

## Owns

- Workspace/project organization: where new material belongs (canonical, working, historical,
  promoted — see **The four places things live** below).
- Project-home/status hygiene: keeping one thin, current "where things stand" document instead
  of scattering status across session transcripts or ad hoc handoff files.
- Evidence placement: a claim's supporting artifact (file, test result, message seq) has one
  findable location, named at the point the claim is made.
- Lightweight configuration management: current-vs-superseded tracking, provenance/change
  attribution, recoverability — using mechanism the project already has, not new tooling.

## Does not own

- **Architecture decisions, qualification/judgment, directive authority** — that is
  [[architect]]'s. This skill says *where a decision gets recorded*, never *what the decision
  should be*.
- **Implementation, testing, execution evidence construction** — that is [[coder]]'s. This
  skill says *where evidence belongs once produced*, never *how to produce it*.
- **Transport/coordination mechanics** (messaging, directives, approvals, presence, wait/wake
  lifecycle) — that is the `liveloop` skill's. This skill assumes LiveLoop (or an equivalent
  comms layer) already exists and governs organization *within* whatever workspace that comms
  layer operates over.
- **Program management as a role** — deliberately not a fourth skill. Program-management-shaped
  work (status rollups, planning documents) is document/process output that the Architect role
  produces using this skill's conventions, not a separate skill or persona.

## Session rhythm

**Orient → Reconcile → Organize → Recommend → Commit → Execute → Close/Carry-forward.**
(`WAYS_OF_WORKING.md` principle: "Session rhythm", demonstrated every wave of this engagement's
v1.2 program.)

1. **Orient** — re-establish current state before acting: read the project-home status
   document, check any pending directive's action state, catch up on anything missed. Session
   start is a self-organization checkpoint, not immediate execution.
2. **Reconcile** — compare the new ask against the canonical register/roadmap/existing docs:
   does it fit, extend, conflict, or duplicate something that already exists?
3. **Organize** — decide where new material belongs (see **The four places things live**)
   *before* writing it, not after.
4. **Recommend** — where the brief itself has gaps or risks, say so before implementing
   literally (this step is [[architect]]'s "constructive challenge" principle in miniature,
   available to either role).
5. **Commit** — get explicit authorization before mutating anything beyond discovery/design.
6. **Execute** — do the authorized work, citing evidence as it's produced.
7. **Close/Carry-forward** — classify whatever remains open as one of: **carried-forward**
   (continues next session), **blocked** (needs something external), **waiting** (needs a
   decision from a named party), **superseded** (no longer relevant), or **intentionally
   dropped** (decided against) — recorded in the status document's own Blocked/Waiting or
   Insights section, never left ambiguous.

## The four places things live

| Place | What goes there | Who decides it graduates here |
|---|---|---|
| **Canonical** (e.g. `plan/`) | Current working truth — the register, the roadmap, the ways-of-working document, the status document | Architect owns; Coder maintains with traceability |
| **Working** (e.g. `dev/duo-work/`) | In-progress design inputs, evidence-in-flight, not yet promoted | Coder owns directly |
| **Historical** (e.g. `dev/`'s existing files) | Frozen record — never deleted, never cosmetically reorganized | Shared; indexed, not edited |
| **Promoted/shared** (e.g. `community/`) | Material deliberately published for reuse beyond this project | Architect decides what graduates; Coder builds/maintains the promoted copy with provenance back to its working source |

A document's current-vs-superseded state is stated inline in its own header — never a second,
separate status field. Cross-document supersession is tracked only in the document index, not
duplicated elsewhere.

## Status-tracking pattern

One thin, current "project home" document (not a growing log) with four fixed sections:
**Current** (what's true right now, with its evidence), **Next** (pointer to the authoritative
plan, not a restated copy of it), **Blocked/Waiting** (each item named with who/what it's
waiting on), **Insights & Recommendations** (append-only — observations get added, not
overwritten, so a later reader can see when something was first noticed even after it's been
acted on). This mirrors `plan/CURRENT_STATUS.md`'s actual structure, not a new invention.

## Lightweight configuration management

- **Current vs. superseded**: stated inline in each canonical doc's own header.
- **Baseline points**: tags/markers at real decision points — reuse what the project already
  has (e.g. git tags), never invent a second versioning mechanism.
- **Provenance**: every canonical doc cites the directive/request that authorized its creation
  or last material change.
- **Recoverability — the one rule that actually matters**: never delete history merely for
  tidiness; always supersede with a pointer.
- Prefer existing mechanics (git/version control, the comms layer's own directive/approval
  model) over inventing a new approval-form, change-request, or ticket system.

## Minimum ceremony, appropriate rigor

Match process weight to actual risk: a one-page status file for routine tracking, a full
discovery-plus-evidence-plus-test cycle for a change that crosses a production/security/
protocol/persistence/autonomous-action/external-integration boundary. Do not build process for
its own sake, and do not reorganize historical material cosmetically just because a tidier
structure is conceivable — reorganization is itself a cost, and this skill's job is to avoid
unnecessary costs, not to add one in the name of neatness.

## Composition with the other two role skills

This skill is deliberately boundary-thin: it says *where things go and how session work is
paced*, and hands off immediately to [[architect]] or [[coder]] for anything about *what the
right decision or implementation is*. A session normally layers all three: this skill's rhythm
frames the session, [[architect]] or [[coder]]'s own discipline governs the substantive work
inside each step, and the `liveloop` skill (or an equivalent transport) carries the actual
messages between roles. See `dev/skills/SKILLS_COMPOSITION.md` for a worked scenario showing
all three skills (plus `liveloop` and `duo-architect-coder-skill`) operating in the same session
without contradictory ownership claims.

## Versioning

**v1.** Authored from `WAYS_OF_WORKING.md` and the actual canonical-document set this
engagement produced, as of 2026-10-04 (v1.2 release program, Wave 5). Expected to be refined by
later usage — including ATP's dogfooding of this release — without needing to be re-justified
as a skill from scratch each time; a refinement is a new version of this file, not a reason to
call v1 a draft.
