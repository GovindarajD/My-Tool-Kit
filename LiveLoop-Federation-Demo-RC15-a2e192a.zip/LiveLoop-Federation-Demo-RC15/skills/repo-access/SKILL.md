---
name: repo-access
description: Governed, fail-closed Gitea repository access via LiveLoop's F036 Repo-Access Service -- configure_repo_access, get_repo_access_status, repo_read_file, repo_commit_file. Use when configuring repo access for a project, reading or committing a file through the governed broker, or interpreting a repo-access error (Disabled/NotConfigured/Unreachable/AuthDenied/NotFound/BackendError). Composable with liveloop/organizing/architect/coder -- not role-exclusive, since F036's admin-gating is already role-neutral.
---

# repo-access

**v1 (seq730, Wave/v1.3-WP4)** — a thin, composable skill for LiveLoop's governed Repo-Access
Service (F036). Distilled from the real design/implementation evidence across Waves 2/6/9 of
the v1.2 program, not invented speculatively — see `plan/LIVELOOP_MASTER_FEATURE_REGISTER.md`'s
F036 row and `live-loop/crates/liveloop-mcp/src/repo_access.rs`'s own module doc for the
authoritative source.

**Who uses this**: anyone — Architect or Coder — who needs to configure, check, or use governed
repo access for a project. This is deliberately **not** filed inside `coder` or `architect`:
F036's admin-gating is already role-neutral (any admin-token holder may configure it; any
participant may be named in a `repo_read_file`/`repo_commit_file` call), so a role-exclusive
skill location would wrongly imply a restriction the actual authority model doesn't have. See
`dev/skills/SKILLS_COMPOSITION.md` for the full reasoning this reversed an earlier, narrower
recommendation on.

## What F036 is, in one paragraph

A governed broker between a LiveLoop project and a Gitea backend. The broker holds the real
Gitea API token; no agent identity ever receives one. Every operation (`read`, `commit`) is
performed by the broker itself, which returns only the result — never a reusable credential.
Three modes: `disabled` (default), `existing_local` (a loopback Gitea instance), `external` (a
non-loopback, https-only instance). A fourth mode (bundled/LiveLoop-managed Gitea) is not
representable this release — deliberately, per `plan/INSTALLER_UXD_AND_DIAGNOSTICS_
DESIGN.md` §M.5's assessment of the real ongoing lifecycle-ownership cost that would carry.

## The four tools

| Tool | Gating | Purpose |
|---|---|---|
| `configure_repo_access` | **Admin-token gated** — operator-level, not a normal agent action | Set a project's mode/base_url/owner/repo/token |
| `get_repo_access_status` | Open to any participant | Returns `{mode, reachable, project_id, ...}` — never the credential |
| `repo_read_file` | Open to any participant | Reads a file via the governed broker; returns content + a content-addressed `sha` |
| `repo_commit_file` | Open to any participant | Commits a file via the governed broker; returns the resulting commit sha |

**Configuring** (admin-token required — the same bootstrap token as `register_participant`):
```json
{"tool": "configure_repo_access", "arguments": {
  "admin_token": "<admin token>", "project_key": "myproject",
  "mode": "existing_local", "base_url": "http://127.0.0.1:3000",
  "owner": "myorg", "repo": "myrepo", "token": "<a real Gitea API token>"
}}
```
`mode: "disabled"`/`"external"` work the same shape; `existing_local` requires a loopback
`base_url` (http or https), `external` requires a non-loopback https `base_url` — enforced
server-side, not just documented here.

**Checking status** (no admin token needed):
```json
{"tool": "get_repo_access_status", "arguments": {"project_key": "myproject"}}
```

**Reading a file**:
```json
{"tool": "repo_read_file", "arguments": {
  "project_key": "myproject", "participant": "<your participant name>",
  "path": "README.md"
}}
```
Optional `ref_` for a specific branch/commit; omitted means the backend's default branch.

**Committing a file**:
```json
{"tool": "repo_commit_file", "arguments": {
  "project_key": "myproject", "participant": "<your participant name>",
  "path": "notes.md", "content_base64": "<base64-encoded content>",
  "message": "a real commit message"
}}
```

## Error taxonomy — what each one means, and what to do

| Error | Meaning | What to do |
|---|---|---|
| `Disabled` | Repo access is off for this project | An admin must `configure_repo_access` with a non-`disabled` mode first — never treat this as "try anyway" |
| `NotConfigured` | No config exists at all | Same as above — **this is not a default-allow state**; absence of config means denied, not permitted |
| `Unreachable` | The backend didn't respond (network/connection error) | Fails closed, never silently retried as if transient — check the backend is actually running at the configured `base_url` |
| `AuthDenied` | The backend rejected the credential (HTTP 401/403) | The configured token is invalid/revoked — an admin must reconfigure with a valid one |
| `NotFound` | The requested path doesn't exist (HTTP 404) | A genuine "no such file" — normal for a first `repo_commit_file` on a new path (the broker probes first, creates if absent) |
| `BackendError` | Any other non-2xx response | Check the backend's own logs; this is a real backend-side problem, not a LiveLoop-side one |

**Never** retry any of these as if they might resolve themselves without an explicit, separate
fix — that is the fail-closed discipline this whole service is built on.

## Recovery

A backend that was genuinely down and comes back up resumes working **with the same
configuration, no reconfiguration needed** — confirmed by direct testing
(`a_backend_that_recovers_resumes_working_without_reconfiguration`, Wave 6). Only `AuthDenied`
requires an actual admin action (reconfigure with a valid token) to recover from.

## Known limitation — state plainly, don't soften

F036's client-side logic is qualified against a real local HTTP server matching Gitea's
documented API shape (`wiremock`, Wave 2) — **a real Gitea instance has not been independently
qualified against this release** (Wave 9 Gate C found a real local Gitea but had no documented
credentials to test against, and correctly did not attempt to obtain them). Treat real-Gitea
reliance as **operator-validated, not vendor-guaranteed**, before depending on it for anything
consequential.

## Composition with the other skills

This skill adds no new authority model and duplicates no other skill's content — it is purely
operational knowledge about one governed tool family. It composes with `liveloop` (transport),
`organizing` (where configuration decisions get recorded), `architect` (deciding whether/how
repo access should be configured for a project), and `coder` (actually calling
`repo_read_file`/`repo_commit_file` during implementation work) — see `dev/skills/
SKILLS_COMPOSITION.md` for the full 5-skill ownership matrix.

## Versioning

**v1.** Authored from the F036 design/implementation evidence across v1.2 Waves 2/6/9, as of
2026-10-05 (v1.3 WP4). Expected to be refined by later usage without needing to be
re-justified from scratch.
