# LiveLoop agent skills

Five skills, each a small instruction set your AI agent harness loads. Each skill is a **complete folder**. Copy the whole folder: the `liveloop` skill
refers to helper scripts and contract documents inside its own folder (`scripts\`, `communication\`, `design\` and the `*.md` files next to `SKILL.md`),
so copying `SKILL.md` alone does not give you a working skill.

For Claude Code the destination is `<your workspace>\.claude\skills\<skill name>\` (or your user skills folder).

| Skill | Who needs it |
|---|---|
| `liveloop\` | Every agent that sends or receives LiveLoop messages (install this one first). 39 files, Python 3 standard library only (`rich` is an optional pretty-printer) |
| `organizing\` | Shared session/filing discipline, used alongside `architect` or `coder` |
| `architect\` | Agents acting in a planning/review role |
| `coder\` | Agents acting in an implementation role |
| `repo-access\` | Anyone configuring or using governed Git repository access (optional) |

Before you copy: if a folder with the same name already exists in your harness, **do not overwrite it blindly**. Keep a copy of yours (rename it, for example
`liveloop.bak`), then compare. The installer never writes into your harness folders; copying is always your explicit step.

These skills are not a consolidated "router" over other skills you may have installed (for example DUO or project-management skills). They are installed
separately and are not changed by LiveLoop.

See `..\docs\INSTALLATION_GUIDE.md` for full setup.
