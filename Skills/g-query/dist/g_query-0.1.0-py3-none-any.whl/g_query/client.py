"""GQueryClient: the public entry point for querying Google Search AI Mode."""

from __future__ import annotations

import os
import random
import re
import sys
import time
import urllib.parse
import uuid
from dataclasses import dataclass, field
from typing import Optional

from markdownify import markdownify
from playwright.sync_api import (
    BrowserContext,
    Error as PlaywrightError,
    Page,
    TimeoutError as PlaywrightTimeoutError,
)
from playwright.sync_api import sync_playwright

from ._browser import launch_context
from .exceptions import (
    AIModeUnavailableError,
    CaptchaDetectedError,
    GQueryError,
    GQueryTimeoutError,
    SignInRequiredError,
)
from .models import GQueryResult, Source
from .selectors import Selectors

GOOGLE_SEARCH_URL = "https://www.google.com/search"

# The `udm=50` query param is what currently routes a Google Search query to
# "AI Mode" instead of classic web results. Google has changed this value before
# (AI Overview vs AI Mode vs experimental UDM ids) and may again — override via
# GQueryClient(udm=...) if a future rollout changes it for your account/region.
AI_MODE_UDM = "50"

# Google has kept these top-level result-column ids stable across years of
# Search UI redesigns (unlike the inner div classes, which are obfuscated and
# change often), so they anchor the heuristic fallback below.
_HEURISTIC_ROOT_SELECTORS = ["#rcnt", "#center_col", "#search", "#main"]
_HEURISTIC_MIN_CHARS = 150

_HEURISTIC_JS = """
([rootSelectors, minChars]) => {
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 &&
      style.visibility !== 'hidden' && style.display !== 'none';
  }

  let root = null;
  for (const sel of rootSelectors) {
    const el = document.querySelector(sel);
    if (el) { root = el; break; }
  }
  if (!root) root = document.body;

  const candidates = Array.from(root.querySelectorAll('div, section, p'))
    .filter(isVisible)
    .map((el) => ({ el, text: (el.innerText || '').trim() }))
    .filter((c) => c.text.length > minChars);

  if (candidates.length === 0) return null;

  // Smallest block over the threshold: a proxy for "the specific answer
  // container" rather than a giant wrapper around the whole results column.
  candidates.sort((a, b) => a.text.length - b.text.length);
  const rootTextLen = (root.innerText || '').length;
  const best = candidates.find((c) => c.text.length < rootTextLen * 0.9) || candidates[0];

  return { html: best.el.outerHTML, text: best.text };
}
"""


@dataclass
class _ContainerMatch:
    text: str
    html: str
    method: str


@dataclass
class _Session:
    page: Page
    last_answer_text: str = ""
    last_activity: float = field(default_factory=time.monotonic)


class GQueryClient:
    """Drives a real (persistent-profile) Chromium browser against Google Search
    AI Mode and returns structured, JSON-serializable results.

    Example:
        with GQueryClient(headless=False) as client:
            result = client.query("latest changes in python 2026")
            print(result.to_json())

    Note: headless=True is best-effort only. Google can fingerprint headless
    Chromium as automated traffic and quietly serve regular web results
    instead of AI Mode, even with a fully signed-in persistent profile — this
    surfaces as a GQueryTimeoutError/AIModeUnavailableError after every
    selector fallback is exhausted, not as a clear error. headless=False does
    not have this problem.

    First-time setup: run once with ``headless=False`` and log into your Google
    account by hand in the window that opens. The persistent profile directory
    (default ``~/.g-query/profile``) retains that session for future headless runs.
    """

    def __init__(
        self,
        *,
        headless: bool = False,
        profile_dir: Optional[os.PathLike] = None,
        timeout: float = 20.0,
        locale: str = "en-US",
        udm: str = AI_MODE_UDM,
        selectors: Optional[Selectors] = None,
        min_request_interval: float = 2.0,
        interactive_wait_seconds: float = 180.0,
        hide_window: bool = False,
    ) -> None:
        self.headless = headless
        self.profile_dir = profile_dir
        self.timeout_ms = timeout * 1000
        self.locale = locale
        self.udm = udm
        self.selectors = selectors or Selectors()
        self.min_request_interval = min_request_interval
        # Pushes the window off-screen instead of using headless=True. Google's
        # bot detection keys off headless mode itself, not window position, so
        # this stays a genuine "headed" browser as far as Chromium/Google are
        # concerned while not visibly popping up. No effect when headless=True.
        # Leave False for the one-time sign-in flow, where you need to see and
        # interact with the window.
        self.hide_window = hide_window
        # In headed mode, how long to wait for a human to clear a sign-in wall
        # or CAPTCHA before giving up. Ignored in headless mode, where there's
        # no one to interact with the page, so the error is raised immediately.
        self.interactive_wait_seconds = interactive_wait_seconds

        self._playwright = None
        self._context: Optional[BrowserContext] = None
        self._last_request_at: float = 0.0
        # Open conversation sessions, keyed by session_id. Each holds the one
        # Page that a multi-turn conversation lives on — follow-up questions
        # are typed into Google's own chat input on that same page instead of
        # opening a fresh, unrelated search.
        self._sessions: dict[str, _Session] = {}

    # -- lifecycle -----------------------------------------------------------

    def start(self) -> "GQueryClient":
        if self._context is not None:
            return self
        self._playwright = sync_playwright().start()
        self._context = launch_context(
            self._playwright,
            profile_dir=self.profile_dir,
            headless=self.headless,
            locale=self.locale,
            hide_window=self.hide_window,
        )
        return self

    def close(self) -> None:
        self._sessions.clear()
        if self._context is not None:
            self._context.close()
            self._context = None
        if self._playwright is not None:
            self._playwright.stop()
            self._playwright = None

    def close_session(self, session_id: str) -> None:
        """End a conversation session and close its page. Safe to call with
        an unknown/already-closed session_id (no-op)."""
        session = self._sessions.pop(session_id, None)
        if session is not None and not session.page.is_closed():
            session.page.close()

    def has_session(self, session_id: str) -> bool:
        return session_id in self._sessions

    def __enter__(self) -> "GQueryClient":
        return self.start()

    def __exit__(self, *exc_info) -> None:
        self.close()

    # -- querying --------------------------------------------------------------

    def query(
        self,
        question: str,
        *,
        session_id: Optional[str] = None,
        keep_session_open: bool = False,
    ) -> GQueryResult:
        """Run an AI Mode query and return the structured result.

        By default this behaves as a one-shot query: it opens a fresh page,
        collects the answer, and closes it — exactly as before.

        To have a real multi-turn conversation (a follow-up typed into
        Google's own chat input on the same page, not a brand-new search),
        pass ``keep_session_open=True``. The returned result's ``session_id``
        can then be passed back in on the next call to continue that same
        conversation:

            r1 = client.query("What is Python?", keep_session_open=True)
            r2 = client.query("What's new in 3.13?",
                               session_id=r1.session_id, keep_session_open=True)
            client.close_session(r2.session_id)  # done — free the page

        If ``session_id`` is given but unknown/already closed, a new session
        is started instead and a new ``session_id`` is returned — check
        ``result.session_id`` against what you passed if that distinction
        matters to your caller.

        Raises:
            CaptchaDetectedError: Google served a CAPTCHA/unusual-traffic wall.
            SignInRequiredError: Google is asking for sign-in before AI Mode results.
            AIModeUnavailableError: page loaded but no AI Mode answer container appeared,
                or (when continuing a session) the chat input box wasn't found.
            GQueryTimeoutError: the answer didn't render within the timeout.
        """
        if self._context is None:
            self.start()

        self._respect_rate_limit()

        session = self._sessions.get(session_id) if session_id else None
        is_continuing = session is not None
        page = session.page if is_continuing else self._context.new_page()
        effective_session_id = session_id if is_continuing else str(uuid.uuid4())

        try:
            if is_continuing:
                previous_text = session.last_answer_text
                self._submit_follow_up(page, question)
                self._raise_if_captcha(page)
                self._raise_if_sign_in_required(page)
                match = self._wait_for_answer_change(page, previous_text)
            else:
                url = self._build_url(question)
                page.goto(url, wait_until="domcontentloaded", timeout=self.timeout_ms)
                self._dismiss_consent_if_present(page)
                self._raise_if_captcha(page)
                self._raise_if_sign_in_required(page)
                match = self._wait_for_answer_container(page)

            sources = self._extract_sources(page)
            follow_ups = self._extract_follow_ups(page)
            # Only attempt the clipboard-copy path on the first turn. Clicking
            # a follow-up turn's Copy button was empirically found to not
            # reliably re-populate the clipboard (likely a focus/binding quirk
            # on dynamically-added buttons), silently returning a *previous*
            # turn's stale clipboard text instead. The DOM-scraped `match`
            # from _wait_for_answer_change is independently verified correct
            # for follow-ups, so skip the enhancement rather than risk it.
            copied_text = None if is_continuing else self._extract_via_copy_button(page, question)

            if keep_session_open:
                self._sessions[effective_session_id] = _Session(
                    page=page, last_answer_text=match.text
                )
            else:
                self._sessions.pop(effective_session_id, None)

            return GQueryResult(
                query=question,
                answer_text=copied_text or match.text,
                answer_html=match.html,
                answer_markdown=copied_text or markdownify(match.html).strip(),
                sources=sources,
                follow_up_queries=follow_ups,
                ai_mode_triggered=True,
                extraction_method=match.method,
                copied_via_clipboard=bool(copied_text),
                session_id=effective_session_id,
                page_url=page.url,
            )
        except PlaywrightError as exc:
            self._sessions.pop(effective_session_id, None)
            if "closed" in str(exc).lower():
                raise GQueryError(
                    "The browser window was closed before the query finished. "
                    "Leave it open until g-query prints the JSON result and "
                    "exits on its own."
                ) from exc
            raise GQueryError(f"Browser automation failed: {exc}") from exc
        except GQueryError:
            self._sessions.pop(effective_session_id, None)
            raise
        finally:
            if not keep_session_open and not page.is_closed():
                page.close()

    # -- internals -------------------------------------------------------------

    def _respect_rate_limit(self) -> None:
        elapsed = time.monotonic() - self._last_request_at
        wait_for = self.min_request_interval - elapsed
        if wait_for > 0:
            time.sleep(wait_for + random.uniform(0, 0.5))
        self._last_request_at = time.monotonic()

    def _build_url(self, question: str) -> str:
        params = {"q": question, "udm": self.udm}
        return f"{GOOGLE_SEARCH_URL}?{urllib.parse.urlencode(params)}"

    def _dismiss_consent_if_present(self, page: Page) -> None:
        for selector in self.selectors.consent_accept_button:
            locator = page.locator(selector).first
            try:
                if locator.count() and locator.is_visible():
                    locator.click(timeout=2000)
                    page.wait_for_load_state("domcontentloaded")
                    return
            except PlaywrightTimeoutError:
                continue

    def _raise_if_captcha(self, page: Page) -> None:
        self._handle_interactive_gate(
            page,
            self.selectors.captcha_markers,
            CaptchaDetectedError,
            "Google is showing a CAPTCHA / unusual-traffic check. Please complete "
            "it in the browser window that just opened.",
            "Google served a CAPTCHA/unusual-traffic page. Re-run with "
            "headless=False and solve it once in the persistent profile.",
        )

    def _raise_if_sign_in_required(self, page: Page) -> None:
        self._handle_interactive_gate(
            page,
            self.selectors.sign_in_markers,
            SignInRequiredError,
            "Google is asking you to sign in. Please log into your Google "
            "account in the browser window that just opened.",
            "Google is asking for sign-in. Re-run with headless=False and "
            "log in once; the persistent profile will retain the session.",
        )

    def _markers_present(self, page: Page, selectors: list[str]) -> bool:
        return any(page.locator(selector).count() for selector in selectors)

    def _handle_interactive_gate(
        self,
        page: Page,
        selectors: list[str],
        exc_cls: type,
        headed_prompt: str,
        headless_message: str,
    ) -> None:
        if not self._markers_present(page, selectors):
            return

        if self.headless:
            # No one is watching a headless browser — fail fast instead of
            # holding the request open for nothing.
            raise exc_cls(headless_message)

        # Headed mode: a human can act on it. Don't slam the browser shut —
        # wait for the marker to clear (they finished signing in / solved the
        # CAPTCHA) or for interactive_wait_seconds to run out.
        print(f"\n[g-query] {headed_prompt}", file=sys.stderr)
        print(
            f"[g-query] Waiting up to {int(self.interactive_wait_seconds)}s "
            "for you to continue in the browser window...",
            file=sys.stderr,
        )
        deadline = time.monotonic() + self.interactive_wait_seconds
        while time.monotonic() < deadline:
            time.sleep(1.5)
            if not self._markers_present(page, selectors):
                print("[g-query] Continuing...", file=sys.stderr)
                return

        raise exc_cls(
            f"Still blocked after waiting {int(self.interactive_wait_seconds)}s. "
            f"{headed_prompt}"
        )

    def _submit_follow_up(self, page: Page, question: str) -> None:
        """Type a follow-up question into Google's own AI Mode chat input and
        submit it, continuing the same conversation thread instead of
        starting a brand-new search.

        Unlike the answer-container selectors (verified against a real
        capture), the chat input selectors in
        g_query.selectors.Selectors.chat_input are best-effort/unverified —
        if this raises AIModeUnavailableError, that box's real markup likely
        needs capturing and selectors.py updating, the same way the answer
        container did.
        """
        last_error: Exception | None = None
        for selector in self.selectors.chat_input:
            try:
                locator = page.locator(f"{selector}:visible").last
                locator.wait_for(state="visible", timeout=self.timeout_ms)
                locator.click()
                locator.fill(question)
                locator.press("Enter")
                return
            except PlaywrightTimeoutError as exc:
                last_error = exc
                continue
        raise AIModeUnavailableError(
            "Could not find Google's AI Mode chat input box to submit a "
            "follow-up question. This selector is best-effort and unverified "
            "— see g_query.selectors.Selectors.chat_input."
        ) from last_error

    def _wait_for_answer_change(self, page: Page, previous_text: str) -> _ContainerMatch:
        """After submitting a follow-up, wait for a new answer to finish
        rendering, rather than assuming a new DOM node gets appended —
        Google's chat UI may append a new answer container per turn, or
        mutate the existing one in place; comparing text handles either case
        without needing to know which.

        AI Mode answers stream in progressively (like an LLM chat reply), so
        the first observed difference from `previous_text` may just be a
        transient, not-yet-finished render — accepting it immediately can
        capture a mid-stream partial answer. Instead, require the text to
        stay unchanged for a short stability window before accepting it as
        the finished new answer.
        """
        STABILITY_WINDOW_S = 1.5
        POLL_INTERVAL_S = 0.4

        deadline = time.monotonic() + self.timeout_ms / 1000
        previous_text = (previous_text or "").strip()
        candidate_text: str | None = None
        candidate_html = ""
        stable_since: float | None = None

        while time.monotonic() < deadline:
            current_text = None
            current_html = ""
            for selector in self.selectors.answer_container:
                locator = page.locator(f"{selector}:visible").last
                if not locator.count():
                    continue
                text = locator.inner_text().strip()
                if text:
                    current_text = text
                    current_html = locator.inner_html()
                    break

            if current_text and current_text != previous_text:
                if current_text == candidate_text:
                    if (
                        stable_since is not None
                        and time.monotonic() - stable_since >= STABILITY_WINDOW_S
                    ):
                        return _ContainerMatch(
                            text=current_text, html=candidate_html, method="known_selector"
                        )
                else:
                    candidate_text = current_text
                    candidate_html = current_html
                    stable_since = time.monotonic()

            time.sleep(POLL_INTERVAL_S)

        raise GQueryTimeoutError(
            f"No new (stable) AI Mode answer appeared within {self.timeout_ms / 1000}s "
            "after submitting the follow-up question."
        )

    def _wait_for_answer_container(self, page: Page) -> _ContainerMatch:
        # `:visible` is a Playwright CSS extension (not standard CSS) that
        # filters out DOM matches that exist but aren't rendered — Google's
        # AI Mode markup includes hidden skeleton/placeholder nodes that share
        # the same class names as the real answer container, so matching
        # `.first` without this filter can return a node that never renders.
        last_error: Exception | None = None
        for selector in self.selectors.answer_container:
            try:
                locator = page.locator(f"{selector}:visible").first
                locator.wait_for(state="visible", timeout=self.timeout_ms)
                return _ContainerMatch(
                    text=locator.inner_text(),
                    html=locator.inner_html(),
                    method="known_selector",
                )
            except PlaywrightTimeoutError as exc:
                last_error = exc
                continue

        heuristic = self._heuristic_answer_container(page)
        if heuristic is not None:
            return heuristic

        if last_error is not None:
            raise GQueryTimeoutError(
                f"No AI Mode answer container appeared within {self.timeout_ms / 1000}s."
            ) from last_error
        raise AIModeUnavailableError(
            "No configured AI Mode selector matched this page. Google's layout may "
            "have changed — see g_query.selectors.Selectors."
        )

    def _heuristic_answer_container(self, page: Page) -> Optional[_ContainerMatch]:
        """Best-effort fallback when no known selector matches: find the
        smallest substantial, visible text block inside Google's long-stable
        result-column containers. Less precise than a maintained selector —
        callers should treat `extraction_method == "heuristic"` as a signal
        that g_query.selectors.Selectors needs updating, even though this
        path let the query succeed anyway.
        """
        try:
            result = page.evaluate(
                _HEURISTIC_JS, [_HEURISTIC_ROOT_SELECTORS, _HEURISTIC_MIN_CHARS]
            )
        except PlaywrightError:
            return None
        if not result:
            return None
        return _ContainerMatch(text=result["text"], html=result["html"], method="heuristic")

    def _extract_via_copy_button(self, page: Page, question: str) -> Optional[str]:
        """Best-effort: click Google's own "Copy" button on the AI Mode
        answer and read back the clipboard, instead of relying solely on
        text we scraped ourselves. Google maintains this button as a real
        product feature, so it's generally far more stable than internal CSS
        classes — but this is purely an enhancement: any failure here just
        falls back to the DOM-scraped text already collected in query().

        Only called for the first turn of a query/session — see query()'s
        `copied_text = None if is_continuing else ...` — because clicking a
        follow-up turn's Copy button was found to not reliably re-populate
        the clipboard in testing.

        Clears the clipboard before clicking and polls (rather than a single
        fixed sleep) for it to be populated: reading it too early after
        clicking returns stale text instead of an empty/failed result.

        `question` is used for a sanity check: Google renders a *separate*
        "Copy <the search query>" share button elsewhere on the page whose
        aria-label also contains "copy" — if a selector or a rendering race
        ever causes that button to get clicked instead of the real one, the
        clipboard ends up holding the query text itself. Since a genuine AI
        Mode answer is never just the question restated verbatim, discard
        (and fall back to the DOM-scraped text) if that happens, rather than
        silently returning the wrong thing.
        """
        try:
            self._context.grant_permissions(["clipboard-read", "clipboard-write"])
        except Exception:
            pass

        normalized_question = question.strip().lower()

        for selector in self.selectors.copy_button:
            try:
                locator = page.locator(f"{selector}:visible").last
                if not locator.count():
                    continue
                try:
                    page.evaluate("() => navigator.clipboard.writeText('')")
                except Exception:
                    pass
                locator.click(timeout=2000)
                deadline = time.monotonic() + 2.0
                while time.monotonic() < deadline:
                    text = page.evaluate("() => navigator.clipboard.readText()")
                    stripped = text.strip() if text else ""
                    if stripped and stripped.lower() != normalized_question:
                        return stripped
                    time.sleep(0.15)
            except Exception:
                continue
        return None

    # Google's citation links render as icon-only "View related links" pills
    # with no visible text, e.g. aria-label="South China Morning Post (+2) –
    # View related links" -- strip this suffix to recover just the source
    # name when inner_text() comes back empty.
    _SOURCE_ARIA_LABEL_SUFFIX_RE = re.compile(
        r"\s*[–-]\s*View related links\s*$", re.IGNORECASE
    )

    def _extract_sources(self, page: Page) -> list[Source]:
        sources: list[Source] = []
        seen_urls: set[str] = set()
        for selector in self.selectors.source_links:
            links = page.locator(selector)
            count = links.count()
            if not count:
                continue
            for i in range(count):
                link = links.nth(i)
                href = link.get_attribute("href") or ""
                if not href or href in seen_urls:
                    continue
                title = link.inner_text().strip()
                if not title:
                    aria_label = link.get_attribute("aria-label") or ""
                    title = self._SOURCE_ARIA_LABEL_SUFFIX_RE.sub("", aria_label).strip()
                sources.append(Source(title=title or href, url=href))
                seen_urls.add(href)
            break
        return sources

    def _extract_follow_ups(self, page: Page) -> list[str]:
        for selector in self.selectors.follow_up_chips:
            chips = page.locator(selector)
            count = chips.count()
            if count:
                return [chips.nth(i).inner_text().strip() for i in range(count)]
        return []
