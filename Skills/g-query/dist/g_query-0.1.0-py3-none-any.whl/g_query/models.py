"""Result data structures returned by GQueryClient.query()."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone


@dataclass
class Source:
    """A citation surfaced alongside an AI Mode answer."""

    title: str
    url: str
    snippet: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class GQueryResult:
    """Structured, JSON-serializable response from a single AI Mode query."""

    query: str
    answer_text: str
    answer_html: str = ""
    answer_markdown: str = ""
    sources: list[Source] = field(default_factory=list)
    follow_up_queries: list[str] = field(default_factory=list)
    ai_mode_triggered: bool = True
    # How the answer container was located: "known_selector" (matched one of
    # g_query.selectors.Selectors) or "heuristic" (fell back to the largest
    # visible text block in a stable structural container). "heuristic" is a
    # signal that Google's markup drifted and selectors.py likely needs an
    # update, even though extraction still succeeded.
    extraction_method: str = "known_selector"
    # True when answer_text/answer_markdown came from clicking Google's own
    # "Copy" button and reading the clipboard, rather than being scraped from
    # the DOM. Clipboard content is generally cleaner and more trustworthy
    # when available.
    copied_via_clipboard: bool = False
    # Identifies the browser page this query ran on. Pass this back into
    # GQueryClient.query(session_id=..., keep_session_open=True) to continue
    # the same conversation with a follow-up typed into Google's own chat
    # input, instead of starting a brand-new search. Empty/unusable once the
    # session has been closed (the default for a one-shot query() call).
    session_id: str = ""
    fetched_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    page_url: str = ""

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "answer_text": self.answer_text,
            "answer_html": self.answer_html,
            "answer_markdown": self.answer_markdown,
            "sources": [s.to_dict() for s in self.sources],
            "follow_up_queries": list(self.follow_up_queries),
            "ai_mode_triggered": self.ai_mode_triggered,
            "extraction_method": self.extraction_method,
            "copied_via_clipboard": self.copied_via_clipboard,
            "session_id": self.session_id,
            "fetched_at": self.fetched_at,
            "page_url": self.page_url,
        }

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)
