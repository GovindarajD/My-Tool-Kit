"""CSS selectors used to find AI Mode content in the Google Search DOM.

Google changes its markup/class names without notice. When scraping breaks, this is
almost always the only file that needs to change — update the selector lists below
rather than touching client.py. Each field is a list tried in order (first match wins).

Callers can also override selectors per-instance:

    from g_query import GQueryClient
    from g_query.selectors import Selectors

    custom = Selectors(answer_container=["div.my-new-selector"])
    client = GQueryClient(selectors=custom)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Selectors:
    # Container that holds the generated AI Mode answer. The first two entries
    # are confirmed against a real captured AI Mode page (2026-07):
    # `<div data-container-id="main-col" jsname="KFl8ub" class="mZJni Dn7Fzd">`.
    # `data-container-id`/`jsname` are Google's own stable component
    # identifiers (unlike `jsuid`, which is a per-render random id — do not
    # match on that). The rest are kept as fallbacks in case Google A/B tests
    # a different template.
    answer_container: list[str] = field(
        default_factory=lambda: [
            '[data-container-id="main-col"]',
            '[jsname="KFl8ub"]',
            "div.mZJni.Dn7Fzd",
            '[data-async-context*="query"] .LqWzUe',
            "div.M8OgIe",
            'div[data-attrid="AIOverview"]',
            'div[jsname="rqhead"]',
            '[role="region"][aria-label*="AI"]',
        ]
    )

    # Individual citation/source links inside the answer container. These
    # are icon-only "View related links" pills -- there's usually no visible
    # link text, so the source name comes from aria-label instead (see
    # client.py's _extract_sources). Confirmed against a real capture
    # (2026-07): `<a class="PMDqCb" aria-label="South China Morning Post
    # (+2) – View related links" href="...">`.
    source_links: list[str] = field(
        default_factory=lambda: [
            "a.PMDqCb",
            "a.YwoBGf",
            "a[data-rc-ludocid]",
            "div.zReHs a",
        ]
    )

    # Google's own "Copy" button on the AI Mode answer. Clicking it and
    # reading the clipboard is more robust than scraping innerText/innerHTML
    # ourselves — it's a real product feature Google maintains deliberately,
    # unlike internal CSS classes which are obfuscated and change often.
    # Confirmed against a real capture (2026-07): `<button class="bKxaof"
    # aria-label="Copy text">`.
    #
    # Deliberately an EXACT match only, not a `*="copy" i` substring match.
    # Google also renders a "Copy <the search query>" button elsewhere on the
    # page (a "copy this search" affordance, unrelated to the answer) whose
    # aria-label always contains "copy" too — a substring selector can match
    # it instead of the real button, silently copying the query text itself
    # into answer_text. This was found via a live bug report and is exactly
    # the failure mode _extract_via_copy_button's query-echo sanity check
    # guards against as a second line of defense.
    copy_button: list[str] = field(
        default_factory=lambda: [
            'button[aria-label="Copy text" i]',
        ]
    )

    # Google's AI Mode chat input box ("Ask anything"), used to submit a
    # follow-up question on the same conversation thread. UNVERIFIED/best-effort
    # — unlike answer_container/copy_button, this has not been confirmed
    # against a real capture. If GQueryClient._submit_follow_up starts raising
    # AIModeUnavailableError, capture the real input box's markup (same way
    # answer_container was fixed) and update this list.
    chat_input: list[str] = field(
        default_factory=lambda: [
            'textarea[placeholder="Ask anything" i]',
            'textarea[aria-label*="ask anything" i]',
            'div[contenteditable="true"][aria-label*="ask anything" i]',
            'textarea[aria-label*="ask" i]',
        ]
    )

    # Suggested follow-up query chips.
    follow_up_chips: list[str] = field(
        default_factory=lambda: [
            "div.follow-up-chip",
            'div[role="button"].oIzYWc',
        ]
    )

    # Consent / "before you continue" dialog accept button.
    consent_accept_button: list[str] = field(
        default_factory=lambda: [
            "button#L2AGLb",
            'form[action*="consent"] button',
            'button[aria-label*="Accept all"]',
        ]
    )

    # Indicators Google is showing a CAPTCHA / unusual-traffic interstitial.
    captcha_markers: list[str] = field(
        default_factory=lambda: [
            "#recaptcha",
            'form[action*="sorry"]',
            "div.g-recaptcha",
        ]
    )

    # Indicators Google wants the user to sign in before continuing.
    sign_in_markers: list[str] = field(
        default_factory=lambda: [
            'a[href*="ServiceLogin"]',
        ]
    )
