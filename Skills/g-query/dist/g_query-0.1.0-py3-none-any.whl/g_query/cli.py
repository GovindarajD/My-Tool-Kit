"""Command-line entry point: `g-query "some question"`."""

from __future__ import annotations

import argparse
import sys

from .client import GQueryClient
from .exceptions import GQueryError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="g-query",
        description="Query Google Search AI Mode via a real Chromium session and print JSON.",
    )
    parser.add_argument("question", help="The question to ask Google AI Mode.")
    parser.add_argument(
        "--headed",
        action="store_true",
        help="Show the browser window (use for first-time Google sign-in).",
    )
    parser.add_argument(
        "--profile-dir",
        default=None,
        help="Persistent Chromium profile directory (default: ~/.g-query/profile).",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=20.0,
        help="Seconds to wait for the AI Mode answer to render (default: 20).",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        with GQueryClient(
            headless=not args.headed,
            profile_dir=args.profile_dir,
            timeout=args.timeout,
        ) as client:
            result = client.query(args.question)
            print(result.to_json())
        return 0
    except GQueryError as exc:
        print(f"g-query error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
