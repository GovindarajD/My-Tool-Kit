"""Persistent-profile Chromium launch helper.

Using a persistent user_data_dir (rather than a fresh incognito context per run) is
the whole trick that makes this reliable: log in to google.com once in a headed
window, and every subsequent headless run reuses that same cookie jar / session,
so Google sees a normal returning browser instead of a fresh anonymous client.
"""

from __future__ import annotations

import os
from pathlib import Path

from playwright.sync_api import BrowserContext, Playwright

DEFAULT_PROFILE_DIR = Path.home() / ".g-query" / "profile"

DEFAULT_LAUNCH_ARGS = [
    "--disable-blink-features=AutomationControlled",
]


def launch_context(
    playwright: Playwright,
    *,
    profile_dir: str | os.PathLike | None,
    headless: bool,
    locale: str,
    hide_window: bool = False,
    extra_args: list[str] | None = None,
) -> BrowserContext:
    profile_path = Path(profile_dir) if profile_dir else DEFAULT_PROFILE_DIR
    profile_path.mkdir(parents=True, exist_ok=True)

    args = list(DEFAULT_LAUNCH_ARGS)
    if hide_window and not headless:
        # Google's real bot-detection distinguishes headless=True from a
        # normal window, not window position — so a window pushed off-screen
        # is still a genuine "headed" browser as far as Chromium/Google are
        # concerned, just not visually intrusive. Confirmed true headless
        # does not reliably get real AI Mode content; this does.
        args.append("--window-position=-32000,-32000")
    args += extra_args or []

    context = playwright.chromium.launch_persistent_context(
        user_data_dir=str(profile_path),
        headless=headless,
        args=args,
        locale=locale,
        viewport={"width": 1280, "height": 900},
    )
    return context
