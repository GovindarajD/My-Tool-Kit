"""g_query: drive a real Chromium browser session against Google Search AI Mode
and return the answer as a structured JSON-serializable payload.
"""

from .client import GQueryClient
from .exceptions import (
    AIModeUnavailableError,
    CaptchaDetectedError,
    GQueryError,
    GQueryTimeoutError,
    SignInRequiredError,
)
from .models import GQueryResult, Source

__version__ = "0.1.0"

__all__ = [
    "GQueryClient",
    "GQueryResult",
    "Source",
    "GQueryError",
    "CaptchaDetectedError",
    "AIModeUnavailableError",
    "SignInRequiredError",
    "GQueryTimeoutError",
]
