"""Typed exceptions raised by g_query.

Kept specific and typed (rather than generic RuntimeError) so callers — including AI
agents driving this library — can branch on failure mode: a CAPTCHA or sign-in wall
needs a human to re-authenticate in a headed browser; a missing AI Mode container may
just mean Google changed its layout or didn't trigger AI Mode for that query.
"""


class GQueryError(Exception):
    """Base class for all g_query errors."""


class CaptchaDetectedError(GQueryError):
    """Google served a CAPTCHA / 'unusual traffic' interstitial.

    g_query never attempts to solve or bypass this. Re-run with headless=False and
    solve it manually once; the persistent profile will retain the cleared state.
    """


class SignInRequiredError(GQueryError):
    """Google is asking for sign-in before it will serve AI Mode results.

    Run once with headless=False and profile_dir pointed at a persistent directory,
    log in by hand, then subsequent headless runs reuse that session.
    """


class AIModeUnavailableError(GQueryError):
    """The page loaded, but no AI Mode response container was found.

    Usually means Google didn't route this query to AI Mode, the feature isn't
    enabled for this account/region, or Google changed its DOM (see selectors.py).
    """


class GQueryTimeoutError(GQueryError):
    """The AI Mode response did not finish rendering within the configured timeout."""
