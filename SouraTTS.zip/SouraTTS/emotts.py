# emotts.py — SouraTTS v1 Inference
# https://huggingface.co/Sourajit123/SouraTTS

import torch
import torch.nn as nn
import numpy as np
import scipy.io.wavfile
import json
from pathlib import Path


class EmoShiftLayer(nn.Module):
    EMOTIONS = ["angry", "disgust", "fear", "happy", "neutral", "sad"]

    def __init__(self, hidden_size: int = 1024, injection_layer: int = 5):
        super().__init__()
        self.hidden_size = hidden_size
        self.injection_layer = injection_layer
        self.steering_vectors = nn.ParameterDict({
            emotion: nn.Parameter(torch.zeros(hidden_size))
            for emotion in self.EMOTIONS
        })
        self.active_emotion = "neutral"
        self.intensity = 0.0

    def set_emotion(self, emotion: str, intensity: float):
        assert emotion in self.EMOTIONS, f"Choose from: {self.EMOTIONS}"
        assert intensity >= 0.0, "Intensity must be non-negative"
        self.active_emotion = emotion
        self.intensity = intensity

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.active_emotion == "neutral" or self.intensity == 0.0:
            return x
        vec = self.steering_vectors[self.active_emotion]
        return x + self.intensity * vec.unsqueeze(0).unsqueeze(0)


class EmoTTS:
    """
    SouraTTS v1 — Pocket-TTS with EmoShift emotion steering.

    Supported emotions : angry, disgust, fear, happy, neutral, sad
    Recommended range  : intensity 0.5 to 1.0
    Built-in voices    : alba, marius, cosette, jean,
                         fantine, eponine, azelma, javert

    Usage:
        from emotts import EmoTTS

        tts = EmoTTS()
        tts.synthesize(
            text      = "I just got the job!",
            voice     = "alba",
            emotion   = "happy",
            intensity = 1.0,
            output    = "out.wav"
        )
    """

    def __init__(
        self,
        weights : str = "SouraTTS.pt",
        meta    : str = "SouraTTS.json",
    ):
        self.device = torch.device("cpu")
        print("Loading SouraTTS v1...")

        # Load metadata
        meta_path = Path(meta)
        if meta_path.exists():
            with open(meta_path) as f:
                self.meta = json.load(f)
            print(f"  Injection layer : {self.meta.get('injection_layer', 5)}")
            print(f"  Emotions        : {self.meta.get('emotions')}")
            print(f"  Trained on      : {self.meta.get('training_data')}")
        else:
            self.meta = {}
            print(f"  Warning: no metadata found at {meta}")

        # Load EmoShift vectors
        self.emo_layer = EmoShiftLayer(hidden_size=1024, injection_layer=5)
        weights_path = Path(weights)
        if weights_path.exists():
            state = torch.load(weights_path, map_location=self.device)
            self.emo_layer.load_state_dict(state)
            print(f"  Weights loaded  : {weights_path} ({weights_path.stat().st_size/1024:.1f} KB)")
        else:
            raise FileNotFoundError(
                f"Weights not found at {weights_path}\n"
                f"Download SouraTTS.pt from https://huggingface.co/Sourajit123/SouraTTS"
            )
        self.emo_layer.eval()

        # Load pocket-tts
        try:
            from pocket_tts import TTSModel
        except ImportError:
            raise ImportError("Run: pip install pocket-tts")

        print("  Loading pocket-tts...")
        self.model = TTSModel.load_model()
        self.model._GEN_SECONDS_PADDING = 3.0
        self.model._TOKENS_PER_SECOND_ESTIMATE = 2.0
        self.model.eval()
        print("  pocket-tts ready.")

        # Register EmoShift hook on transformer layer 5
        self._hook_handle = None
        self._register_hook()

        # Voice state cache
        self._voice_cache = {}

        print("SouraTTS v1 ready.\n")

    def _register_hook(self):
        if self._hook_handle is not None:
            self._hook_handle.remove()
        def emo_hook(module, input, output):
            return self.emo_layer(output)
        self._hook_handle = (
            self.model.flow_lm.transformer.layers[5]
            .register_forward_hook(emo_hook)
        )

    def _get_voice_state(self, voice: str):
        if voice not in self._voice_cache:
            print(f"  Processing voice '{voice}'...")
            self._voice_cache[voice] = self.model.get_state_for_audio_prompt(voice)
        return self._voice_cache[voice]

    def synthesize(
        self,
        text      : str,
        voice     : str   = "alba",
        emotion   : str   = "neutral",
        intensity : float = 1.0,
        output    : str   = "output.wav",
    ) -> np.ndarray:
        """
        Synthesize emotional speech and save to a wav file.

        Args:
            text      : Text to synthesize
            voice     : Built-in voice name or path to a .wav file
            emotion   : angry | disgust | fear | happy | neutral | sad
            intensity : Emotion strength (0.0 = none, 1.0 = full, max ~1.2)
            output    : Output file path

        Returns:
            numpy array of audio samples at 24000 Hz
        """
        self.emo_layer.set_emotion(emotion, intensity)
        voice_state = self._get_voice_state(voice)

        with torch.no_grad():
            audio = self.model.generate_audio(voice_state, text)

        audio_np = audio.cpu().numpy().squeeze()
        scipy.io.wavfile.write(output, self.model.sample_rate, audio_np)
        duration = len(audio_np) / self.model.sample_rate
        print(f"  [{emotion} @ {intensity}] "
              f"'{text[:50]}{'...' if len(text) > 50 else ''}' "
              f"→ {output} ({duration:.1f}s)")
        return audio_np

    def available_emotions(self) -> list:
        return EmoShiftLayer.EMOTIONS

    def available_voices(self) -> list:
        return ["alba", "marius", "cosette", "jean",
                "fantine", "eponine", "azelma", "javert"]

    def cleanup(self):
        if self._hook_handle is not None:
            self._hook_handle.remove()
            self._hook_handle = None

    def __del__(self):
        self.cleanup()


if __name__ == "__main__":
    tts = EmoTTS(
        weights="SouraTTS.pt",
        meta="SouraTTS.json"
    )

    print("Available emotions:", tts.available_emotions())
    print("Available voices  :", tts.available_voices())
    print()

    tests = [
        ("neutral", 0.0, "alba", "The meeting is scheduled for three tomorrow."),
        ("happy",   1.0, "alba", "I just got the job! I cannot believe it!"),
        ("sad",     1.0, "alba", "I miss you. Things are not the same without you."),
        ("angry",   1.0, "alba", "This is completely unacceptable."),
        ("fear",    1.0, "alba", "Did you hear that? Something is out there."),
        ("disgust", 1.0, "alba", "That is revolting. I cannot even look at it."),
    ]

    for emotion, intensity, voice, text in tests:
        tts.synthesize(
            text      = text,
            voice     = voice,
            emotion   = emotion,
            intensity = intensity,
            output    = f"out_{emotion}.wav"
        )

    tts.cleanup()
